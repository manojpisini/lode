# Project Discovery Report Example

> Example only. A real `UPPS-03` run writes its primary report to `./reports/discovery/project_discovery_report.md` in the audited project.

*UPPS-03 Project Discovery — Mode: AUDIT_ONLY*

## Repository Identity

| Field | Value |
|---|---|
| Name | LODE |
| Type | Rust developer tool (CLI + daemon + MCP + LSP + TUI) |
| Root | `.` |
| Version | 0.1.0 |
| License | MIT |
| Edition | 2021 |
| Workspace resolver | 2 |
| Status | Active development |

## Version Control

| Field | Value |
|---|---|
| Git | Yes |
| Default branch | (not determined) |
| `.gitignore` | Present (covers `target/`, `prompts/`, logs, etc.) |
| `.gitattributes` | Present |

## Workspace Architecture

**6 crates, 155 `.rs` source files, 4 binary targets:**

| Crate | Role | Files | Binary | Tests |
|---|---|---|---|---|
| `lode-core` | Shared library | 55 .rs (inc. 23 config sub-modules) | — | 1 file |
| `lode-cli` | CLI binary | 48 .rs (46 command modules) | `lode` | 13 files |
| `lode-daemon` | Background file watcher | 7 .rs | `lode-daemon` | 0 |
| `lode-mcp` | MCP server | 24 .rs (15 tool modules) | `lode-mcp` | 0 (embedded) |
| `lode-tui` | Terminal UI | 19 .rs (6 widget modules) | `lode-tui` | 0 |
| `lode-lsp` | LSP server | 2 .rs | `lode-lsp` | 0 (8 embedded) |

## Language & Runtime

| Field | Value |
|---|---|
| Language | Rust (stable) |
| Toolchain | `stable-x86_64-pc-windows-gnu` |
| Build system | Cargo workspace |
| Linter | Clippy (`-D warnings`) |
| Formatter | rustfmt |
| Fuzzer | `cargo fuzz` (2 targets) |

## Entry Points

| Binary | Source | Purpose |
|---|---|---|
| `lode` | `crates/lode-cli/src/main.rs` | CLI with 50+ subcommands |
| `lode-daemon` | `crates/lode-daemon/src/main.rs` | Background file watcher |
| `lode-mcp` | `crates/lode-mcp/src/main.rs` | MCP protocol server |
| `lode-tui` | `crates/lode-tui/src/main.rs` | Terminal dashboard |
| `lode-lsp` | `crates/lode-lsp/src/main.rs` | LSP protocol server |

## Key Dependencies

| Dependency | Version | Used By |
|---|---|---|
| `clap` 4.5 (derive) | Workspace | lode-cli, lode-daemon, lode-mcp |
| `serde` 1.0+ (derive) | Workspace | All crates |
| `ratatui` 0.28 | Workspace | lode-tui, lode-cli (serve) |
| `crossterm` 0.28 | Workspace | lode-tui, lode-cli |
| `tokio` 1 (full) | Workspace | lode-daemon |
| `notify` 6.1+ | Workspace | lode-daemon |
| `camino` 1.1 (serde1) | Workspace | All crates |
| `tower-lsp` | lode-lsp | LSP framework |
| `lsp-types` | lode-lsp | LSP types |

## CI/CD Pipeline

| Stage | Tool |
|---|---|
| Check | `cargo check --workspace` |
| Build | `cargo build` (3 OS targets) |
| Audit | `cargo audit` / deny.toml (advisory, license, bans) |
| Test | `cargo test --workspace` (3 OS matrix) |
| Lint | `cargo clippy --workspace -- -D warnings` |
| Format | `cargo fmt --check` |
| Coverage | `cargo llvm-cov --workspace` |
| Fuzz | `cargo fuzz run` (validated_root, process_validation) |
| Release | 3-platform artifact build + GitHub Release |

## Security Model

| Surface | Mechanism |
|---|---|
| Path validation | `ValidatedRoot` — prevents directory traversal, atomic writes via Windows ReplaceFileW |
| Process execution | `Process` — validates program names, rejects shell metacharacters |
| Secret scanning | Regex-based detection of API keys, tokens, passwords |
| Secrets redaction | All secrets redacted from logs, metrics, MCP responses |
| Plugin security | Permission receipts (network, execute, fs paths) |
| Network access | Explicit and narrow (MCP HTTP, daemon IPC) |

## Extensions

| Extension | Language | Purpose |
|---|---|---|
| `vscode-lode` | TypeScript | VS Code extension |
| `lode.nvim` | Lua | Neovim plugin |
| `zed-lode` | Rust/WASM | Zed editor extension |

## Documentation Inventory

| File | Purpose |
|---|---|
| `README.md` | Project overview |
| `CONTRIBUTING.md` | Contribution guide |
| `SECURITY.md` | Security policy |
| `CHANGELOG.md` | Release changelog |
| `AGENTS.md` | AI agent instructions |
| `LODE_DESIGN_FINAL.md` | Design document |
| `prompts/README.md` | Prompt suite documentation |
| `prompts/PROMPT_CATALOG.md` | Prompt inventory |
| `prompts/PROMPT_EXECUTION_ORDER.md` | Execution scenarios |
| `prompts/PROMPT_SUITE_CONVENTIONS.md` | Suite conventions |
| `prompts/MANIFEST.md` | Suite manifest |

## Coverage & Exclusions

| Area | Coverage |
|---|---|
| Rust source | 155 .rs files verified |
| Cargo.toml files | 7 (workspace + 6 crates) |
| Extensions | 3 extensions (TypeScript, Lua, Rust/WASM) |
| CI/CD | `.github/workflows/ci.yml` |
| Fuzz | `fuzz/` directory with 2 targets |
| **Excluded** | `prompts/` (UPPS suite — per task exclusions) |
| **Excluded** | `target/` (build artifacts) |
| **Excluded** | `outputs/` (runtime outputs) |

## Acceptance Criteria Verification

| Criterion | Status |
|---|---|
| `cargo check --workspace` | PASS |
| `cargo test --workspace` | PASS (321+ tests) |
