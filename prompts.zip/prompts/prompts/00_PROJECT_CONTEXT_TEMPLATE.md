---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-00
sequence: 0
title: Project Context Template
slug: project-context-template
canonical_path: prompts/00_PROJECT_CONTEXT_TEMPLATE.md
category: core
prompt_type: template
status: stable
description: Collects project context, task scope, permissions, constraints, and verification requirements before any specialist prompt runs.
language_agnostic: true
self_contained: false
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: none
risk_level: low
requires: []
recommended_before:
- UPPS-01
- UPPS-02
recommended_after: []
related_prompts:
- UPPS-01
- UPPS-02
expected_outputs:
- normalized_project_context
- permission_boundary
- verification_requirements
tags:
- context
- permissions
- inputs
- template
last_updated: '2026-07-11'
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: .prompt_suite/context/project_context.yaml
    format: yaml
    purpose: Normalized project context used by the prompt suite.
    required_when_writing: true
  supporting_artifacts:
  - path: .prompt_suite/context/permission_boundary.yaml
    format: yaml
    purpose: Resolved permissions, prohibitions, and approval boundaries.
    required_when_writing: true
  - path: .prompt_suite/context/verification_requirements.yaml
    format: yaml
    purpose: Required commands, acceptance criteria, and validation constraints.
    required_when_writing: true
---

# Project Context Template

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./.prompt_suite/context/project_context.yaml` | `yaml` | Normalized project context used by the prompt suite. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./.prompt_suite/context/permission_boundary.yaml` | `yaml` | Resolved permissions, prohibitions, and approval boundaries. | Required when writing |
| `./.prompt_suite/context/verification_requirements.yaml` | `yaml` | Required commands, acceptance criteria, and validation constraints. | Required when writing |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_00_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_00
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

Copy this block above a specialist prompt or provide the same values through your agent runner.

```yaml
PROJECT:
  name: ""
  root: "."
  type: ""
  purpose: ""
  status: ""
  primary_users: []
  supported_platforms: []
  deployment_targets: []
  languages: []
  frameworks: []
  runtimes: []
  package_managers: []
  data_stores: []
  external_services: []

TASK:
  mode: "AUDIT_ONLY"
  scope: "entire repository"
  objectives: []
  priority_areas: []
  exclusions: []
  protected_paths: []
  required_outputs: []
  write_output_files: true
  use_prompt_output_contracts: true
  output_path_base: "project_root"
  create_missing_output_directories: true
  overwrite_policy: "preserve_existing"
  run_id: ""
  additional_output_paths: []

PERMISSIONS:
  modify_files: false
  delete_files: false
  rename_or_move_files: false
  install_dependencies: false
  upgrade_dependencies: false
  access_network: false
  query_external_advisories: false
  execute_project_code: false
  run_tests: true
  run_builds: true
  start_local_services: false
  use_containers: false
  access_local_secrets: false
  modify_data: false
  run_migrations: false
  change_public_contracts: false
  execute_unknown_binaries: false
  create_commits: false

VERIFICATION:
  required_commands: []
  optional_commands: []
  forbidden_commands: []
  compatibility_requirements: []
  acceptance_criteria: []
  performance_budgets: {}

CONTEXT:
  architecture_notes: ""
  repository_conventions: ""
  documentation_conventions: ""
  security_constraints: ""
  compliance_constraints: ""
  additional_notes: ""
```


## Output Configuration Guidance

`TASK.write_output_files` controls whether the agent writes artifacts or returns them only in chat.

`TASK.output_path_base` must normally remain `project_root`.

Do not set a shared output directory such as `docs/prompts`, `output`, or `outputs`.

Each specialist prompt already declares its own canonical report, plan, artifact, and log locations through `output_contract`.

The normalized project context must be persisted as:

```text
./.prompt_suite/context/project_context.yaml
```

This file is runtime context for the prompt system, not project documentation.
