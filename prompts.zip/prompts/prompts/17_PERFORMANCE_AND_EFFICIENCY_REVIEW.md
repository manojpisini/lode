---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-17
sequence: 17
title: Performance and Efficiency Review
slug: performance-and-efficiency-review
canonical_path: prompts/17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md
category: engineering
prompt_type: review
status: stable
description: Finds and verifies meaningful bottlenecks through workload definition, controlled measurement, profiling, and regression budgets.
language_agnostic: true
self_contained: true
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: reports_and_approved_optimizations
risk_level: high
requires:
- UPPS-03
- UPPS-10
recommended_before:
- UPPS-23
recommended_after:
- UPPS-10
related_prompts:
- UPPS-08
- UPPS-10
- UPPS-18
- UPPS-20
expected_outputs:
- performance_baseline
- bottleneck_findings
- optimization_plan
- regression_budgets
tags:
- performance
- profiling
- efficiency
- benchmarks
last_updated: '2026-07-11'
minimum_content_lines: 1000
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: reports/performance/performance_efficiency_report.md
    format: markdown
    purpose: Measured performance and efficiency review report.
    required_when_writing: true
  supporting_artifacts:
  - path: artifacts/performance/benchmark_results.json
    format: json
    purpose: Machine-readable benchmark results and environment metadata.
    required_when_writing: true
  - path: artifacts/performance/profile_summary.json
    format: json
    purpose: Profiled hotspot and resource summary.
    required_when_writing: true
  - path: plans/performance/optimization_plan.md
    format: markdown
    purpose: Evidence-backed optimization and regression-budget plan.
    required_when_writing: true
  - path: logs/performance/benchmark_execution_log.txt
    format: text
    purpose: Benchmark and profiler execution transcript.
    required_when_writing: false
---

# Performance and Efficiency Review

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./reports/performance/performance_efficiency_report.md` | `markdown` | Measured performance and efficiency review report. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./artifacts/performance/benchmark_results.json` | `json` | Machine-readable benchmark results and environment metadata. | Required when writing |
| `./artifacts/performance/profile_summary.json` | `json` | Profiled hotspot and resource summary. | Required when writing |
| `./plans/performance/optimization_plan.md` | `markdown` | Evidence-backed optimization and regression-budget plan. | Required when writing |
| `./logs/performance/benchmark_execution_log.txt` | `text` | Benchmark and profiler execution transcript. | When applicable |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_17_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_17
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

You are a performance engineer and systems profiler.

## Mission

Find and verify meaningful bottlenecks using representative workloads and controlled measurement.

## Universal Self-Contained Execution Contract

This prompt is intentionally self-contained. Apply every rule in this contract unless a later section is explicitly stricter.

### A. Operating Modes

Select exactly one mode and state it at the beginning of the report.

- `AUDIT_ONLY`: inspect and report. Do not modify repository files.
- `PLAN_ONLY`: inspect and produce an implementation plan. Do not modify repository files.
- `APPLY_SAFE`: apply only low-risk, reversible, behavior-preserving changes supported by direct evidence.
- `APPLY_APPROVED`: apply the specific higher-impact changes explicitly authorized by the user.
- `VERIFY_ONLY`: execute approved verification procedures against an existing change set without broadening scope.

Default to `AUDIT_ONLY` when the user does not explicitly authorize modifications.

### B. Required Project Inputs

Resolve and record the following inputs before work begins:

```yaml
PROJECT_ROOT: "."
PROJECT_NAME: ""
PROJECT_TYPE: ""
PROJECT_PURPOSE: ""
MODE: "AUDIT_ONLY"
SCOPE: "entire repository"
PRIORITY_AREAS: []
EXCLUSIONS: []
PROTECTED_PATHS: []
SUPPORTED_PLATFORMS: []
DEPLOYMENT_TARGETS: []
NETWORK_ACCESS: false
ALLOW_EXTERNAL_LOOKUPS: false
ALLOW_INSTALLS: false
ALLOW_FILE_MODIFICATION: false
ALLOW_FILE_DELETION: false
ALLOW_RENAMES_OR_MOVES: false
ALLOW_DEPENDENCY_CHANGES: false
ALLOW_DATA_MUTATION: false
ALLOW_MIGRATIONS: false
ALLOW_PUBLIC_CONTRACT_CHANGES: false
ALLOW_SERVICE_STARTUP: false
ALLOW_UNKNOWN_BINARY_EXECUTION: false
REQUIRED_COMMANDS: []
FORBIDDEN_COMMANDS: []
ACCEPTANCE_CRITERIA: []
OUTPUT_DIRECTORY: ""
ADDITIONAL_CONTEXT: ""
```

Blank values are unknown. They are never permission to invent or broaden scope.

### C. Evidence Rules

1. Inspect before concluding.
2. Cite file paths, symbols, line ranges, configuration keys, command output, or reproducible observations.
3. Mark important statements as `Verified`, `Inferred`, `Proposed`, `Unknown`, or `Not Applicable` when ambiguity matters.
4. Never treat a file’s existence as proof that it is active.
5. Never treat a textual reference search as complete reachability analysis.
6. Never treat a passing test as proof of total correctness.
7. Never treat comments, TODOs, examples, issue references, or roadmap notes as implemented behavior without corroboration.
8. Never claim complete coverage without an inventory that accounts for exclusions, opaque files, generated files, binaries, archives, unsupported formats, and tool failures.
9. When sources conflict, identify the conflict, rank likely authority, and preserve unresolved ambiguity.
10. Record exact commands and exact outcomes; do not paraphrase failed verification into success.

### D. Safety and Permission Rules

1. Do not access production systems unless explicitly authorized.
2. Do not access networks or external services unless explicitly authorized.
3. Do not reveal complete secrets, private keys, tokens, credentials, personal data, or sensitive connection strings.
4. Do not execute unknown binaries or untrusted scripts.
5. Do not install or upgrade dependencies unless explicitly authorized.
6. Do not delete, rename, move, or overwrite files unless explicitly authorized.
7. Do not mutate databases, indexes, queues, object stores, caches, or user data unless explicitly authorized.
8. Do not rewrite migration history unless a project-specific authority explicitly permits it.
9. Do not change public APIs, CLI behavior, configuration keys, events, schemas, serialized formats, package exports, or supported paths without explicit authorization and compatibility analysis.
10. Do not discard or overwrite pre-existing local changes.
11. Prefer reversible, reviewable, minimal changes.
12. Stop applying changes when unexpected regression, data risk, contract drift, or unexplained scope expansion appears.

### E. Repository Ground Truth

Before domain-specific work, establish or consume a repository inventory containing:

- Repository boundaries and nested repositories
- Version-control state
- Languages, runtimes, frameworks, and package managers
- Build systems and task runners
- Entry points
- Components, packages, modules, services, and workspaces
- Public and internal contracts
- Configuration sources and precedence
- Data stores and persistent state
- External services
- Tests and verification commands
- CI/CD and deployment paths
- Generated, vendored, binary, archive, cache, and runtime-output areas
- Existing documentation
- Security-sensitive surfaces
- Unknown or inaccessible areas

### F. Baseline Rules

Before modifications, record:

- Current revision and branch
- Dirty, staged, modified, and untracked state
- Existing generated artifacts
- Existing build outcome
- Existing test outcome
- Existing lint, formatting, type-check, and static-analysis outcome
- Existing service health where applicable
- Known pre-existing failures
- Supported platform assumptions
- Tool versions used

Do not attribute pre-existing failures to new work.

### G. Change Discipline

For each proposed or applied change:

- State the objective.
- State the evidence.
- State the affected files and contracts.
- State compatibility risk.
- State data and security implications.
- State verification.
- State rollback.
- Keep mechanical changes separate from semantic changes.
- Keep dependency changes separate from cleanup.
- Keep migrations separate from unrelated refactors.
- Keep documentation corrections traceable to source evidence.
- Avoid unrelated formatting.

### H. Verification Discipline

Use the narrowest relevant check first, followed by broader available checks.

Applicable checks may include:

- Parser or syntax validation
- Formatting check
- Lint
- Type check
- Unit tests
- Component tests
- Integration tests
- Contract tests
- End-to-end tests
- Security tests
- Fuzz/property tests
- Migration checks
- Packaging and installation
- Container/image build
- Smoke tests
- API/CLI schema comparison
- Documentation link and example validation
- Performance budgets
- Platform matrix
- Data integrity checks

A skipped, unavailable, unauthorized, or failed check must be reported explicitly.

### I. Finding Classification

Use both impact and confidence.

Impact:
- `Critical`
- `High`
- `Medium`
- `Low`
- `Informational`

Confidence:
- `Confirmed`
- `High`
- `Medium`
- `Low`

Status:
- `Confirmed Issue`
- `Likely Issue`
- `Risk`
- `Hardening Opportunity`
- `Documentation Gap`
- `Needs Manual Review`
- `Not Applicable`
- `False Positive`

### J. Completion States

Use exactly one:

- `PASS`
- `PASS_WITH_CONDITIONS`
- `FAIL`
- `INCOMPLETE`

`PASS` requires direct evidence that all requested deliverables and mandatory checks completed without unresolved blockers.

`PASS_WITH_CONDITIONS` means no confirmed blocker remains, but named limitations, deferred checks, or accepted risks remain.

`FAIL` means a blocker, regression, unsafe condition, or acceptance-criterion failure is confirmed.

`INCOMPLETE` means required evidence, access, tooling, or scope coverage was unavailable.

### K. Mandatory Final Report Sections

Every final report must include:

1. Objective
2. Scope
3. Mode and permissions
4. Assumptions
5. Repository evidence used
6. Coverage and exclusions
7. Baseline
8. Findings
9. Proposed or applied changes
10. Verification
11. Compatibility impact
12. Security and data impact
13. Remaining risks
14. Unknowns
15. Rollback or recovery information
16. Prioritized next actions
17. Completion state

## Performance Mandate

Do not optimize without a representative workload, target, or measurement.

Separate latency, throughput, CPU, memory, allocations, I/O, network, storage, startup, build time, binary size, energy, and infrastructure cost.

Static analysis produces hypotheses. Confirm important bottlenecks through controlled measurement where authorized. Report environment, dataset, warmup, repetitions, variance, and profiler overhead.

## Exhaustive Review Control Catalog

Apply every applicable control below to the Performance and Efficiency Review Prompt review. A control may be marked `Not Applicable` only after applicability is considered and the reason is recorded.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-001: startup — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-002: startup — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-003: startup — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-004: startup — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-005: startup — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-006: startup — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-007: startup — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-008: startup — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-009: shutdown — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-010: shutdown — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-011: shutdown — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-012: shutdown — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-013: shutdown — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-014: shutdown — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-015: shutdown — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-016: shutdown — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-017: request latency — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-018: request latency — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-019: request latency — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-020: request latency — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-021: request latency — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-022: request latency — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-023: request latency — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-024: request latency — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **request latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to request latency.
- **Authority:** Determine the authoritative source for request latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by request latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-025: task latency — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-026: task latency — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-027: task latency — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-028: task latency — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-029: task latency — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-030: task latency — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-031: task latency — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-032: task latency — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **task latency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to task latency.
- **Authority:** Determine the authoritative source for task latency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by task latency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-033: throughput — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-034: throughput — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-035: throughput — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-036: throughput — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-037: throughput — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-038: throughput — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-039: throughput — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-040: throughput — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **throughput**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to throughput.
- **Authority:** Determine the authoritative source for throughput and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by throughput.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-041: concurrency — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-042: concurrency — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-043: concurrency — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-044: concurrency — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-045: concurrency — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-046: concurrency — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-047: concurrency — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-048: concurrency — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **concurrency**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to concurrency.
- **Authority:** Determine the authoritative source for concurrency and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by concurrency.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-049: CPU utilization — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-050: CPU utilization — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-051: CPU utilization — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-052: CPU utilization — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-053: CPU utilization — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-054: CPU utilization — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-055: CPU utilization — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-056: CPU utilization — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **cpu utilization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cpu utilization.
- **Authority:** Determine the authoritative source for cpu utilization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cpu utilization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-057: memory footprint — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-058: memory footprint — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-059: memory footprint — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-060: memory footprint — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-061: memory footprint — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-062: memory footprint — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-063: memory footprint — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-064: memory footprint — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **memory footprint**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to memory footprint.
- **Authority:** Determine the authoritative source for memory footprint and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by memory footprint.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-065: allocations and garbage collection — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-066: allocations and garbage collection — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-067: allocations and garbage collection — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-068: allocations and garbage collection — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-069: allocations and garbage collection — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-070: allocations and garbage collection — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-071: allocations and garbage collection — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-072: allocations and garbage collection — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **allocations and garbage collection**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to allocations and garbage collection.
- **Authority:** Determine the authoritative source for allocations and garbage collection and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by allocations and garbage collection.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-073: disk I/O — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-074: disk I/O — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-075: disk I/O — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-076: disk I/O — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-077: disk I/O — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-078: disk I/O — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-079: disk I/O — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-080: disk I/O — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **disk i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to disk i/o.
- **Authority:** Determine the authoritative source for disk i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by disk i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-081: network I/O — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-082: network I/O — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-083: network I/O — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-084: network I/O — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-085: network I/O — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-086: network I/O — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-087: network I/O — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-088: network I/O — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **network i/o**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network i/o.
- **Authority:** Determine the authoritative source for network i/o and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network i/o.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-089: database queries — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-090: database queries — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-091: database queries — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-092: database queries — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-093: database queries — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-094: database queries — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-095: database queries — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-096: database queries — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **database queries**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database queries.
- **Authority:** Determine the authoritative source for database queries and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database queries.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-097: indexes — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-098: indexes — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-099: indexes — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-100: indexes — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-101: indexes — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-102: indexes — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-103: indexes — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-104: indexes — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-105: caching — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-106: caching — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-107: caching — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-108: caching — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-109: caching — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-110: caching — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-111: caching — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-112: caching — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **caching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to caching.
- **Authority:** Determine the authoritative source for caching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by caching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-113: serialization — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-114: serialization — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-115: serialization — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-116: serialization — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-117: serialization — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-118: serialization — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-119: serialization — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-120: serialization — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **serialization**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to serialization.
- **Authority:** Determine the authoritative source for serialization and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by serialization.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-121: parsing — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-122: parsing — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-123: parsing — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-124: parsing — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-125: parsing — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-126: parsing — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-127: parsing — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-128: parsing — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **parsing**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to parsing.
- **Authority:** Determine the authoritative source for parsing and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by parsing.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-129: compression — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-130: compression — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-131: compression — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-132: compression — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-133: compression — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-134: compression — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-135: compression — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-136: compression — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **compression**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to compression.
- **Authority:** Determine the authoritative source for compression and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by compression.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-137: logging — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-138: logging — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-139: logging — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-140: logging — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-141: logging — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-142: logging — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-143: logging — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-144: logging — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **logging**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging.
- **Authority:** Determine the authoritative source for logging and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-145: background jobs — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-146: background jobs — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-147: background jobs — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-148: background jobs — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-149: background jobs — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-150: background jobs — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-151: background jobs — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-152: background jobs — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **background jobs**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to background jobs.
- **Authority:** Determine the authoritative source for background jobs and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by background jobs.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-153: queues and batching — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-154: queues and batching — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-155: queues and batching — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-156: queues and batching — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-157: queues and batching — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-158: queues and batching — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-159: queues and batching — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-160: queues and batching — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **queues and batching**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queues and batching.
- **Authority:** Determine the authoritative source for queues and batching and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queues and batching.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-161: locks and contention — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-162: locks and contention — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-163: locks and contention — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-164: locks and contention — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-165: locks and contention — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-166: locks and contention — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-167: locks and contention — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-168: locks and contention — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **locks and contention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to locks and contention.
- **Authority:** Determine the authoritative source for locks and contention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by locks and contention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-169: async blocking — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-170: async blocking — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-171: async blocking — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-172: async blocking — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-173: async blocking — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-174: async blocking — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-175: async blocking — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-176: async blocking — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **async blocking**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to async blocking.
- **Authority:** Determine the authoritative source for async blocking and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by async blocking.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-177: frontend bundles and rendering — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-178: frontend bundles and rendering — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-179: frontend bundles and rendering — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-180: frontend bundles and rendering — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-181: frontend bundles and rendering — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-182: frontend bundles and rendering — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-183: frontend bundles and rendering — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-184: frontend bundles and rendering — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **frontend bundles and rendering**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to frontend bundles and rendering.
- **Authority:** Determine the authoritative source for frontend bundles and rendering and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by frontend bundles and rendering.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-185: container image size — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-186: container image size — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-187: container image size — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-188: container image size — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-189: container image size — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-190: container image size — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-191: container image size — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-192: container image size — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **container image size**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container image size.
- **Authority:** Determine the authoritative source for container image size and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container image size.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-193: build duration — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-194: build duration — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-195: build duration — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-196: build duration — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-197: build duration — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-198: build duration — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-199: build duration — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-200: build duration — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **build duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to build duration.
- **Authority:** Determine the authoritative source for build duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by build duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-201: test duration — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-202: test duration — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-203: test duration — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-204: test duration — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-205: test duration — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-206: test duration — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-207: test duration — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-208: test duration — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **test duration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test duration.
- **Authority:** Determine the authoritative source for test duration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test duration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-209: cloud and infrastructure cost — workload relevance

- **Control intent:** Establish reliable evidence about **workload relevance** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to workload relevance.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about workload relevance could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-210: cloud and infrastructure cost — measurement quality

- **Control intent:** Establish reliable evidence about **measurement quality** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to measurement quality.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about measurement quality could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-211: cloud and infrastructure cost — latency and throughput

- **Control intent:** Establish reliable evidence about **latency and throughput** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to latency and throughput.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about latency and throughput could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-212: cloud and infrastructure cost — CPU and allocation

- **Control intent:** Establish reliable evidence about **cpu and allocation** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cpu and allocation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cpu and allocation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-213: cloud and infrastructure cost — I/O and network

- **Control intent:** Establish reliable evidence about **i/o and network** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to i/o and network.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about i/o and network could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-214: cloud and infrastructure cost — storage and query behavior

- **Control intent:** Establish reliable evidence about **storage and query behavior** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to storage and query behavior.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about storage and query behavior could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-215: cloud and infrastructure cost — cost and capacity

- **Control intent:** Establish reliable evidence about **cost and capacity** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to cost and capacity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about cost and capacity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### PERFORMANCE-AND-EFFICIENCY-REVIEW-PROMPT-RC-216: cloud and infrastructure cost — regression budget

- **Control intent:** Establish reliable evidence about **regression budget** for **cloud and infrastructure cost**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cloud and infrastructure cost.
- **Authority:** Determine the authoritative source for cloud and infrastructure cost and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to regression budget.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cloud and infrastructure cost.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about regression budget could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.


## Mandatory Performance and Efficiency Review Prompt Report Output Contract

Produce a report titled **Performance and Efficiency Review Prompt Report** with the following sections:

### 1. Goals and workloads

Document goals and workloads using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 2. Environment and baseline

Document environment and baseline using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 3. Static hypotheses

Document static hypotheses using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 4. Measurement plan

Document measurement plan using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 5. Measured bottlenecks

Document measured bottlenecks using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 6. Resource breakdown

Document resource breakdown using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 7. Recommendations

Document recommendations using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 8. Changes applied

Document changes applied using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 9. Before and after results

Document before and after results using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 10. Regression budgets

Document regression budgets using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 11. Cost implications

Document cost implications using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 12. Unmeasured areas

Document unmeasured areas using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

## Final Quality Gate

- Confirm every material claim has evidence or an explicit inference label.
- Confirm no secret or private data is exposed.
- Confirm the reported scope matches the inspected scope.
- Confirm unsupported files, platforms, environments, and tool failures are listed.
- Confirm proposed work is separated from applied work.
- Confirm exact verification outcomes are included.
- Confirm no completion claim exceeds available evidence.
- End with `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or `INCOMPLETE` and a concise rationale.
