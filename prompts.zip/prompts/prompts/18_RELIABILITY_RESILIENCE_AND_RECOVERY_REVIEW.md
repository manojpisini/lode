---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-18
sequence: 18
title: Reliability, Resilience, and Recovery Review
slug: reliability-resilience-and-recovery-review
canonical_path: prompts/18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md
category: operations
prompt_type: review
status: stable
description: Evaluates behavior under partial failure, overload, interruption, duplication, corruption, restart, and recovery.
language_agnostic: true
self_contained: true
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: reports_and_approved_reliability_changes
risk_level: critical
requires:
- UPPS-03
- UPPS-08
- UPPS-16
recommended_before:
- UPPS-19
- UPPS-20
- UPPS-21
- UPPS-23
recommended_after:
- UPPS-08
- UPPS-16
related_prompts:
- UPPS-16
- UPPS-17
- UPPS-20
- UPPS-21
expected_outputs:
- failure_model
- resilience_findings
- recovery_plan
- fault_injection_plan
tags:
- reliability
- resilience
- recovery
- failure-analysis
last_updated: '2026-07-11'
minimum_content_lines: 1000
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: reports/reliability/reliability_resilience_recovery_report.md
    format: markdown
    purpose: Reliability, resilience, failure, and recovery report.
    required_when_writing: true
  supporting_artifacts:
  - path: artifacts/reliability/failure_mode_inventory.json
    format: json
    purpose: Machine-readable failure-mode and dependency-outage inventory.
    required_when_writing: true
  - path: artifacts/reliability/resilience_scorecard.json
    format: json
    purpose: Reliability and recoverability scorecard.
    required_when_writing: true
  - path: plans/reliability/recovery_plan.md
    format: markdown
    purpose: Recovery, reconciliation, backup, and restoration plan.
    required_when_writing: true
  - path: plans/reliability/fault_injection_plan.md
    format: markdown
    purpose: Safe fault-injection and recovery-verification plan.
    required_when_writing: true
  - path: logs/reliability/fault_injection_log.txt
    format: text
    purpose: Authorized fault-injection execution transcript.
    required_when_writing: false
---

# Reliability, Resilience, and Recovery Review

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./reports/reliability/reliability_resilience_recovery_report.md` | `markdown` | Reliability, resilience, failure, and recovery report. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./artifacts/reliability/failure_mode_inventory.json` | `json` | Machine-readable failure-mode and dependency-outage inventory. | Required when writing |
| `./artifacts/reliability/resilience_scorecard.json` | `json` | Reliability and recoverability scorecard. | Required when writing |
| `./plans/reliability/recovery_plan.md` | `markdown` | Recovery, reconciliation, backup, and restoration plan. | Required when writing |
| `./plans/reliability/fault_injection_plan.md` | `markdown` | Safe fault-injection and recovery-verification plan. | Required when writing |
| `./logs/reliability/fault_injection_log.txt` | `text` | Authorized fault-injection execution transcript. | When applicable |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_18_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_18
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

You are a reliability engineer and failure-analysis specialist.

## Mission

Evaluate behavior under partial failure, overload, interruption, duplication, corruption, restart, and recovery.

## Universal Self-Contained Execution Contract

This prompt is intentionally self-contained. Apply every rule in this contract unless a later section is explicitly stricter.

### A. Operating Modes

Select exactly one mode and state it at the beginning of the report.

- `AUDIT_ONLY`: inspect and report. Do not modify repository files.
- `PLAN_ONLY`: inspect and produce an implementation plan. Do not modify repository files.
- `APPLY_SAFE`: apply only low-risk, reversible, behavior-preserving changes supported by direct evidence.
- `APPLY_APPROVED`: apply the specific higher-impact changes explicitly authorized by the user.
- `VERIFY_ONLY`: execute approved verification procedures against an existing change set without broadening scope.

Default to `AUDIT_ONLY` when the user does not explicitly authorize modifications.

### B. Required Project Inputs

Resolve and record the following inputs before work begins:

```yaml
PROJECT_ROOT: "."
PROJECT_NAME: ""
PROJECT_TYPE: ""
PROJECT_PURPOSE: ""
MODE: "AUDIT_ONLY"
SCOPE: "entire repository"
PRIORITY_AREAS: []
EXCLUSIONS: []
PROTECTED_PATHS: []
SUPPORTED_PLATFORMS: []
DEPLOYMENT_TARGETS: []
NETWORK_ACCESS: false
ALLOW_EXTERNAL_LOOKUPS: false
ALLOW_INSTALLS: false
ALLOW_FILE_MODIFICATION: false
ALLOW_FILE_DELETION: false
ALLOW_RENAMES_OR_MOVES: false
ALLOW_DEPENDENCY_CHANGES: false
ALLOW_DATA_MUTATION: false
ALLOW_MIGRATIONS: false
ALLOW_PUBLIC_CONTRACT_CHANGES: false
ALLOW_SERVICE_STARTUP: false
ALLOW_UNKNOWN_BINARY_EXECUTION: false
REQUIRED_COMMANDS: []
FORBIDDEN_COMMANDS: []
ACCEPTANCE_CRITERIA: []
OUTPUT_DIRECTORY: ""
ADDITIONAL_CONTEXT: ""
```

Blank values are unknown. They are never permission to invent or broaden scope.

### C. Evidence Rules

1. Inspect before concluding.
2. Cite file paths, symbols, line ranges, configuration keys, command output, or reproducible observations.
3. Mark important statements as `Verified`, `Inferred`, `Proposed`, `Unknown`, or `Not Applicable` when ambiguity matters.
4. Never treat a file’s existence as proof that it is active.
5. Never treat a textual reference search as complete reachability analysis.
6. Never treat a passing test as proof of total correctness.
7. Never treat comments, TODOs, examples, issue references, or roadmap notes as implemented behavior without corroboration.
8. Never claim complete coverage without an inventory that accounts for exclusions, opaque files, generated files, binaries, archives, unsupported formats, and tool failures.
9. When sources conflict, identify the conflict, rank likely authority, and preserve unresolved ambiguity.
10. Record exact commands and exact outcomes; do not paraphrase failed verification into success.

### D. Safety and Permission Rules

1. Do not access production systems unless explicitly authorized.
2. Do not access networks or external services unless explicitly authorized.
3. Do not reveal complete secrets, private keys, tokens, credentials, personal data, or sensitive connection strings.
4. Do not execute unknown binaries or untrusted scripts.
5. Do not install or upgrade dependencies unless explicitly authorized.
6. Do not delete, rename, move, or overwrite files unless explicitly authorized.
7. Do not mutate databases, indexes, queues, object stores, caches, or user data unless explicitly authorized.
8. Do not rewrite migration history unless a project-specific authority explicitly permits it.
9. Do not change public APIs, CLI behavior, configuration keys, events, schemas, serialized formats, package exports, or supported paths without explicit authorization and compatibility analysis.
10. Do not discard or overwrite pre-existing local changes.
11. Prefer reversible, reviewable, minimal changes.
12. Stop applying changes when unexpected regression, data risk, contract drift, or unexplained scope expansion appears.

### E. Repository Ground Truth

Before domain-specific work, establish or consume a repository inventory containing:

- Repository boundaries and nested repositories
- Version-control state
- Languages, runtimes, frameworks, and package managers
- Build systems and task runners
- Entry points
- Components, packages, modules, services, and workspaces
- Public and internal contracts
- Configuration sources and precedence
- Data stores and persistent state
- External services
- Tests and verification commands
- CI/CD and deployment paths
- Generated, vendored, binary, archive, cache, and runtime-output areas
- Existing documentation
- Security-sensitive surfaces
- Unknown or inaccessible areas

### F. Baseline Rules

Before modifications, record:

- Current revision and branch
- Dirty, staged, modified, and untracked state
- Existing generated artifacts
- Existing build outcome
- Existing test outcome
- Existing lint, formatting, type-check, and static-analysis outcome
- Existing service health where applicable
- Known pre-existing failures
- Supported platform assumptions
- Tool versions used

Do not attribute pre-existing failures to new work.

### G. Change Discipline

For each proposed or applied change:

- State the objective.
- State the evidence.
- State the affected files and contracts.
- State compatibility risk.
- State data and security implications.
- State verification.
- State rollback.
- Keep mechanical changes separate from semantic changes.
- Keep dependency changes separate from cleanup.
- Keep migrations separate from unrelated refactors.
- Keep documentation corrections traceable to source evidence.
- Avoid unrelated formatting.

### H. Verification Discipline

Use the narrowest relevant check first, followed by broader available checks.

Applicable checks may include:

- Parser or syntax validation
- Formatting check
- Lint
- Type check
- Unit tests
- Component tests
- Integration tests
- Contract tests
- End-to-end tests
- Security tests
- Fuzz/property tests
- Migration checks
- Packaging and installation
- Container/image build
- Smoke tests
- API/CLI schema comparison
- Documentation link and example validation
- Performance budgets
- Platform matrix
- Data integrity checks

A skipped, unavailable, unauthorized, or failed check must be reported explicitly.

### I. Finding Classification

Use both impact and confidence.

Impact:
- `Critical`
- `High`
- `Medium`
- `Low`
- `Informational`

Confidence:
- `Confirmed`
- `High`
- `Medium`
- `Low`

Status:
- `Confirmed Issue`
- `Likely Issue`
- `Risk`
- `Hardening Opportunity`
- `Documentation Gap`
- `Needs Manual Review`
- `Not Applicable`
- `False Positive`

### J. Completion States

Use exactly one:

- `PASS`
- `PASS_WITH_CONDITIONS`
- `FAIL`
- `INCOMPLETE`

`PASS` requires direct evidence that all requested deliverables and mandatory checks completed without unresolved blockers.

`PASS_WITH_CONDITIONS` means no confirmed blocker remains, but named limitations, deferred checks, or accepted risks remain.

`FAIL` means a blocker, regression, unsafe condition, or acceptance-criterion failure is confirmed.

`INCOMPLETE` means required evidence, access, tooling, or scope coverage was unavailable.

### K. Mandatory Final Report Sections

Every final report must include:

1. Objective
2. Scope
3. Mode and permissions
4. Assumptions
5. Repository evidence used
6. Coverage and exclusions
7. Baseline
8. Findings
9. Proposed or applied changes
10. Verification
11. Compatibility impact
12. Security and data impact
13. Remaining risks
14. Unknowns
15. Rollback or recovery information
16. Prioritized next actions
17. Completion state

## Reliability Method

Model failure, not only the happy path.

Trace critical workflows through timeout, cancellation, retry, duplicate delivery, reordering, partial write, dependency outage, overload, restart, migration interruption, disk pressure, memory pressure, and operator intervention.

Review idempotency, backpressure, reconciliation, backup, restore, rebuild, disaster recovery, RPO, RTO, and post-recovery validation.

## Exhaustive Review Control Catalog

Apply every applicable control below to the Reliability Resilience and Recovery Review Prompt review. A control may be marked `Not Applicable` only after applicability is considered and the reason is recorded.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-001: application process — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-002: application process — detection

- **Control intent:** Establish reliable evidence about **detection** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-003: application process — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-004: application process — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-005: application process — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-006: application process — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-007: application process — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-008: application process — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **application process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to application process.
- **Authority:** Determine the authoritative source for application process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by application process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-009: worker process — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-010: worker process — detection

- **Control intent:** Establish reliable evidence about **detection** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-011: worker process — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-012: worker process — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-013: worker process — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-014: worker process — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-015: worker process — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-016: worker process — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **worker process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to worker process.
- **Authority:** Determine the authoritative source for worker process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by worker process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-017: scheduler — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-018: scheduler — detection

- **Control intent:** Establish reliable evidence about **detection** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-019: scheduler — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-020: scheduler — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-021: scheduler — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-022: scheduler — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-023: scheduler — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-024: scheduler — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **scheduler**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to scheduler.
- **Authority:** Determine the authoritative source for scheduler and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by scheduler.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-025: database — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-026: database — detection

- **Control intent:** Establish reliable evidence about **detection** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-027: database — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-028: database — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-029: database — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-030: database — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-031: database — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-032: database — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database.
- **Authority:** Determine the authoritative source for database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-033: cache — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-034: cache — detection

- **Control intent:** Establish reliable evidence about **detection** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-035: cache — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-036: cache — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-037: cache — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-038: cache — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-039: cache — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-040: cache — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-041: queue — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-042: queue — detection

- **Control intent:** Establish reliable evidence about **detection** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-043: queue — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-044: queue — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-045: queue — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-046: queue — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-047: queue — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-048: queue — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-049: object store — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-050: object store — detection

- **Control intent:** Establish reliable evidence about **detection** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-051: object store — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-052: object store — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-053: object store — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-054: object store — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-055: object store — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-056: object store — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **object store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object store.
- **Authority:** Determine the authoritative source for object store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-057: search or vector index — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-058: search or vector index — detection

- **Control intent:** Establish reliable evidence about **detection** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-059: search or vector index — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-060: search or vector index — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-061: search or vector index — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-062: search or vector index — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-063: search or vector index — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-064: search or vector index — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **search or vector index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search or vector index.
- **Authority:** Determine the authoritative source for search or vector index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search or vector index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-065: external API — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-066: external API — detection

- **Control intent:** Establish reliable evidence about **detection** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-067: external API — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-068: external API — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-069: external API — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-070: external API — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-071: external API — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-072: external API — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **external api**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to external api.
- **Authority:** Determine the authoritative source for external api and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by external api.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-073: network — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-074: network — detection

- **Control intent:** Establish reliable evidence about **detection** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-075: network — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-076: network — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-077: network — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-078: network — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-079: network — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-080: network — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **network**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network.
- **Authority:** Determine the authoritative source for network and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-081: filesystem — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-082: filesystem — detection

- **Control intent:** Establish reliable evidence about **detection** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-083: filesystem — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-084: filesystem — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-085: filesystem — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-086: filesystem — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-087: filesystem — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-088: filesystem — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **filesystem**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem.
- **Authority:** Determine the authoritative source for filesystem and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-089: configuration provider — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-090: configuration provider — detection

- **Control intent:** Establish reliable evidence about **detection** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-091: configuration provider — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-092: configuration provider — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-093: configuration provider — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-094: configuration provider — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-095: configuration provider — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-096: configuration provider — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **configuration provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration provider.
- **Authority:** Determine the authoritative source for configuration provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-097: secret provider — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-098: secret provider — detection

- **Control intent:** Establish reliable evidence about **detection** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-099: secret provider — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-100: secret provider — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-101: secret provider — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-102: secret provider — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-103: secret provider — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-104: secret provider — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **secret provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret provider.
- **Authority:** Determine the authoritative source for secret provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-105: authentication provider — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-106: authentication provider — detection

- **Control intent:** Establish reliable evidence about **detection** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-107: authentication provider — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-108: authentication provider — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-109: authentication provider — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-110: authentication provider — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-111: authentication provider — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-112: authentication provider — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **authentication provider**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication provider.
- **Authority:** Determine the authoritative source for authentication provider and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication provider.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-113: deployment platform — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-114: deployment platform — detection

- **Control intent:** Establish reliable evidence about **detection** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-115: deployment platform — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-116: deployment platform — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-117: deployment platform — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-118: deployment platform — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-119: deployment platform — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-120: deployment platform — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **deployment platform**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deployment platform.
- **Authority:** Determine the authoritative source for deployment platform and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deployment platform.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-121: startup — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-122: startup — detection

- **Control intent:** Establish reliable evidence about **detection** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-123: startup — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-124: startup — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-125: startup — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-126: startup — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-127: startup — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-128: startup — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **startup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to startup.
- **Authority:** Determine the authoritative source for startup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by startup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-129: shutdown — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-130: shutdown — detection

- **Control intent:** Establish reliable evidence about **detection** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-131: shutdown — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-132: shutdown — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-133: shutdown — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-134: shutdown — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-135: shutdown — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-136: shutdown — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **shutdown**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to shutdown.
- **Authority:** Determine the authoritative source for shutdown and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by shutdown.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-137: rolling upgrade — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-138: rolling upgrade — detection

- **Control intent:** Establish reliable evidence about **detection** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-139: rolling upgrade — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-140: rolling upgrade — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-141: rolling upgrade — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-142: rolling upgrade — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-143: rolling upgrade — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-144: rolling upgrade — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **rolling upgrade**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rolling upgrade.
- **Authority:** Determine the authoritative source for rolling upgrade and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rolling upgrade.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-145: migration — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-146: migration — detection

- **Control intent:** Establish reliable evidence about **detection** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-147: migration — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-148: migration — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-149: migration — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-150: migration — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-151: migration — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-152: migration — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-153: backup — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-154: backup — detection

- **Control intent:** Establish reliable evidence about **detection** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-155: backup — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-156: backup — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-157: backup — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-158: backup — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-159: backup — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-160: backup — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-161: restore — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-162: restore — detection

- **Control intent:** Establish reliable evidence about **detection** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-163: restore — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-164: restore — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-165: restore — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-166: restore — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-167: restore — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-168: restore — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **restore**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to restore.
- **Authority:** Determine the authoritative source for restore and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by restore.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-169: rebuild — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-170: rebuild — detection

- **Control intent:** Establish reliable evidence about **detection** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-171: rebuild — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-172: rebuild — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-173: rebuild — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-174: rebuild — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-175: rebuild — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-176: rebuild — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **rebuild**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild.
- **Authority:** Determine the authoritative source for rebuild and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-177: retry loop — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-178: retry loop — detection

- **Control intent:** Establish reliable evidence about **detection** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-179: retry loop — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-180: retry loop — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-181: retry loop — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-182: retry loop — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-183: retry loop — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-184: retry loop — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **retry loop**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry loop.
- **Authority:** Determine the authoritative source for retry loop and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry loop.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-185: timeout chain — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-186: timeout chain — detection

- **Control intent:** Establish reliable evidence about **detection** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-187: timeout chain — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-188: timeout chain — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-189: timeout chain — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-190: timeout chain — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-191: timeout chain — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-192: timeout chain — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **timeout chain**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to timeout chain.
- **Authority:** Determine the authoritative source for timeout chain and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by timeout chain.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-193: cancellation path — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-194: cancellation path — detection

- **Control intent:** Establish reliable evidence about **detection** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-195: cancellation path — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-196: cancellation path — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-197: cancellation path — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-198: cancellation path — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-199: cancellation path — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-200: cancellation path — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **cancellation path**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cancellation path.
- **Authority:** Determine the authoritative source for cancellation path and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cancellation path.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-201: overload condition — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-202: overload condition — detection

- **Control intent:** Establish reliable evidence about **detection** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-203: overload condition — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-204: overload condition — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-205: overload condition — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-206: overload condition — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-207: overload condition — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-208: overload condition — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **overload condition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to overload condition.
- **Authority:** Determine the authoritative source for overload condition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by overload condition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-209: data corruption — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-210: data corruption — detection

- **Control intent:** Establish reliable evidence about **detection** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-211: data corruption — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-212: data corruption — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-213: data corruption — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-214: data corruption — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-215: data corruption — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-216: data corruption — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **data corruption**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data corruption.
- **Authority:** Determine the authoritative source for data corruption and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data corruption.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-217: operator intervention — failure mode

- **Control intent:** Establish reliable evidence about **failure mode** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to failure mode.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about failure mode could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-218: operator intervention — detection

- **Control intent:** Establish reliable evidence about **detection** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to detection.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about detection could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-219: operator intervention — timeout and cancellation

- **Control intent:** Establish reliable evidence about **timeout and cancellation** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to timeout and cancellation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about timeout and cancellation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-220: operator intervention — retry and idempotency

- **Control intent:** Establish reliable evidence about **retry and idempotency** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retry and idempotency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retry and idempotency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-221: operator intervention — partial state and consistency

- **Control intent:** Establish reliable evidence about **partial state and consistency** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to partial state and consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about partial state and consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-222: operator intervention — overload and backpressure

- **Control intent:** Establish reliable evidence about **overload and backpressure** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to overload and backpressure.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about overload and backpressure could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-223: operator intervention — recovery and reconciliation

- **Control intent:** Establish reliable evidence about **recovery and reconciliation** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to recovery and reconciliation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about recovery and reconciliation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### RELIABILITY-RESILIENCE-AND-RECOVERY-REVIEW-PROMPT-RC-224: operator intervention — operational ownership

- **Control intent:** Establish reliable evidence about **operational ownership** for **operator intervention**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to operator intervention.
- **Authority:** Determine the authoritative source for operator intervention and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to operational ownership.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by operator intervention.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about operational ownership could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.


## Mandatory Reliability Resilience and Recovery Review Prompt Report Output Contract

Produce a report titled **Reliability Resilience and Recovery Review Prompt Report** with the following sections:

### 1. System and failure model

Document system and failure model using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 2. Critical workflows

Document critical workflows using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 3. Timeout retry and idempotency

Document timeout retry and idempotency using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 4. State under failure

Document state under failure using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 5. Dependency outages

Document dependency outages using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 6. Overload and backpressure

Document overload and backpressure using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 7. Startup shutdown and restart

Document startup shutdown and restart using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 8. Backup restore and recovery

Document backup restore and recovery using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 9. Fault-injection plan

Document fault-injection plan using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 10. Prioritized improvements

Document prioritized improvements using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 11. Operational assumptions

Document operational assumptions using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 12. Unknowns

Document unknowns using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

## Final Quality Gate

- Confirm every material claim has evidence or an explicit inference label.
- Confirm no secret or private data is exposed.
- Confirm the reported scope matches the inspected scope.
- Confirm unsupported files, platforms, environments, and tool failures are listed.
- Confirm proposed work is separated from applied work.
- Confirm exact verification outcomes are included.
- Confirm no completion claim exceeds available evidence.
- End with `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or `INCOMPLETE` and a concise rationale.
