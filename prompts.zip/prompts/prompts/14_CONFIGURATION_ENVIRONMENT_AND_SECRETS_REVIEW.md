---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-14
sequence: 14
title: Configuration, Environment, and Secrets Review
slug: configuration-environment-and-secrets-review
canonical_path: prompts/14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md
category: security
prompt_type: review
status: stable
description: Reviews configuration sources, precedence, validation, environment parity, defaults, and secret lifecycle without exposing sensitive values.
language_agnostic: true
self_contained: true
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: reports_and_approved_configuration_changes
risk_level: critical
requires:
- UPPS-03
recommended_before:
- UPPS-19
- UPPS-23
recommended_after:
- UPPS-05
related_prompts:
- UPPS-05
- UPPS-13
- UPPS-19
- UPPS-20
expected_outputs:
- configuration_map
- secret_handling_assessment
- environment_drift_report
tags:
- configuration
- environment
- secrets
- validation
last_updated: '2026-07-11'
minimum_content_lines: 1000
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: reports/configuration/configuration_environment_secrets_report.md
    format: markdown
    purpose: Configuration, environment parity, defaults, and secrets report.
    required_when_writing: true
  supporting_artifacts:
  - path: artifacts/configuration/configuration_inventory.json
    format: json
    purpose: Machine-readable configuration-key inventory.
    required_when_writing: true
  - path: artifacts/configuration/environment_matrix.json
    format: json
    purpose: Development, CI, staging, production, and platform comparison.
    required_when_writing: true
  - path: docs/reference/configuration_reference.md
    format: markdown
    purpose: Maintained user-facing configuration reference.
    required_when_writing: false
  - path: plans/configuration/configuration_hardening_plan.md
    format: markdown
    purpose: Configuration and secret-handling hardening plan.
    required_when_writing: true
---

# Configuration, Environment, and Secrets Review

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./reports/configuration/configuration_environment_secrets_report.md` | `markdown` | Configuration, environment parity, defaults, and secrets report. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./artifacts/configuration/configuration_inventory.json` | `json` | Machine-readable configuration-key inventory. | Required when writing |
| `./artifacts/configuration/environment_matrix.json` | `json` | Development, CI, staging, production, and platform comparison. | Required when writing |
| `./docs/reference/configuration_reference.md` | `markdown` | Maintained user-facing configuration reference. | When applicable |
| `./plans/configuration/configuration_hardening_plan.md` | `markdown` | Configuration and secret-handling hardening plan. | Required when writing |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_14_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_14
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

You are a configuration architect, platform engineer, and secrets-management reviewer.

## Mission

Make configuration deterministic, validated, documented, environment-safe, and secure.

## Universal Self-Contained Execution Contract

This prompt is intentionally self-contained. Apply every rule in this contract unless a later section is explicitly stricter.

### A. Operating Modes

Select exactly one mode and state it at the beginning of the report.

- `AUDIT_ONLY`: inspect and report. Do not modify repository files.
- `PLAN_ONLY`: inspect and produce an implementation plan. Do not modify repository files.
- `APPLY_SAFE`: apply only low-risk, reversible, behavior-preserving changes supported by direct evidence.
- `APPLY_APPROVED`: apply the specific higher-impact changes explicitly authorized by the user.
- `VERIFY_ONLY`: execute approved verification procedures against an existing change set without broadening scope.

Default to `AUDIT_ONLY` when the user does not explicitly authorize modifications.

### B. Required Project Inputs

Resolve and record the following inputs before work begins:

```yaml
PROJECT_ROOT: "."
PROJECT_NAME: ""
PROJECT_TYPE: ""
PROJECT_PURPOSE: ""
MODE: "AUDIT_ONLY"
SCOPE: "entire repository"
PRIORITY_AREAS: []
EXCLUSIONS: []
PROTECTED_PATHS: []
SUPPORTED_PLATFORMS: []
DEPLOYMENT_TARGETS: []
NETWORK_ACCESS: false
ALLOW_EXTERNAL_LOOKUPS: false
ALLOW_INSTALLS: false
ALLOW_FILE_MODIFICATION: false
ALLOW_FILE_DELETION: false
ALLOW_RENAMES_OR_MOVES: false
ALLOW_DEPENDENCY_CHANGES: false
ALLOW_DATA_MUTATION: false
ALLOW_MIGRATIONS: false
ALLOW_PUBLIC_CONTRACT_CHANGES: false
ALLOW_SERVICE_STARTUP: false
ALLOW_UNKNOWN_BINARY_EXECUTION: false
REQUIRED_COMMANDS: []
FORBIDDEN_COMMANDS: []
ACCEPTANCE_CRITERIA: []
OUTPUT_DIRECTORY: ""
ADDITIONAL_CONTEXT: ""
```

Blank values are unknown. They are never permission to invent or broaden scope.

### C. Evidence Rules

1. Inspect before concluding.
2. Cite file paths, symbols, line ranges, configuration keys, command output, or reproducible observations.
3. Mark important statements as `Verified`, `Inferred`, `Proposed`, `Unknown`, or `Not Applicable` when ambiguity matters.
4. Never treat a file’s existence as proof that it is active.
5. Never treat a textual reference search as complete reachability analysis.
6. Never treat a passing test as proof of total correctness.
7. Never treat comments, TODOs, examples, issue references, or roadmap notes as implemented behavior without corroboration.
8. Never claim complete coverage without an inventory that accounts for exclusions, opaque files, generated files, binaries, archives, unsupported formats, and tool failures.
9. When sources conflict, identify the conflict, rank likely authority, and preserve unresolved ambiguity.
10. Record exact commands and exact outcomes; do not paraphrase failed verification into success.

### D. Safety and Permission Rules

1. Do not access production systems unless explicitly authorized.
2. Do not access networks or external services unless explicitly authorized.
3. Do not reveal complete secrets, private keys, tokens, credentials, personal data, or sensitive connection strings.
4. Do not execute unknown binaries or untrusted scripts.
5. Do not install or upgrade dependencies unless explicitly authorized.
6. Do not delete, rename, move, or overwrite files unless explicitly authorized.
7. Do not mutate databases, indexes, queues, object stores, caches, or user data unless explicitly authorized.
8. Do not rewrite migration history unless a project-specific authority explicitly permits it.
9. Do not change public APIs, CLI behavior, configuration keys, events, schemas, serialized formats, package exports, or supported paths without explicit authorization and compatibility analysis.
10. Do not discard or overwrite pre-existing local changes.
11. Prefer reversible, reviewable, minimal changes.
12. Stop applying changes when unexpected regression, data risk, contract drift, or unexplained scope expansion appears.

### E. Repository Ground Truth

Before domain-specific work, establish or consume a repository inventory containing:

- Repository boundaries and nested repositories
- Version-control state
- Languages, runtimes, frameworks, and package managers
- Build systems and task runners
- Entry points
- Components, packages, modules, services, and workspaces
- Public and internal contracts
- Configuration sources and precedence
- Data stores and persistent state
- External services
- Tests and verification commands
- CI/CD and deployment paths
- Generated, vendored, binary, archive, cache, and runtime-output areas
- Existing documentation
- Security-sensitive surfaces
- Unknown or inaccessible areas

### F. Baseline Rules

Before modifications, record:

- Current revision and branch
- Dirty, staged, modified, and untracked state
- Existing generated artifacts
- Existing build outcome
- Existing test outcome
- Existing lint, formatting, type-check, and static-analysis outcome
- Existing service health where applicable
- Known pre-existing failures
- Supported platform assumptions
- Tool versions used

Do not attribute pre-existing failures to new work.

### G. Change Discipline

For each proposed or applied change:

- State the objective.
- State the evidence.
- State the affected files and contracts.
- State compatibility risk.
- State data and security implications.
- State verification.
- State rollback.
- Keep mechanical changes separate from semantic changes.
- Keep dependency changes separate from cleanup.
- Keep migrations separate from unrelated refactors.
- Keep documentation corrections traceable to source evidence.
- Avoid unrelated formatting.

### H. Verification Discipline

Use the narrowest relevant check first, followed by broader available checks.

Applicable checks may include:

- Parser or syntax validation
- Formatting check
- Lint
- Type check
- Unit tests
- Component tests
- Integration tests
- Contract tests
- End-to-end tests
- Security tests
- Fuzz/property tests
- Migration checks
- Packaging and installation
- Container/image build
- Smoke tests
- API/CLI schema comparison
- Documentation link and example validation
- Performance budgets
- Platform matrix
- Data integrity checks

A skipped, unavailable, unauthorized, or failed check must be reported explicitly.

### I. Finding Classification

Use both impact and confidence.

Impact:
- `Critical`
- `High`
- `Medium`
- `Low`
- `Informational`

Confidence:
- `Confirmed`
- `High`
- `Medium`
- `Low`

Status:
- `Confirmed Issue`
- `Likely Issue`
- `Risk`
- `Hardening Opportunity`
- `Documentation Gap`
- `Needs Manual Review`
- `Not Applicable`
- `False Positive`

### J. Completion States

Use exactly one:

- `PASS`
- `PASS_WITH_CONDITIONS`
- `FAIL`
- `INCOMPLETE`

`PASS` requires direct evidence that all requested deliverables and mandatory checks completed without unresolved blockers.

`PASS_WITH_CONDITIONS` means no confirmed blocker remains, but named limitations, deferred checks, or accepted risks remain.

`FAIL` means a blocker, regression, unsafe condition, or acceptance-criterion failure is confirmed.

`INCOMPLETE` means required evidence, access, tooling, or scope coverage was unavailable.

### K. Mandatory Final Report Sections

Every final report must include:

1. Objective
2. Scope
3. Mode and permissions
4. Assumptions
5. Repository evidence used
6. Coverage and exclusions
7. Baseline
8. Findings
9. Proposed or applied changes
10. Verification
11. Compatibility impact
12. Security and data impact
13. Remaining risks
14. Unknowns
15. Rollback or recovery information
16. Prioritized next actions
17. Completion state

## Configuration Method

Inventory every configuration source and reconstruct precedence, merge, validation, reload, deprecation, and failure behavior.

Never print secret values. Review insecure defaults, secret fallbacks, placeholder production values, typo acceptance, environment drift, ambiguous coercion, command-line secret exposure, logging exposure, and rotation capability.

Create a complete key reference with source, type, required status, default, allowed values, sensitivity, scope, consumer, and restart requirement.

## Exhaustive Review Control Catalog

Apply every applicable control below to the Configuration Environment and Secrets Review Prompt review. A control may be marked `Not Applicable` only after applicability is considered and the reason is recorded.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-001: built-in defaults — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-002: built-in defaults — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-003: built-in defaults — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-004: built-in defaults — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-005: built-in defaults — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-006: built-in defaults — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-007: built-in defaults — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-008: built-in defaults — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **built-in defaults**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to built-in defaults.
- **Authority:** Determine the authoritative source for built-in defaults and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by built-in defaults.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-009: configuration files — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-010: configuration files — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-011: configuration files — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-012: configuration files — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-013: configuration files — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-014: configuration files — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-015: configuration files — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-016: configuration files — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **configuration files**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration files.
- **Authority:** Determine the authoritative source for configuration files and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration files.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-017: environment variables — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-018: environment variables — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-019: environment variables — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-020: environment variables — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-021: environment variables — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-022: environment variables — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-023: environment variables — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-024: environment variables — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **environment variables**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to environment variables.
- **Authority:** Determine the authoritative source for environment variables and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by environment variables.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-025: CLI flags — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-026: CLI flags — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-027: CLI flags — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-028: CLI flags — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-029: CLI flags — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-030: CLI flags — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-031: CLI flags — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-032: CLI flags — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **cli flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cli flags.
- **Authority:** Determine the authoritative source for cli flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cli flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-033: remote configuration — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-034: remote configuration — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-035: remote configuration — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-036: remote configuration — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-037: remote configuration — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-038: remote configuration — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-039: remote configuration — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-040: remote configuration — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **remote configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to remote configuration.
- **Authority:** Determine the authoritative source for remote configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by remote configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-041: feature flags — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-042: feature flags — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-043: feature flags — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-044: feature flags — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-045: feature flags — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-046: feature flags — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-047: feature flags — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-048: feature flags — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **feature flags**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to feature flags.
- **Authority:** Determine the authoritative source for feature flags and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by feature flags.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-049: secret stores — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-050: secret stores — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-051: secret stores — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-052: secret stores — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-053: secret stores — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-054: secret stores — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-055: secret stores — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-056: secret stores — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **secret stores**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to secret stores.
- **Authority:** Determine the authoritative source for secret stores and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by secret stores.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-057: platform settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-058: platform settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-059: platform settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-060: platform settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-061: platform settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-062: platform settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-063: platform settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-064: platform settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **platform settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to platform settings.
- **Authority:** Determine the authoritative source for platform settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by platform settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-065: database-backed settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-066: database-backed settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-067: database-backed settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-068: database-backed settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-069: database-backed settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-070: database-backed settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-071: database-backed settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-072: database-backed settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **database-backed settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to database-backed settings.
- **Authority:** Determine the authoritative source for database-backed settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by database-backed settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-073: generated configuration — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-074: generated configuration — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-075: generated configuration — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-076: generated configuration — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-077: generated configuration — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-078: generated configuration — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-079: generated configuration — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-080: generated configuration — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **generated configuration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated configuration.
- **Authority:** Determine the authoritative source for generated configuration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated configuration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-081: test overrides — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-082: test overrides — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-083: test overrides — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-084: test overrides — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-085: test overrides — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-086: test overrides — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-087: test overrides — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-088: test overrides — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **test overrides**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to test overrides.
- **Authority:** Determine the authoritative source for test overrides and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by test overrides.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-089: development profile — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-090: development profile — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-091: development profile — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-092: development profile — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-093: development profile — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-094: development profile — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-095: development profile — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-096: development profile — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **development profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to development profile.
- **Authority:** Determine the authoritative source for development profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by development profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-097: CI profile — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-098: CI profile — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-099: CI profile — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-100: CI profile — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-101: CI profile — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-102: CI profile — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-103: CI profile — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-104: CI profile — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **ci profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to ci profile.
- **Authority:** Determine the authoritative source for ci profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by ci profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-105: staging profile — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-106: staging profile — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-107: staging profile — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-108: staging profile — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-109: staging profile — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-110: staging profile — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-111: staging profile — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-112: staging profile — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **staging profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to staging profile.
- **Authority:** Determine the authoritative source for staging profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by staging profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-113: production profile — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-114: production profile — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-115: production profile — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-116: production profile — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-117: production profile — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-118: production profile — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-119: production profile — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-120: production profile — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **production profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to production profile.
- **Authority:** Determine the authoritative source for production profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by production profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-121: local container profile — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-122: local container profile — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-123: local container profile — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-124: local container profile — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-125: local container profile — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-126: local container profile — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-127: local container profile — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-128: local container profile — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **local container profile**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local container profile.
- **Authority:** Determine the authoritative source for local container profile and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local container profile.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-129: network settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-130: network settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-131: network settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-132: network settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-133: network settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-134: network settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-135: network settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-136: network settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **network settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to network settings.
- **Authority:** Determine the authoritative source for network settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by network settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-137: storage settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-138: storage settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-139: storage settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-140: storage settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-141: storage settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-142: storage settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-143: storage settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-144: storage settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **storage settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to storage settings.
- **Authority:** Determine the authoritative source for storage settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by storage settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-145: authentication settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-146: authentication settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-147: authentication settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-148: authentication settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-149: authentication settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-150: authentication settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-151: authentication settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-152: authentication settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **authentication settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to authentication settings.
- **Authority:** Determine the authoritative source for authentication settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by authentication settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-153: logging settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-154: logging settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-155: logging settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-156: logging settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-157: logging settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-158: logging settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-159: logging settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-160: logging settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **logging settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to logging settings.
- **Authority:** Determine the authoritative source for logging settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by logging settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-161: performance settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-162: performance settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-163: performance settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-164: performance settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-165: performance settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-166: performance settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-167: performance settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-168: performance settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **performance settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to performance settings.
- **Authority:** Determine the authoritative source for performance settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by performance settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-169: retry and timeout settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-170: retry and timeout settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-171: retry and timeout settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-172: retry and timeout settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-173: retry and timeout settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-174: retry and timeout settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-175: retry and timeout settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-176: retry and timeout settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **retry and timeout settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retry and timeout settings.
- **Authority:** Determine the authoritative source for retry and timeout settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retry and timeout settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-177: experimental settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-178: experimental settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-179: experimental settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-180: experimental settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-181: experimental settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-182: experimental settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-183: experimental settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-184: experimental settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **experimental settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to experimental settings.
- **Authority:** Determine the authoritative source for experimental settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by experimental settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-185: deprecated settings — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-186: deprecated settings — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-187: deprecated settings — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-188: deprecated settings — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-189: deprecated settings — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-190: deprecated settings — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-191: deprecated settings — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-192: deprecated settings — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **deprecated settings**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to deprecated settings.
- **Authority:** Determine the authoritative source for deprecated settings and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by deprecated settings.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-193: example templates — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-194: example templates — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-195: example templates — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-196: example templates — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-197: example templates — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-198: example templates — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-199: example templates — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-200: example templates — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **example templates**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to example templates.
- **Authority:** Determine the authoritative source for example templates and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by example templates.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-201: configuration documentation — source and precedence

- **Control intent:** Establish reliable evidence about **source and precedence** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to source and precedence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about source and precedence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-202: configuration documentation — type and validation

- **Control intent:** Establish reliable evidence about **type and validation** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to type and validation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about type and validation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-203: configuration documentation — default and fallback

- **Control intent:** Establish reliable evidence about **default and fallback** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to default and fallback.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about default and fallback could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-204: configuration documentation — secret sensitivity

- **Control intent:** Establish reliable evidence about **secret sensitivity** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to secret sensitivity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about secret sensitivity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-205: configuration documentation — environment parity

- **Control intent:** Establish reliable evidence about **environment parity** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to environment parity.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about environment parity could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-206: configuration documentation — reload and lifecycle

- **Control intent:** Establish reliable evidence about **reload and lifecycle** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to reload and lifecycle.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about reload and lifecycle could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-207: configuration documentation — deprecation and compatibility

- **Control intent:** Establish reliable evidence about **deprecation and compatibility** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to deprecation and compatibility.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about deprecation and compatibility could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### CONFIGURATION-ENVIRONMENT-AND-SECRETS-REVIEW-PROMPT-RC-208: configuration documentation — documentation and testing

- **Control intent:** Establish reliable evidence about **documentation and testing** for **configuration documentation**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to configuration documentation.
- **Authority:** Determine the authoritative source for configuration documentation and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation and testing.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by configuration documentation.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation and testing could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.


## Mandatory Configuration Environment and Secrets Review Prompt Report Output Contract

Produce a report titled **Configuration Environment and Secrets Review Prompt Report** with the following sections:

### 1. Configuration architecture

Document configuration architecture using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 2. Source and precedence

Document source and precedence using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 3. Complete key reference

Document complete key reference using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 4. Environment comparison

Document environment comparison using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 5. Validation and failure behavior

Document validation and failure behavior using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 6. Secret handling

Document secret handling using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 7. Defaults and drift

Document defaults and drift using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 8. Deprecation and compatibility

Document deprecation and compatibility using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 9. Changes or recommendations

Document changes or recommendations using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 10. Verification

Document verification using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 11. Unknown settings

Document unknown settings using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

## Final Quality Gate

- Confirm every material claim has evidence or an explicit inference label.
- Confirm no secret or private data is exposed.
- Confirm the reported scope matches the inspected scope.
- Confirm unsupported files, platforms, environments, and tool failures are listed.
- Confirm proposed work is separated from applied work.
- Confirm exact verification outcomes are included.
- Confirm no completion claim exceeds available evidence.
- End with `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or `INCOMPLETE` and a concise rationale.
