---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-16
sequence: 16
title: Data Storage, Schema, and Migration Review
slug: data-storage-schema-and-migration-review
canonical_path: prompts/16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md
category: data
prompt_type: review
status: stable
description: Reviews data ownership, schemas, integrity, concurrency, migrations, backup, restore, privacy, and rollback safety.
language_agnostic: true
self_contained: true
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: reports_and_explicitly_approved_data_changes
risk_level: critical
requires:
- UPPS-03
- UPPS-15
recommended_before:
- UPPS-19
- UPPS-21
- UPPS-23
recommended_after:
- UPPS-03
- UPPS-15
related_prompts:
- UPPS-04
- UPPS-15
- UPPS-18
- UPPS-21
expected_outputs:
- data_inventory
- schema_assessment
- migration_plan
- recovery_plan
tags:
- data
- schema
- migration
- integrity
- backup
last_updated: '2026-07-11'
minimum_content_lines: 1000
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: reports/data/data_storage_schema_migration_report.md
    format: markdown
    purpose: Data ownership, integrity, schema, migration, backup, and recovery report.
    required_when_writing: true
  supporting_artifacts:
  - path: artifacts/data/data_inventory.json
    format: json
    purpose: Machine-readable data-store and ownership inventory.
    required_when_writing: true
  - path: artifacts/data/schema_inventory.json
    format: json
    purpose: Schema, version, constraint, and index inventory.
    required_when_writing: true
  - path: plans/data/migration_plan.md
    format: markdown
    purpose: Safe migration and compatibility plan.
    required_when_writing: true
  - path: plans/data/recovery_plan.md
    format: markdown
    purpose: Backup, restore, rollback, and recovery plan.
    required_when_writing: true
  - path: logs/data/migration_validation_log.txt
    format: text
    purpose: Sanitized migration validation transcript.
    required_when_writing: false
---

# Data Storage, Schema, and Migration Review

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./reports/data/data_storage_schema_migration_report.md` | `markdown` | Data ownership, integrity, schema, migration, backup, and recovery report. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./artifacts/data/data_inventory.json` | `json` | Machine-readable data-store and ownership inventory. | Required when writing |
| `./artifacts/data/schema_inventory.json` | `json` | Schema, version, constraint, and index inventory. | Required when writing |
| `./plans/data/migration_plan.md` | `markdown` | Safe migration and compatibility plan. | Required when writing |
| `./plans/data/recovery_plan.md` | `markdown` | Backup, restore, rollback, and recovery plan. | Required when writing |
| `./logs/data/migration_validation_log.txt` | `text` | Sanitized migration validation transcript. | When applicable |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_16_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_16
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

You are a data architect, database reliability engineer, and migration safety reviewer.

## Mission

Review persistence, ownership, integrity, privacy, schema evolution, migration safety, backup, and recovery.

## Universal Self-Contained Execution Contract

This prompt is intentionally self-contained. Apply every rule in this contract unless a later section is explicitly stricter.

### A. Operating Modes

Select exactly one mode and state it at the beginning of the report.

- `AUDIT_ONLY`: inspect and report. Do not modify repository files.
- `PLAN_ONLY`: inspect and produce an implementation plan. Do not modify repository files.
- `APPLY_SAFE`: apply only low-risk, reversible, behavior-preserving changes supported by direct evidence.
- `APPLY_APPROVED`: apply the specific higher-impact changes explicitly authorized by the user.
- `VERIFY_ONLY`: execute approved verification procedures against an existing change set without broadening scope.

Default to `AUDIT_ONLY` when the user does not explicitly authorize modifications.

### B. Required Project Inputs

Resolve and record the following inputs before work begins:

```yaml
PROJECT_ROOT: "."
PROJECT_NAME: ""
PROJECT_TYPE: ""
PROJECT_PURPOSE: ""
MODE: "AUDIT_ONLY"
SCOPE: "entire repository"
PRIORITY_AREAS: []
EXCLUSIONS: []
PROTECTED_PATHS: []
SUPPORTED_PLATFORMS: []
DEPLOYMENT_TARGETS: []
NETWORK_ACCESS: false
ALLOW_EXTERNAL_LOOKUPS: false
ALLOW_INSTALLS: false
ALLOW_FILE_MODIFICATION: false
ALLOW_FILE_DELETION: false
ALLOW_RENAMES_OR_MOVES: false
ALLOW_DEPENDENCY_CHANGES: false
ALLOW_DATA_MUTATION: false
ALLOW_MIGRATIONS: false
ALLOW_PUBLIC_CONTRACT_CHANGES: false
ALLOW_SERVICE_STARTUP: false
ALLOW_UNKNOWN_BINARY_EXECUTION: false
REQUIRED_COMMANDS: []
FORBIDDEN_COMMANDS: []
ACCEPTANCE_CRITERIA: []
OUTPUT_DIRECTORY: ""
ADDITIONAL_CONTEXT: ""
```

Blank values are unknown. They are never permission to invent or broaden scope.

### C. Evidence Rules

1. Inspect before concluding.
2. Cite file paths, symbols, line ranges, configuration keys, command output, or reproducible observations.
3. Mark important statements as `Verified`, `Inferred`, `Proposed`, `Unknown`, or `Not Applicable` when ambiguity matters.
4. Never treat a file’s existence as proof that it is active.
5. Never treat a textual reference search as complete reachability analysis.
6. Never treat a passing test as proof of total correctness.
7. Never treat comments, TODOs, examples, issue references, or roadmap notes as implemented behavior without corroboration.
8. Never claim complete coverage without an inventory that accounts for exclusions, opaque files, generated files, binaries, archives, unsupported formats, and tool failures.
9. When sources conflict, identify the conflict, rank likely authority, and preserve unresolved ambiguity.
10. Record exact commands and exact outcomes; do not paraphrase failed verification into success.

### D. Safety and Permission Rules

1. Do not access production systems unless explicitly authorized.
2. Do not access networks or external services unless explicitly authorized.
3. Do not reveal complete secrets, private keys, tokens, credentials, personal data, or sensitive connection strings.
4. Do not execute unknown binaries or untrusted scripts.
5. Do not install or upgrade dependencies unless explicitly authorized.
6. Do not delete, rename, move, or overwrite files unless explicitly authorized.
7. Do not mutate databases, indexes, queues, object stores, caches, or user data unless explicitly authorized.
8. Do not rewrite migration history unless a project-specific authority explicitly permits it.
9. Do not change public APIs, CLI behavior, configuration keys, events, schemas, serialized formats, package exports, or supported paths without explicit authorization and compatibility analysis.
10. Do not discard or overwrite pre-existing local changes.
11. Prefer reversible, reviewable, minimal changes.
12. Stop applying changes when unexpected regression, data risk, contract drift, or unexplained scope expansion appears.

### E. Repository Ground Truth

Before domain-specific work, establish or consume a repository inventory containing:

- Repository boundaries and nested repositories
- Version-control state
- Languages, runtimes, frameworks, and package managers
- Build systems and task runners
- Entry points
- Components, packages, modules, services, and workspaces
- Public and internal contracts
- Configuration sources and precedence
- Data stores and persistent state
- External services
- Tests and verification commands
- CI/CD and deployment paths
- Generated, vendored, binary, archive, cache, and runtime-output areas
- Existing documentation
- Security-sensitive surfaces
- Unknown or inaccessible areas

### F. Baseline Rules

Before modifications, record:

- Current revision and branch
- Dirty, staged, modified, and untracked state
- Existing generated artifacts
- Existing build outcome
- Existing test outcome
- Existing lint, formatting, type-check, and static-analysis outcome
- Existing service health where applicable
- Known pre-existing failures
- Supported platform assumptions
- Tool versions used

Do not attribute pre-existing failures to new work.

### G. Change Discipline

For each proposed or applied change:

- State the objective.
- State the evidence.
- State the affected files and contracts.
- State compatibility risk.
- State data and security implications.
- State verification.
- State rollback.
- Keep mechanical changes separate from semantic changes.
- Keep dependency changes separate from cleanup.
- Keep migrations separate from unrelated refactors.
- Keep documentation corrections traceable to source evidence.
- Avoid unrelated formatting.

### H. Verification Discipline

Use the narrowest relevant check first, followed by broader available checks.

Applicable checks may include:

- Parser or syntax validation
- Formatting check
- Lint
- Type check
- Unit tests
- Component tests
- Integration tests
- Contract tests
- End-to-end tests
- Security tests
- Fuzz/property tests
- Migration checks
- Packaging and installation
- Container/image build
- Smoke tests
- API/CLI schema comparison
- Documentation link and example validation
- Performance budgets
- Platform matrix
- Data integrity checks

A skipped, unavailable, unauthorized, or failed check must be reported explicitly.

### I. Finding Classification

Use both impact and confidence.

Impact:
- `Critical`
- `High`
- `Medium`
- `Low`
- `Informational`

Confidence:
- `Confirmed`
- `High`
- `Medium`
- `Low`

Status:
- `Confirmed Issue`
- `Likely Issue`
- `Risk`
- `Hardening Opportunity`
- `Documentation Gap`
- `Needs Manual Review`
- `Not Applicable`
- `False Positive`

### J. Completion States

Use exactly one:

- `PASS`
- `PASS_WITH_CONDITIONS`
- `FAIL`
- `INCOMPLETE`

`PASS` requires direct evidence that all requested deliverables and mandatory checks completed without unresolved blockers.

`PASS_WITH_CONDITIONS` means no confirmed blocker remains, but named limitations, deferred checks, or accepted risks remain.

`FAIL` means a blocker, regression, unsafe condition, or acceptance-criterion failure is confirmed.

`INCOMPLETE` means required evidence, access, tooling, or scope coverage was unavailable.

### K. Mandatory Final Report Sections

Every final report must include:

1. Objective
2. Scope
3. Mode and permissions
4. Assumptions
5. Repository evidence used
6. Coverage and exclusions
7. Baseline
8. Findings
9. Proposed or applied changes
10. Verification
11. Compatibility impact
12. Security and data impact
13. Remaining risks
14. Unknowns
15. Rollback or recovery information
16. Prioritized next actions
17. Completion state

## Data Safety Boundary

Default to read-only analysis. Do not connect to production or run migrations without explicit authorization.

Identify data stores, owners, sources of truth, readers, writers, constraints, indexes, transaction boundaries, consistency, retention, privacy, backups, restore procedures, and rebuild paths.

Review migrations for ordering, online compatibility, expand/contract sequencing, backfills, checkpoints, retries, failure recovery, rollback limits, and old/new version coexistence.

## Exhaustive Review Control Catalog

Apply every applicable control below to the Data Storage Schema and Migration Review Prompt review. A control may be marked `Not Applicable` only after applicability is considered and the reason is recorded.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-001: relational database — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-002: relational database — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-003: relational database — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-004: relational database — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-005: relational database — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-006: relational database — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-007: relational database — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-008: relational database — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **relational database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to relational database.
- **Authority:** Determine the authoritative source for relational database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by relational database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-009: document database — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-010: document database — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-011: document database — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-012: document database — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-013: document database — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-014: document database — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-015: document database — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-016: document database — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **document database**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to document database.
- **Authority:** Determine the authoritative source for document database and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by document database.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-017: key-value store — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-018: key-value store — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-019: key-value store — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-020: key-value store — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-021: key-value store — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-022: key-value store — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-023: key-value store — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-024: key-value store — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **key-value store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to key-value store.
- **Authority:** Determine the authoritative source for key-value store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by key-value store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-025: cache — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-026: cache — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-027: cache — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-028: cache — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-029: cache — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-030: cache — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-031: cache — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-032: cache — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **cache**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to cache.
- **Authority:** Determine the authoritative source for cache and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by cache.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-033: queue — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-034: queue — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-035: queue — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-036: queue — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-037: queue — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-038: queue — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-039: queue — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-040: queue — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **queue**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to queue.
- **Authority:** Determine the authoritative source for queue and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by queue.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-041: event log — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-042: event log — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-043: event log — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-044: event log — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-045: event log — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-046: event log — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-047: event log — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-048: event log — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **event log**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to event log.
- **Authority:** Determine the authoritative source for event log and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by event log.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-049: object storage — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-050: object storage — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-051: object storage — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-052: object storage — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-053: object storage — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-054: object storage — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-055: object storage — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-056: object storage — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **object storage**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to object storage.
- **Authority:** Determine the authoritative source for object storage and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by object storage.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-057: filesystem data — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-058: filesystem data — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-059: filesystem data — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-060: filesystem data — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-061: filesystem data — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-062: filesystem data — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-063: filesystem data — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-064: filesystem data — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **filesystem data**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to filesystem data.
- **Authority:** Determine the authoritative source for filesystem data and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by filesystem data.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-065: search index — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-066: search index — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-067: search index — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-068: search index — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-069: search index — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-070: search index — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-071: search index — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-072: search index — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **search index**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to search index.
- **Authority:** Determine the authoritative source for search index and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by search index.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-073: vector store — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-074: vector store — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-075: vector store — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-076: vector store — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-077: vector store — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-078: vector store — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-079: vector store — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-080: vector store — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **vector store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vector store.
- **Authority:** Determine the authoritative source for vector store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vector store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-081: analytics store — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-082: analytics store — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-083: analytics store — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-084: analytics store — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-085: analytics store — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-086: analytics store — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-087: analytics store — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-088: analytics store — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **analytics store**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to analytics store.
- **Authority:** Determine the authoritative source for analytics store and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by analytics store.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-089: local state — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-090: local state — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-091: local state — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-092: local state — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-093: local state — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-094: local state — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-095: local state — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-096: local state — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **local state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to local state.
- **Authority:** Determine the authoritative source for local state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by local state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-097: temporary state — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-098: temporary state — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-099: temporary state — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-100: temporary state — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-101: temporary state — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-102: temporary state — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-103: temporary state — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-104: temporary state — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **temporary state**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to temporary state.
- **Authority:** Determine the authoritative source for temporary state and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by temporary state.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-105: backup — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-106: backup — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-107: backup — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-108: backup — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-109: backup — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-110: backup — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-111: backup — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-112: backup — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **backup**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backup.
- **Authority:** Determine the authoritative source for backup and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backup.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-113: snapshot — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-114: snapshot — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-115: snapshot — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-116: snapshot — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-117: snapshot — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-118: snapshot — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-119: snapshot — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-120: snapshot — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **snapshot**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to snapshot.
- **Authority:** Determine the authoritative source for snapshot and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by snapshot.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-121: schema definition — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-122: schema definition — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-123: schema definition — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-124: schema definition — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-125: schema definition — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-126: schema definition — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-127: schema definition — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-128: schema definition — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **schema definition**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to schema definition.
- **Authority:** Determine the authoritative source for schema definition and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by schema definition.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-129: constraints — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-130: constraints — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-131: constraints — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-132: constraints — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-133: constraints — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-134: constraints — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-135: constraints — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-136: constraints — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **constraints**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to constraints.
- **Authority:** Determine the authoritative source for constraints and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by constraints.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-137: indexes — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-138: indexes — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-139: indexes — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-140: indexes — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-141: indexes — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-142: indexes — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-143: indexes — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-144: indexes — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **indexes**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to indexes.
- **Authority:** Determine the authoritative source for indexes and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by indexes.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-145: transaction boundary — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-146: transaction boundary — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-147: transaction boundary — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-148: transaction boundary — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-149: transaction boundary — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-150: transaction boundary — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-151: transaction boundary — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-152: transaction boundary — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **transaction boundary**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transaction boundary.
- **Authority:** Determine the authoritative source for transaction boundary and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transaction boundary.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-153: read model — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-154: read model — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-155: read model — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-156: read model — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-157: read model — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-158: read model — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-159: read model — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-160: read model — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **read model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to read model.
- **Authority:** Determine the authoritative source for read model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by read model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-161: write model — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-162: write model — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-163: write model — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-164: write model — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-165: write model — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-166: write model — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-167: write model — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-168: write model — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **write model**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to write model.
- **Authority:** Determine the authoritative source for write model and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by write model.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-169: migration — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-170: migration — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-171: migration — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-172: migration — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-173: migration — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-174: migration — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-175: migration — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-176: migration — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **migration**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to migration.
- **Authority:** Determine the authoritative source for migration and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by migration.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-177: backfill — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-178: backfill — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-179: backfill — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-180: backfill — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-181: backfill — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-182: backfill — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-183: backfill — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-184: backfill — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **backfill**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to backfill.
- **Authority:** Determine the authoritative source for backfill and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by backfill.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-185: data export — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-186: data export — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-187: data export — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-188: data export — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-189: data export — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-190: data export — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-191: data export — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-192: data export — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **data export**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data export.
- **Authority:** Determine the authoritative source for data export and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data export.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-193: data deletion — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-194: data deletion — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-195: data deletion — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-196: data deletion — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-197: data deletion — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-198: data deletion — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-199: data deletion — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-200: data deletion — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **data deletion**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to data deletion.
- **Authority:** Determine the authoritative source for data deletion and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by data deletion.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-201: retention policy — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-202: retention policy — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-203: retention policy — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-204: retention policy — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-205: retention policy — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-206: retention policy — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-207: retention policy — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-208: retention policy — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **retention policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention policy.
- **Authority:** Determine the authoritative source for retention policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-209: reconciliation job — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-210: reconciliation job — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-211: reconciliation job — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-212: reconciliation job — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-213: reconciliation job — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-214: reconciliation job — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-215: reconciliation job — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-216: reconciliation job — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **reconciliation job**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to reconciliation job.
- **Authority:** Determine the authoritative source for reconciliation job and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by reconciliation job.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-217: rebuild procedure — ownership and source of truth

- **Control intent:** Establish reliable evidence about **ownership and source of truth** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and source of truth.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and source of truth could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-218: rebuild procedure — schema and constraints

- **Control intent:** Establish reliable evidence about **schema and constraints** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to schema and constraints.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about schema and constraints could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-219: rebuild procedure — read and write paths

- **Control intent:** Establish reliable evidence about **read and write paths** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to read and write paths.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about read and write paths could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-220: rebuild procedure — transactions and concurrency

- **Control intent:** Establish reliable evidence about **transactions and concurrency** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to transactions and concurrency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about transactions and concurrency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-221: rebuild procedure — migration and version coexistence

- **Control intent:** Establish reliable evidence about **migration and version coexistence** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to migration and version coexistence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about migration and version coexistence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-222: rebuild procedure — retention and privacy

- **Control intent:** Establish reliable evidence about **retention and privacy** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to retention and privacy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about retention and privacy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-223: rebuild procedure — backup and recovery

- **Control intent:** Establish reliable evidence about **backup and recovery** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to backup and recovery.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about backup and recovery could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### DATA-STORAGE-SCHEMA-AND-MIGRATION-REVIEW-PROMPT-RC-224: rebuild procedure — integrity verification

- **Control intent:** Establish reliable evidence about **integrity verification** for **rebuild procedure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to rebuild procedure.
- **Authority:** Determine the authoritative source for rebuild procedure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to integrity verification.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by rebuild procedure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about integrity verification could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.


## Mandatory Data Storage Schema and Migration Review Prompt Report Output Contract

Produce a report titled **Data Storage Schema and Migration Review Prompt Report** with the following sections:

### 1. Data-store inventory

Document data-store inventory using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 2. Sources of truth and ownership

Document sources of truth and ownership using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 3. Schemas and indexes

Document schemas and indexes using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 4. Read and write paths

Document read and write paths using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 5. Integrity and concurrency

Document integrity and concurrency using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 6. Migration safety

Document migration safety using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 7. Backup and restore

Document backup and restore using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 8. Privacy and retention

Document privacy and retention using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 9. Findings

Document findings using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 10. Safe migration plan

Document safe migration plan using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 11. Verification and rollback

Document verification and rollback using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 12. Unknowns

Document unknowns using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

## Final Quality Gate

- Confirm every material claim has evidence or an explicit inference label.
- Confirm no secret or private data is exposed.
- Confirm the reported scope matches the inspected scope.
- Confirm unsupported files, platforms, environments, and tool failures are listed.
- Confirm proposed work is separated from applied work.
- Confirm exact verification outcomes are included.
- Confirm no completion claim exceeds available evidence.
- End with `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or `INCOMPLETE` and a concise rationale.
