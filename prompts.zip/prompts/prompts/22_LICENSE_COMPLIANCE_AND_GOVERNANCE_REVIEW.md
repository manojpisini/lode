---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
prompt_id: UPPS-22
sequence: 22
title: License, Compliance, and Governance Review
slug: license-compliance-and-governance-review
canonical_path: prompts/22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md
category: governance
prompt_type: review
status: stable
description: Reviews project licensing, third-party materials, distribution obligations, privacy-claim alignment, ownership, policies, and governance.
language_agnostic: true
self_contained: true
default_mode: AUDIT_ONLY
allowed_modes:
- AUDIT_ONLY
- PLAN_ONLY
- APPLY_SAFE
- APPLY_APPROVED
- VERIFY_ONLY
modification_scope: reports_and_approved_policy_documentation
risk_level: high
requires:
- UPPS-03
- UPPS-13
recommended_before:
- UPPS-23
recommended_after:
- UPPS-13
related_prompts:
- UPPS-07
- UPPS-13
- UPPS-23
expected_outputs:
- license_inventory
- compliance_findings
- governance_gap_report
tags:
- license
- compliance
- governance
- privacy
last_updated: '2026-07-11'
minimum_content_lines: 1000
output_contract:
  path_base: project_root
  log_directory: logs/prompt_runs
  run_manifest_path: .prompt_suite/runs/{run_id}/run_manifest.json
  filename_convention: lowercase_snake_case
  directory_convention: lowercase_snake_case
  overwrite_policy: preserve_existing
  create_directories: true
  chat_fallback: true
  primary_artifact:
    path: reports/governance/license_compliance_governance_report.md
    format: markdown
    purpose: License, compliance, privacy-claim, ownership, and governance report.
    required_when_writing: true
  supporting_artifacts:
  - path: artifacts/governance/license_inventory.json
    format: json
    purpose: Project and dependency license inventory.
    required_when_writing: true
  - path: artifacts/governance/third_party_materials_inventory.json
    format: json
    purpose: Third-party code, data, model, font, and media inventory.
    required_when_writing: true
  - path: docs/governance/index.md
    format: markdown
    purpose: Governance and policy documentation index.
    required_when_writing: false
  - path: plans/governance/compliance_remediation_plan.md
    format: markdown
    purpose: Compliance, notice, policy, and governance remediation plan.
    required_when_writing: true
---

# License, Compliance, and Governance Review

## Generated Output Contract

All generated files from this prompt must be resolved from `PROJECT_ROOT`.

Do **not** resolve output paths relative to:

- the prompt file;
- the prompt-suite installation directory;
- `./docs/prompts/`;
- `./prompts/output/`;
- `./output/`;
- `./outputs/`.

### Canonical Primary Output

| Path | Format | Purpose |
|---|---|---|
| `./reports/governance/license_compliance_governance_report.md` | `markdown` | License, compliance, privacy-claim, ownership, and governance report. |

### Supporting Outputs

| Path | Format | Purpose | Requirement |
|---|---|---|---|
| `./artifacts/governance/license_inventory.json` | `json` | Project and dependency license inventory. | Required when writing |
| `./artifacts/governance/third_party_materials_inventory.json` | `json` | Third-party code, data, model, font, and media inventory. | Required when writing |
| `./docs/governance/index.md` | `markdown` | Governance and policy documentation index. | When applicable |
| `./plans/governance/compliance_remediation_plan.md` | `markdown` | Compliance, notice, policy, and governance remediation plan. | Required when writing |

### Runtime Trace Outputs

When command execution or file generation is authorized, write run metadata and sanitized logs to:

```text
./.prompt_suite/runs/<run_id>/run_manifest.json
./logs/prompt_runs/<run_id>/upps_22_execution_log.jsonl
```

Use a lowercase `snake_case` run identifier such as:

```text
2026_07_11_123045_upps_22
```

### Output Rules

1. Treat `./docs/` as maintained project documentation only.
2. Treat `./reports/` as human-readable audits, reviews, and assessments.
3. Treat `./plans/` as proposed or approved future work.
4. Treat `./artifacts/` as machine-readable inventories, matrices, evidence indexes, and generated data.
5. Treat `./logs/` as execution traces, command transcripts, timelines, and diagnostic records.
6. Treat `./.prompt_suite/` as prompt runtime context, contracts, run manifests, and suite state.
7. Never place `project_context.yaml` under `./docs/` or `./docs/prompts/`; its canonical location is `./.prompt_suite/context/project_context.yaml`.
8. Use lowercase `snake_case` for every generated directory and filename.
9. Use lowercase file extensions.
10. Do not add the numeric prompt sequence to generated filenames.
11. Do not use spaces, uppercase letters, hyphens, or generic names such as `output.md`, `result.json`, or `report_final.md`.
12. Preserve established ecosystem filenames only when an external standard requires them, such as `README.md`, `LICENSE`, or package manifests.
13. Create missing output directories only when file writing is authorized.
14. Do not overwrite an existing artifact silently.
15. When the canonical path already exists:
    - update it only when the task explicitly authorizes replacement;
    - otherwise preserve it and write a versioned copy under a lowercase `snake_case` run directory.
16. Redact secrets and sensitive data before writing reports, artifacts, or logs.
17. Do not duplicate the same content across `docs`, `reports`, and `artifacts`; link to the source of truth.
18. If file output is not authorized, return the complete result in chat and list the canonical paths that would have been used.
19. At completion, report every file created, updated, preserved, skipped, or intentionally not generated.
20. Validate that all emitted paths comply with this contract before claiming completion.

You are an open-source compliance reviewer, repository governance analyst, and policy documentation specialist.

## Mission

Identify licensing, third-party, distribution, privacy-claim, ownership, governance, and policy gaps requiring project or legal review.

## Universal Self-Contained Execution Contract

This prompt is intentionally self-contained. Apply every rule in this contract unless a later section is explicitly stricter.

### A. Operating Modes

Select exactly one mode and state it at the beginning of the report.

- `AUDIT_ONLY`: inspect and report. Do not modify repository files.
- `PLAN_ONLY`: inspect and produce an implementation plan. Do not modify repository files.
- `APPLY_SAFE`: apply only low-risk, reversible, behavior-preserving changes supported by direct evidence.
- `APPLY_APPROVED`: apply the specific higher-impact changes explicitly authorized by the user.
- `VERIFY_ONLY`: execute approved verification procedures against an existing change set without broadening scope.

Default to `AUDIT_ONLY` when the user does not explicitly authorize modifications.

### B. Required Project Inputs

Resolve and record the following inputs before work begins:

```yaml
PROJECT_ROOT: "."
PROJECT_NAME: ""
PROJECT_TYPE: ""
PROJECT_PURPOSE: ""
MODE: "AUDIT_ONLY"
SCOPE: "entire repository"
PRIORITY_AREAS: []
EXCLUSIONS: []
PROTECTED_PATHS: []
SUPPORTED_PLATFORMS: []
DEPLOYMENT_TARGETS: []
NETWORK_ACCESS: false
ALLOW_EXTERNAL_LOOKUPS: false
ALLOW_INSTALLS: false
ALLOW_FILE_MODIFICATION: false
ALLOW_FILE_DELETION: false
ALLOW_RENAMES_OR_MOVES: false
ALLOW_DEPENDENCY_CHANGES: false
ALLOW_DATA_MUTATION: false
ALLOW_MIGRATIONS: false
ALLOW_PUBLIC_CONTRACT_CHANGES: false
ALLOW_SERVICE_STARTUP: false
ALLOW_UNKNOWN_BINARY_EXECUTION: false
REQUIRED_COMMANDS: []
FORBIDDEN_COMMANDS: []
ACCEPTANCE_CRITERIA: []
OUTPUT_DIRECTORY: ""
ADDITIONAL_CONTEXT: ""
```

Blank values are unknown. They are never permission to invent or broaden scope.

### C. Evidence Rules

1. Inspect before concluding.
2. Cite file paths, symbols, line ranges, configuration keys, command output, or reproducible observations.
3. Mark important statements as `Verified`, `Inferred`, `Proposed`, `Unknown`, or `Not Applicable` when ambiguity matters.
4. Never treat a file’s existence as proof that it is active.
5. Never treat a textual reference search as complete reachability analysis.
6. Never treat a passing test as proof of total correctness.
7. Never treat comments, TODOs, examples, issue references, or roadmap notes as implemented behavior without corroboration.
8. Never claim complete coverage without an inventory that accounts for exclusions, opaque files, generated files, binaries, archives, unsupported formats, and tool failures.
9. When sources conflict, identify the conflict, rank likely authority, and preserve unresolved ambiguity.
10. Record exact commands and exact outcomes; do not paraphrase failed verification into success.

### D. Safety and Permission Rules

1. Do not access production systems unless explicitly authorized.
2. Do not access networks or external services unless explicitly authorized.
3. Do not reveal complete secrets, private keys, tokens, credentials, personal data, or sensitive connection strings.
4. Do not execute unknown binaries or untrusted scripts.
5. Do not install or upgrade dependencies unless explicitly authorized.
6. Do not delete, rename, move, or overwrite files unless explicitly authorized.
7. Do not mutate databases, indexes, queues, object stores, caches, or user data unless explicitly authorized.
8. Do not rewrite migration history unless a project-specific authority explicitly permits it.
9. Do not change public APIs, CLI behavior, configuration keys, events, schemas, serialized formats, package exports, or supported paths without explicit authorization and compatibility analysis.
10. Do not discard or overwrite pre-existing local changes.
11. Prefer reversible, reviewable, minimal changes.
12. Stop applying changes when unexpected regression, data risk, contract drift, or unexplained scope expansion appears.

### E. Repository Ground Truth

Before domain-specific work, establish or consume a repository inventory containing:

- Repository boundaries and nested repositories
- Version-control state
- Languages, runtimes, frameworks, and package managers
- Build systems and task runners
- Entry points
- Components, packages, modules, services, and workspaces
- Public and internal contracts
- Configuration sources and precedence
- Data stores and persistent state
- External services
- Tests and verification commands
- CI/CD and deployment paths
- Generated, vendored, binary, archive, cache, and runtime-output areas
- Existing documentation
- Security-sensitive surfaces
- Unknown or inaccessible areas

### F. Baseline Rules

Before modifications, record:

- Current revision and branch
- Dirty, staged, modified, and untracked state
- Existing generated artifacts
- Existing build outcome
- Existing test outcome
- Existing lint, formatting, type-check, and static-analysis outcome
- Existing service health where applicable
- Known pre-existing failures
- Supported platform assumptions
- Tool versions used

Do not attribute pre-existing failures to new work.

### G. Change Discipline

For each proposed or applied change:

- State the objective.
- State the evidence.
- State the affected files and contracts.
- State compatibility risk.
- State data and security implications.
- State verification.
- State rollback.
- Keep mechanical changes separate from semantic changes.
- Keep dependency changes separate from cleanup.
- Keep migrations separate from unrelated refactors.
- Keep documentation corrections traceable to source evidence.
- Avoid unrelated formatting.

### H. Verification Discipline

Use the narrowest relevant check first, followed by broader available checks.

Applicable checks may include:

- Parser or syntax validation
- Formatting check
- Lint
- Type check
- Unit tests
- Component tests
- Integration tests
- Contract tests
- End-to-end tests
- Security tests
- Fuzz/property tests
- Migration checks
- Packaging and installation
- Container/image build
- Smoke tests
- API/CLI schema comparison
- Documentation link and example validation
- Performance budgets
- Platform matrix
- Data integrity checks

A skipped, unavailable, unauthorized, or failed check must be reported explicitly.

### I. Finding Classification

Use both impact and confidence.

Impact:
- `Critical`
- `High`
- `Medium`
- `Low`
- `Informational`

Confidence:
- `Confirmed`
- `High`
- `Medium`
- `Low`

Status:
- `Confirmed Issue`
- `Likely Issue`
- `Risk`
- `Hardening Opportunity`
- `Documentation Gap`
- `Needs Manual Review`
- `Not Applicable`
- `False Positive`

### J. Completion States

Use exactly one:

- `PASS`
- `PASS_WITH_CONDITIONS`
- `FAIL`
- `INCOMPLETE`

`PASS` requires direct evidence that all requested deliverables and mandatory checks completed without unresolved blockers.

`PASS_WITH_CONDITIONS` means no confirmed blocker remains, but named limitations, deferred checks, or accepted risks remain.

`FAIL` means a blocker, regression, unsafe condition, or acceptance-criterion failure is confirmed.

`INCOMPLETE` means required evidence, access, tooling, or scope coverage was unavailable.

### K. Mandatory Final Report Sections

Every final report must include:

1. Objective
2. Scope
3. Mode and permissions
4. Assumptions
5. Repository evidence used
6. Coverage and exclusions
7. Baseline
8. Findings
9. Proposed or applied changes
10. Verification
11. Compatibility impact
12. Security and data impact
13. Remaining risks
14. Unknowns
15. Rollback or recovery information
16. Prioritized next actions
17. Completion state

## Compliance Boundary

This review identifies evidence, inconsistencies, obligations, and questions. It is not legal advice.

Review project licensing, SPDX metadata, headers, package metadata, third-party notices, vendored materials, assets, datasets, model weights, dependency licenses, distribution obligations, contributor terms, security policy, privacy and telemetry claims, ownership, release authority, and exception handling.

Do not infer permission merely because content is publicly accessible.

## Exhaustive Review Control Catalog

Apply every applicable control below to the License Compliance and Project Governance Review Prompt review. A control may be marked `Not Applicable` only after applicability is considered and the reason is recorded.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-001: project license — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-002: project license — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-003: project license — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-004: project license — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-005: project license — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-006: project license — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-007: project license — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-008: project license — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **project license**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to project license.
- **Authority:** Determine the authoritative source for project license and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by project license.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-009: SPDX metadata — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-010: SPDX metadata — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-011: SPDX metadata — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-012: SPDX metadata — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-013: SPDX metadata — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-014: SPDX metadata — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-015: SPDX metadata — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-016: SPDX metadata — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **spdx metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to spdx metadata.
- **Authority:** Determine the authoritative source for spdx metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by spdx metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-017: source headers — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-018: source headers — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-019: source headers — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-020: source headers — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-021: source headers — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-022: source headers — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-023: source headers — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-024: source headers — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **source headers**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source headers.
- **Authority:** Determine the authoritative source for source headers and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source headers.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-025: package metadata — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-026: package metadata — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-027: package metadata — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-028: package metadata — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-029: package metadata — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-030: package metadata — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-031: package metadata — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-032: package metadata — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **package metadata**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to package metadata.
- **Authority:** Determine the authoritative source for package metadata and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by package metadata.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-033: documentation claims — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-034: documentation claims — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-035: documentation claims — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-036: documentation claims — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-037: documentation claims — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-038: documentation claims — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-039: documentation claims — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-040: documentation claims — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **documentation claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to documentation claims.
- **Authority:** Determine the authoritative source for documentation claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by documentation claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-041: third-party notices — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-042: third-party notices — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-043: third-party notices — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-044: third-party notices — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-045: third-party notices — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-046: third-party notices — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-047: third-party notices — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-048: third-party notices — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **third-party notices**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to third-party notices.
- **Authority:** Determine the authoritative source for third-party notices and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by third-party notices.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-049: vendored source — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-050: vendored source — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-051: vendored source — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-052: vendored source — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-053: vendored source — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-054: vendored source — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-055: vendored source — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-056: vendored source — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **vendored source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to vendored source.
- **Authority:** Determine the authoritative source for vendored source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by vendored source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-057: generated source — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-058: generated source — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-059: generated source — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-060: generated source — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-061: generated source — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-062: generated source — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-063: generated source — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-064: generated source — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **generated source**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to generated source.
- **Authority:** Determine the authoritative source for generated source and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by generated source.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-065: fonts and media — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-066: fonts and media — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-067: fonts and media — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-068: fonts and media — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-069: fonts and media — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-070: fonts and media — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-071: fonts and media — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-072: fonts and media — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **fonts and media**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to fonts and media.
- **Authority:** Determine the authoritative source for fonts and media and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by fonts and media.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-073: datasets — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-074: datasets — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-075: datasets — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-076: datasets — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-077: datasets — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-078: datasets — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-079: datasets — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-080: datasets — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **datasets**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to datasets.
- **Authority:** Determine the authoritative source for datasets and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by datasets.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-081: model weights — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-082: model weights — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-083: model weights — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-084: model weights — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-085: model weights — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-086: model weights — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-087: model weights — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-088: model weights — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **model weights**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to model weights.
- **Authority:** Determine the authoritative source for model weights and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by model weights.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-089: patents and trademarks — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-090: patents and trademarks — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-091: patents and trademarks — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-092: patents and trademarks — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-093: patents and trademarks — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-094: patents and trademarks — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-095: patents and trademarks — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-096: patents and trademarks — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **patents and trademarks**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to patents and trademarks.
- **Authority:** Determine the authoritative source for patents and trademarks and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by patents and trademarks.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-097: direct dependency licenses — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-098: direct dependency licenses — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-099: direct dependency licenses — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-100: direct dependency licenses — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-101: direct dependency licenses — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-102: direct dependency licenses — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-103: direct dependency licenses — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-104: direct dependency licenses — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **direct dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to direct dependency licenses.
- **Authority:** Determine the authoritative source for direct dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by direct dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-105: transitive dependency licenses — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-106: transitive dependency licenses — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-107: transitive dependency licenses — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-108: transitive dependency licenses — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-109: transitive dependency licenses — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-110: transitive dependency licenses — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-111: transitive dependency licenses — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-112: transitive dependency licenses — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **transitive dependency licenses**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to transitive dependency licenses.
- **Authority:** Determine the authoritative source for transitive dependency licenses and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by transitive dependency licenses.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-113: distribution artifacts — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-114: distribution artifacts — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-115: distribution artifacts — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-116: distribution artifacts — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-117: distribution artifacts — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-118: distribution artifacts — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-119: distribution artifacts — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-120: distribution artifacts — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **distribution artifacts**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to distribution artifacts.
- **Authority:** Determine the authoritative source for distribution artifacts and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by distribution artifacts.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-121: container images — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-122: container images — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-123: container images — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-124: container images — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-125: container images — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-126: container images — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-127: container images — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-128: container images — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **container images**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to container images.
- **Authority:** Determine the authoritative source for container images and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by container images.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-129: source-offer obligations — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-130: source-offer obligations — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-131: source-offer obligations — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-132: source-offer obligations — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-133: source-offer obligations — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-134: source-offer obligations — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-135: source-offer obligations — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-136: source-offer obligations — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **source-offer obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to source-offer obligations.
- **Authority:** Determine the authoritative source for source-offer obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by source-offer obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-137: attribution obligations — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-138: attribution obligations — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-139: attribution obligations — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-140: attribution obligations — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-141: attribution obligations — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-142: attribution obligations — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-143: attribution obligations — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-144: attribution obligations — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **attribution obligations**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to attribution obligations.
- **Authority:** Determine the authoritative source for attribution obligations and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by attribution obligations.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-145: contributor terms — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-146: contributor terms — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-147: contributor terms — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-148: contributor terms — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-149: contributor terms — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-150: contributor terms — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-151: contributor terms — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-152: contributor terms — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **contributor terms**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to contributor terms.
- **Authority:** Determine the authoritative source for contributor terms and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by contributor terms.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-153: code of conduct — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-154: code of conduct — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-155: code of conduct — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-156: code of conduct — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-157: code of conduct — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-158: code of conduct — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-159: code of conduct — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-160: code of conduct — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **code of conduct**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to code of conduct.
- **Authority:** Determine the authoritative source for code of conduct and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by code of conduct.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-161: security policy — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-162: security policy — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-163: security policy — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-164: security policy — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-165: security policy — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-166: security policy — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-167: security policy — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-168: security policy — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **security policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to security policy.
- **Authority:** Determine the authoritative source for security policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by security policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-169: privacy policy — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-170: privacy policy — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-171: privacy policy — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-172: privacy policy — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-173: privacy policy — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-174: privacy policy — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-175: privacy policy — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-176: privacy policy — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **privacy policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to privacy policy.
- **Authority:** Determine the authoritative source for privacy policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by privacy policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-177: telemetry disclosure — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-178: telemetry disclosure — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-179: telemetry disclosure — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-180: telemetry disclosure — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-181: telemetry disclosure — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-182: telemetry disclosure — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-183: telemetry disclosure — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-184: telemetry disclosure — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **telemetry disclosure**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to telemetry disclosure.
- **Authority:** Determine the authoritative source for telemetry disclosure and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by telemetry disclosure.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-185: retention claims — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-186: retention claims — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-187: retention claims — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-188: retention claims — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-189: retention claims — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-190: retention claims — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-191: retention claims — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-192: retention claims — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **retention claims**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to retention claims.
- **Authority:** Determine the authoritative source for retention claims and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by retention claims.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-193: maintainer ownership — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-194: maintainer ownership — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-195: maintainer ownership — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-196: maintainer ownership — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-197: maintainer ownership — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-198: maintainer ownership — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-199: maintainer ownership — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-200: maintainer ownership — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **maintainer ownership**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to maintainer ownership.
- **Authority:** Determine the authoritative source for maintainer ownership and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by maintainer ownership.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-201: release authority — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-202: release authority — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-203: release authority — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-204: release authority — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-205: release authority — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-206: release authority — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-207: release authority — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-208: release authority — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **release authority**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to release authority.
- **Authority:** Determine the authoritative source for release authority and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by release authority.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-209: exception process — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-210: exception process — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-211: exception process — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-212: exception process — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-213: exception process — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-214: exception process — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-215: exception process — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-216: exception process — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **exception process**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to exception process.
- **Authority:** Determine the authoritative source for exception process and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by exception process.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-217: archival policy — declared policy

- **Control intent:** Establish reliable evidence about **declared policy** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to declared policy.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about declared policy could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-218: archival policy — repository evidence

- **Control intent:** Establish reliable evidence about **repository evidence** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to repository evidence.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about repository evidence could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-219: archival policy — third-party obligation

- **Control intent:** Establish reliable evidence about **third-party obligation** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to third-party obligation.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about third-party obligation could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-220: archival policy — distribution impact

- **Control intent:** Establish reliable evidence about **distribution impact** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to distribution impact.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about distribution impact could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-221: archival policy — ownership and approval

- **Control intent:** Establish reliable evidence about **ownership and approval** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to ownership and approval.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about ownership and approval could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-222: archival policy — documentation consistency

- **Control intent:** Establish reliable evidence about **documentation consistency** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to documentation consistency.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about documentation consistency could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-223: archival policy — exception handling

- **Control intent:** Establish reliable evidence about **exception handling** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to exception handling.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about exception handling could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.

### LICENSE-COMPLIANCE-AND-PROJECT-GOVERNANCE-REVIEW-PROMPT-RC-224: archival policy — review and renewal

- **Control intent:** Establish reliable evidence about **review and renewal** for **archival policy**.
- **Locate:** Identify every in-scope implementation, configuration, declaration, generated representation, test, document, and operational dependency related to archival policy.
- **Authority:** Determine the authoritative source for archival policy and identify duplicated, derived, stale, or conflicting representations.
- **Trace:** Trace inputs, outputs, dependencies, dependents, lifecycle, state changes, side effects, and failure behavior relevant to review and renewal.
- **Contracts:** Check public, internal, data, security, operational, and compatibility contracts affected by archival policy.
- **Variants:** Check supported platforms, environments, feature flags, versions, deployment modes, and optional components.
- **Risk questions:** Identify how incorrect assumptions about review and renewal could cause defects, outages, data loss, security exposure, documentation drift, or maintenance cost.
- **Evidence required:** Record exact paths, symbols, keys, commands, outputs, diagrams, schemas, or reproducible observations.
- **Classification:** Mark the result `Verified`, `Inferred`, `Unknown`, `Not Applicable`, or `Needs Manual Review`.
- **Action rule:** Prefer the smallest proportionate action that addresses the root cause without introducing unrelated change.
- **Verification:** Define a targeted check and at least one broader regression check when a change is proposed or applied.
- **Report:** Summarize current state, gap, impact, confidence, recommended owner, priority, and completion condition.


## Mandatory License Compliance and Project Governance Review Prompt Report Output Contract

Produce a report titled **License Compliance and Project Governance Review Prompt Report** with the following sections:

### 1. Project license

Document project license using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 2. Metadata consistency

Document metadata consistency using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 3. Third-party materials

Document third-party materials using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 4. Dependency licenses

Document dependency licenses using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 5. Distribution obligations

Document distribution obligations using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 6. Privacy and telemetry alignment

Document privacy and telemetry alignment using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 7. Governance and ownership

Document governance and ownership using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 8. Missing policies

Document missing policies using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 9. Legal-review items

Document legal-review items using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

### 10. Remediation

Document remediation using evidence, status labels, risks, decisions, verification, and unresolved questions where applicable.

## Final Quality Gate

- Confirm every material claim has evidence or an explicit inference label.
- Confirm no secret or private data is exposed.
- Confirm the reported scope matches the inspected scope.
- Confirm unsupported files, platforms, environments, and tool failures are listed.
- Confirm proposed work is separated from applied work.
- Confirm exact verification outcomes are included.
- Confirm no completion claim exceeds available evidence.
- End with `PASS`, `PASS_WITH_CONDITIONS`, `FAIL`, or `INCOMPLETE` and a concise rationale.
