---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-MIGRATION-3-1
title: Migration from Version 3.1 to 3.2.0
document_type: migration_guide
status: stable
description: Explains generated-output storage, project-context relocation, and lowercase snake-case migration for version 3.2.
last_updated: '2026-07-11'
---

# Migration from Version 3.1 to 3.2.0

## Summary

Version 3.2.0 adds a mandatory generated-output contract to every prompt.

## Breaking Behavioral Changes

### Project Context

Old or incorrect placement:

```text
docs/prompts/Project_Context.yaml
```

Canonical placement:

```text
.prompt_suite/context/project_context.yaml
```

### Generic Output Directories

Retire:

```text
output/
outputs/
prompts/output/
docs/prompts/
```

Use:

```text
.prompt_suite/
docs/
reports/
plans/
artifacts/
logs/
```

### Generated Filename Style

Retire uppercase, title case, spaces, hyphens, and prompt-sequence prefixes.

Old:

```text
03_PROJECT_DISCOVERY.md
Security-Audit-FINAL.md
Project_Context.yaml
```

New:

```text
project_discovery_report.md
security_audit_report.md
project_context.yaml
```

## Required Runner Changes

Prompt runners should read `output_contract` from YAML frontmatter and:

1. resolve paths from the audited project root;
2. create required directories only when authorized;
3. preserve existing files;
4. record generated files in the run manifest;
5. enforce lowercase `snake_case`;
6. write logs under `logs`;
7. keep documentation under `docs`;
8. keep prompt state under `.prompt_suite`.

## Existing Output Migration

Move existing files according to their purpose.

| Existing Type | New Root |
|---|---|
| Prompt context | `.prompt_suite/context/` |
| Audit or review report | `reports/` |
| Future work or remediation plan | `plans/` |
| JSON, CSV, diagrams, inventories | `artifacts/` |
| Execution log or transcript | `logs/` |
| Maintained documentation | `docs/` |

Do not move files automatically when their purpose or authority is unclear.
