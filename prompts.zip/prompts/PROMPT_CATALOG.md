---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-CATALOG
title: Prompt Catalog
document_type: catalog
status: stable
description: Provides the canonical human-readable inventory, routing guidance, dependencies, outputs, modes, and use boundaries for every prompt.
last_updated: '2026-07-11'
---

# Prompt Catalog

This catalog answers:

- which prompt to use;
- when to use it;
- when not to use it;
- what it requires;
- what it produces;
- what risk and change authority it carries;
- where it fits in a larger workflow.

**Suite version:** `3.2.0`  
**Prompt count:** **25**  
**Specialist prompt count:** **23**

## Selection Rules

1. Start with `UPPS-00` and `UPPS-01` for any consequential task.
2. Use `UPPS-02` when the task spans multiple domains or the correct route is unclear.
3. Use `UPPS-03` before broad claims about an unfamiliar repository.
4. Use specialist prompts for depth; do not ask the health audit to replace them.
5. Use `UPPS-24` to consolidate project health and remaining work.
6. Use `UPPS-23` only for an exact release candidate and target environment.
7. Do not load the entire suite into one model context.

## Canonical Prompt Inventory

| Seq. | ID | Prompt | Category | Type | Default Mode | Risk | Lines |
|---:|---|---|---|---|---|---|---:|
| 00 | `UPPS-00` | [Project Context Template](prompts/00_PROJECT_CONTEXT_TEMPLATE.md) | `core` | `template` | `AUDIT_ONLY` | `low` | 111 |
| 01 | `UPPS-01` | [Universal Execution Contract](prompts/01_UNIVERSAL_EXECUTION_CONTRACT.md) | `core` | `contract` | `AUDIT_ONLY` | `medium` | 277 |
| 02 | `UPPS-02` | [Master Project Orchestrator](prompts/02_MASTER_PROJECT_ORCHESTRATOR.md) | `orchestration` | `orchestrator` | `AUDIT_ONLY` | `high` | 2,927 |
| 03 | `UPPS-03` | [Project Discovery and Inventory](prompts/03_PROJECT_DISCOVERY_AND_INVENTORY.md) | `discovery` | `audit` | `AUDIT_ONLY` | `medium` | 3,517 |
| 04 | `UPPS-04` | [Threat Modeling](prompts/04_THREAT_MODELING.md) | `security` | `analysis` | `AUDIT_ONLY` | `high` | 3,501 |
| 05 | `UPPS-05` | [Master Security Audit](prompts/05_MASTER_SECURITY_AUDIT.md) | `security` | `audit` | `AUDIT_ONLY` | `critical` | 1,538 |
| 06 | `UPPS-06` | [Security Remediation and Verification](prompts/06_SECURITY_REMEDIATION_AND_VERIFICATION.md) | `security` | `remediation` | `PLAN_ONLY` | `critical` | 3,501 |
| 07 | `UPPS-07` | [Comprehensive Project Documentation](prompts/07_COMPREHENSIVE_PROJECT_DOCUMENTATION.md) | `documentation` | `generation` | `PLAN_ONLY` | `medium` | 4,249 |
| 08 | `UPPS-08` | [Architecture and System Design Review](prompts/08_ARCHITECTURE_AND_SYSTEM_DESIGN_REVIEW.md) | `engineering` | `review` | `AUDIT_ONLY` | `high` | 3,492 |
| 09 | `UPPS-09` | [Code Quality and Maintainability Review](prompts/09_CODE_QUALITY_AND_MAINTAINABILITY_REVIEW.md) | `engineering` | `review` | `AUDIT_ONLY` | `high` | 3,253 |
| 10 | `UPPS-10` | [Testing and Verification Review](prompts/10_TESTING_AND_VERIFICATION_REVIEW.md) | `engineering` | `review` | `AUDIT_ONLY` | `high` | 3,487 |
| 11 | `UPPS-11` | [Safe Cleanup and Repository Hygiene](prompts/11_SAFE_CLEANUP_AND_REPOSITORY_HYGIENE.md) | `engineering` | `transformation` | `AUDIT_ONLY` | `high` | 3,999 |
| 12 | `UPPS-12` | [Safe Refactoring and Modernization](prompts/12_SAFE_REFACTORING_AND_MODERNIZATION.md) | `engineering` | `transformation` | `PLAN_ONLY` | `critical` | 3,499 |
| 13 | `UPPS-13` | [Dependency and Supply Chain Review](prompts/13_DEPENDENCY_AND_SUPPLY_CHAIN_REVIEW.md) | `security` | `review` | `AUDIT_ONLY` | `critical` | 3,488 |
| 14 | `UPPS-14` | [Configuration, Environment, and Secrets Review](prompts/14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md) | `security` | `review` | `AUDIT_ONLY` | `critical` | 3,479 |
| 15 | `UPPS-15` | [API, CLI, and Public Contract Review](prompts/15_API_CLI_AND_PUBLIC_CONTRACT_REVIEW.md) | `contracts` | `review` | `AUDIT_ONLY` | `critical` | 3,482 |
| 16 | `UPPS-16` | [Data Storage, Schema, and Migration Review](prompts/16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md) | `data` | `review` | `AUDIT_ONLY` | `critical` | 3,728 |
| 17 | `UPPS-17` | [Performance and Efficiency Review](prompts/17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md) | `engineering` | `review` | `AUDIT_ONLY` | `high` | 3,604 |
| 18 | `UPPS-18` | [Reliability, Resilience, and Recovery Review](prompts/18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md) | `operations` | `review` | `AUDIT_ONLY` | `critical` | 3,729 |
| 19 | `UPPS-19` | [CI/CD, Build, Release, and Deployment Review](prompts/19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md) | `delivery` | `review` | `AUDIT_ONLY` | `critical` | 3,607 |
| 20 | `UPPS-20` | [Observability and Operations Review](prompts/20_OBSERVABILITY_AND_OPERATIONS_REVIEW.md) | `operations` | `review` | `AUDIT_ONLY` | `high` | 3,601 |
| 21 | `UPPS-21` | [Incident Response and Recovery](prompts/21_INCIDENT_RESPONSE_AND_RECOVERY.md) | `operations` | `response` | `PLAN_ONLY` | `critical` | 3,735 |
| 22 | `UPPS-22` | [License, Compliance, and Governance Review](prompts/22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md) | `governance` | `review` | `AUDIT_ONLY` | `high` | 3,714 |
| 23 | `UPPS-23` | [Release Readiness and Final Audit](prompts/23_RELEASE_READINESS_AND_FINAL_AUDIT.md) | `release` | `gate` | `VERIFY_ONLY` | `critical` | 3,747 |
| 24 | `UPPS-24` | [Comprehensive Project Health and Completeness Audit](prompts/24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md) | `governance` | `audit` | `AUDIT_ONLY` | `critical` | 3,771 |

## Prompt Details

### UPPS-00 — Project Context Template

**Canonical file:** `prompts/00_PROJECT_CONTEXT_TEMPLATE.md`  
**Category / type:** `core` / `template`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `low`  
**Hard prerequisites:** None  
**Related prompts:** `UPPS-01`, `UPPS-02`

**Use when:** Use first to collect project identity, task objectives, exclusions, permissions, supported environments, commands, and acceptance criteria.

**Do not use when:** Do not use it as an audit or implementation prompt.

**Primary outputs:** Normalized project context, permission boundary, and verification requirements.

### UPPS-01 — Universal Execution Contract

**Canonical file:** `prompts/01_UNIVERSAL_EXECUTION_CONTRACT.md`  
**Category / type:** `core` / `contract`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `medium`  
**Hard prerequisites:** `UPPS-00`  
**Related prompts:** `UPPS-00`, `UPPS-02`

**Use when:** Use to impose evidence, safety, change-control, secret-protection, and completion rules on every suite task.

**Do not use when:** Do not treat it as a substitute for a specialist prompt.

**Primary outputs:** Execution boundary, evidence standard, and completion gate.

### UPPS-02 — Master Project Orchestrator

**Canonical file:** `prompts/02_MASTER_PROJECT_ORCHESTRATOR.md`  
**Category / type:** `orchestration` / `orchestrator`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-00`, `UPPS-01`  
**Related prompts:** `UPPS-03`, `UPPS-05`, `UPPS-23`

**Use when:** Use for broad, ambiguous, multi-domain, or release-scale work that needs routing and consolidation.

**Do not use when:** Avoid for a single well-bounded specialist task when routing is already known.

**Primary outputs:** Specialist execution plan, consolidated findings, and completion decision.

### UPPS-03 — Project Discovery and Inventory

**Canonical file:** `prompts/03_PROJECT_DISCOVERY_AND_INVENTORY.md`  
**Category / type:** `discovery` / `audit`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `medium`  
**Hard prerequisites:** `UPPS-00`, `UPPS-01`  
**Related prompts:** `UPPS-02`, `UPPS-04`, `UPPS-05`, `UPPS-07`

**Use when:** Use for an unfamiliar repository or whenever architecture, entry points, commands, boundaries, and source-of-truth files are unclear.

**Do not use when:** Avoid repeating it unchanged when a current verified inventory already exists.

**Primary outputs:** Repository inventory, entry-point map, component map, and coverage limitations.

### UPPS-04 — Threat Modeling

**Canonical file:** `prompts/04_THREAT_MODELING.md`  
**Category / type:** `security` / `analysis`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-05`, `UPPS-06`, `UPPS-15`, `UPPS-16`

**Use when:** Use before deep security work, permission expansion, external exposure, AI tool access, or major architecture changes.

**Do not use when:** Do not use it as a vulnerability scanner or remediation prompt.

**Primary outputs:** Threat model, abuse cases, trust boundaries, and validation priorities.

### UPPS-05 — Master Security Audit

**Canonical file:** `prompts/05_MASTER_SECURITY_AUDIT.md`  
**Category / type:** `security` / `audit`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-04`  
**Related prompts:** `UPPS-04`, `UPPS-06`, `UPPS-13`, `UPPS-14`, `UPPS-21`

**Use when:** Use for a defensive full-spectrum security audit of code, dependencies, configuration, CI/CD, infrastructure, assets, and supply chain.

**Do not use when:** Do not use it to implement fixes; use UPPS-06 after findings are validated.

**Primary outputs:** Security report, finding register, attack-surface map, and remediation roadmap.

### UPPS-06 — Security Remediation and Verification

**Canonical file:** `prompts/06_SECURITY_REMEDIATION_AND_VERIFICATION.md`  
**Category / type:** `security` / `remediation`  
**Default mode:** `PLAN_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-05`  
**Related prompts:** `UPPS-04`, `UPPS-05`, `UPPS-10`, `UPPS-23`

**Use when:** Use after validated security findings require root-cause remediation, regression tests, and closure evidence.

**Do not use when:** Do not use before the issue is validated or without change authorization.

**Primary outputs:** Remediation plan, fixes, regression tests, and closure evidence.

### UPPS-07 — Comprehensive Project Documentation

**Canonical file:** `prompts/07_COMPREHENSIVE_PROJECT_DOCUMENTATION.md`  
**Category / type:** `documentation` / `generation`  
**Default mode:** `PLAN_ONLY`  
**Risk:** `medium`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-03`, `UPPS-08`, `UPPS-15`, `UPPS-23`

**Use when:** Use to design or rebuild a complete, proportionate documentation system from repository evidence.

**Do not use when:** Do not use merely to produce a huge README or fabricate unsupported project behavior.

**Primary outputs:** Documentation architecture, project docs, and documentation-gap register.

### UPPS-08 — Architecture and System Design Review

**Canonical file:** `prompts/08_ARCHITECTURE_AND_SYSTEM_DESIGN_REVIEW.md`  
**Category / type:** `engineering` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-03`, `UPPS-04`, `UPPS-09`, `UPPS-18`

**Use when:** Use when system boundaries, data flow, deployment topology, quality attributes, or architectural tradeoffs need reconstruction and review.

**Do not use when:** Avoid using it to justify a fashionable rewrite without evidence.

**Primary outputs:** Architecture map, quality-attribute assessment, and incremental design plan.

### UPPS-09 — Code Quality and Maintainability Review

**Canonical file:** `prompts/09_CODE_QUALITY_AND_MAINTAINABILITY_REVIEW.md`  
**Category / type:** `engineering` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`, `UPPS-08`  
**Related prompts:** `UPPS-08`, `UPPS-10`, `UPPS-11`, `UPPS-12`

**Use when:** Use for correctness, maintainability, clarity, error design, resource lifecycle, and developer-experience review.

**Do not use when:** Do not turn personal style preferences into defects.

**Primary outputs:** Quality findings, maintainability assessment, and refactoring candidates.

### UPPS-10 — Testing and Verification Review

**Canonical file:** `prompts/10_TESTING_AND_VERIFICATION_REVIEW.md`  
**Category / type:** `engineering` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-06`, `UPPS-09`, `UPPS-11`, `UPPS-12`, `UPPS-23`

**Use when:** Use to establish verification baseline, map tests to risks and contracts, and identify confidence gaps.

**Do not use when:** Do not equate line coverage or passing tests with proven correctness.

**Primary outputs:** Verification baseline, test-gap analysis, and regression strategy.

### UPPS-11 — Safe Cleanup and Repository Hygiene

**Canonical file:** `prompts/11_SAFE_CLEANUP_AND_REPOSITORY_HYGIENE.md`  
**Category / type:** `engineering` / `transformation`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`, `UPPS-05`, `UPPS-10`  
**Related prompts:** `UPPS-05`, `UPPS-09`, `UPPS-10`, `UPPS-12`

**Use when:** Use to identify and apply behavior-preserving cleanup after security and verification baselines exist.

**Do not use when:** Do not delete based only on zero textual references or mix cleanup with feature work.

**Primary outputs:** Cleanup candidate register, safe batches, and verification results.

### UPPS-12 — Safe Refactoring and Modernization

**Canonical file:** `prompts/12_SAFE_REFACTORING_AND_MODERNIZATION.md`  
**Category / type:** `engineering` / `transformation`  
**Default mode:** `PLAN_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-05`, `UPPS-09`, `UPPS-10`  
**Related prompts:** `UPPS-08`, `UPPS-09`, `UPPS-10`, `UPPS-11`, `UPPS-15`

**Use when:** Use for planned architectural or implementation modernization with compatibility and rollback controls.

**Do not use when:** Do not use for an unbounded rewrite or before tests, contracts, and security implications are understood.

**Primary outputs:** Refactoring plan, compatibility plan, and verified change batches.

### UPPS-13 — Dependency and Supply Chain Review

**Canonical file:** `prompts/13_DEPENDENCY_AND_SUPPLY_CHAIN_REVIEW.md`  
**Category / type:** `security` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-05`, `UPPS-14`, `UPPS-19`, `UPPS-22`

**Use when:** Use for dependencies, lockfiles, registries, install/build execution, container bases, CI actions, SBOM, and provenance.

**Do not use when:** Do not infer maliciousness solely from package age, unfamiliarity, or popularity.

**Primary outputs:** Dependency inventory, supply-chain findings, provenance assessment, and upgrade plan.

### UPPS-14 — Configuration, Environment, and Secrets Review

**Canonical file:** `prompts/14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md`  
**Category / type:** `security` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-05`, `UPPS-13`, `UPPS-19`, `UPPS-20`

**Use when:** Use for configuration sources, precedence, validation, environment drift, safe defaults, and secret lifecycle.

**Do not use when:** Do not expose or test live credentials.

**Primary outputs:** Configuration map, secret-handling assessment, and environment-drift report.

### UPPS-15 — API, CLI, and Public Contract Review

**Canonical file:** `prompts/15_API_CLI_AND_PUBLIC_CONTRACT_REVIEW.md`  
**Category / type:** `contracts` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`  
**Related prompts:** `UPPS-07`, `UPPS-12`, `UPPS-16`, `UPPS-19`

**Use when:** Use before changing APIs, CLIs, schemas, events, package exports, configuration keys, file formats, or compatibility promises.

**Do not use when:** Do not treat internal implementation details as public contracts without evidence.

**Primary outputs:** Contract inventory, compatibility assessment, and deprecation plan.

### UPPS-16 — Data Storage, Schema, and Migration Review

**Canonical file:** `prompts/16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md`  
**Category / type:** `data` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-15`  
**Related prompts:** `UPPS-04`, `UPPS-15`, `UPPS-18`, `UPPS-21`

**Use when:** Use before schema, storage, migration, retention, backup, restore, or data-lifecycle changes.

**Do not use when:** Do not connect to or mutate production without explicit authorization.

**Primary outputs:** Data inventory, schema assessment, migration plan, and recovery plan.

### UPPS-17 — Performance and Efficiency Review

**Canonical file:** `prompts/17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md`  
**Category / type:** `engineering` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`, `UPPS-10`  
**Related prompts:** `UPPS-08`, `UPPS-10`, `UPPS-18`, `UPPS-20`

**Use when:** Use when latency, throughput, CPU, memory, I/O, build time, startup, bundle size, or cost need evidence-based improvement.

**Do not use when:** Do not optimize from intuition alone.

**Primary outputs:** Performance baseline, bottleneck findings, optimization plan, and budgets.

### UPPS-18 — Reliability, Resilience, and Recovery Review

**Canonical file:** `prompts/18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md`  
**Category / type:** `operations` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-08`, `UPPS-16`  
**Related prompts:** `UPPS-16`, `UPPS-17`, `UPPS-20`, `UPPS-21`

**Use when:** Use for timeout, retry, idempotency, overload, partial failure, crash, restart, backup, and disaster-recovery analysis.

**Do not use when:** Do not infer resilience from happy-path tests.

**Primary outputs:** Failure model, resilience findings, recovery plan, and fault-injection plan.

### UPPS-19 — CI/CD, Build, Release, and Deployment Review

**Canonical file:** `prompts/19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md`  
**Category / type:** `delivery` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-13`, `UPPS-14`, `UPPS-16`, `UPPS-18`  
**Related prompts:** `UPPS-13`, `UPPS-14`, `UPPS-16`, `UPPS-20`, `UPPS-23`

**Use when:** Use for local build through CI, artifact creation, signing, release, deployment, migration order, promotion, and rollback.

**Do not use when:** Do not use it as the final release authority; UPPS-23 owns that decision.

**Primary outputs:** Pipeline map, build assessment, release assessment, and deployment/rollback plan.

### UPPS-20 — Observability and Operations Review

**Canonical file:** `prompts/20_OBSERVABILITY_AND_OPERATIONS_REVIEW.md`  
**Category / type:** `operations` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`, `UPPS-18`  
**Related prompts:** `UPPS-14`, `UPPS-17`, `UPPS-18`, `UPPS-21`

**Use when:** Use for logs, metrics, traces, health checks, alerts, dashboards, runbooks, and operator diagnostics.

**Do not use when:** Do not add telemetry without privacy, cardinality, cost, and operational-value review.

**Primary outputs:** Observability map, operational gaps, and runbook plan.

### UPPS-21 — Incident Response and Recovery

**Canonical file:** `prompts/21_INCIDENT_RESPONSE_AND_RECOVERY.md`  
**Category / type:** `operations` / `response`  
**Default mode:** `PLAN_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-05`, `UPPS-16`, `UPPS-18`, `UPPS-20`  
**Related prompts:** `UPPS-05`, `UPPS-16`, `UPPS-18`, `UPPS-20`

**Use when:** Use to prepare for or respond to incidents through triage, containment, evidence preservation, recovery, communication, and learning.

**Do not use when:** Do not execute containment or eradication actions without appropriate authorization.

**Primary outputs:** Incident plan, containment playbooks, and recovery/learning plan.

### UPPS-22 — License, Compliance, and Governance Review

**Canonical file:** `prompts/22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md`  
**Category / type:** `governance` / `review`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `high`  
**Hard prerequisites:** `UPPS-03`, `UPPS-13`  
**Related prompts:** `UPPS-07`, `UPPS-13`, `UPPS-23`

**Use when:** Use for project licensing, third-party materials, privacy claims, notices, ownership, contribution, and governance.

**Do not use when:** Do not present its findings as final legal advice.

**Primary outputs:** License inventory, compliance findings, and governance-gap report.

### UPPS-23 — Release Readiness and Final Audit

**Canonical file:** `prompts/23_RELEASE_READINESS_AND_FINAL_AUDIT.md`  
**Category / type:** `release` / `gate`  
**Default mode:** `VERIFY_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-03`, `UPPS-05`, `UPPS-10`, `UPPS-13`, `UPPS-14`, `UPPS-16`, `UPPS-18`, `UPPS-19`, `UPPS-20`, `UPPS-22`  
**Related prompts:** `UPPS-02`, `UPPS-05`, `UPPS-07`, `UPPS-19`, `UPPS-22`

**Use when:** Use for an exact release candidate, revision, artifact set, target environment, and named release criteria.

**Do not use when:** Do not use it as a generic project backlog audit or substitute for specialist reviews.

**Primary outputs:** Release scorecard, accepted-risk register, and GO/NO-GO decision.

### UPPS-24 — Comprehensive Project Health and Completeness Audit

**Canonical file:** `prompts/24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md`  
**Category / type:** `governance` / `audit`  
**Default mode:** `AUDIT_ONLY`  
**Risk:** `critical`  
**Hard prerequisites:** `UPPS-00`, `UPPS-01`, `UPPS-03`  
**Related prompts:** `UPPS-02`, `UPPS-03`, `UPPS-05`, `UPPS-07`, `UPPS-10`, `UPPS-11`, `UPPS-12`, `UPPS-23`

**Use when:** Use for a whole-project health and completeness audit, remaining-work discovery, contradiction reconciliation, and actionable backlog consolidation.

**Do not use when:** Do not use it as a replacement for deep security analysis or as the authoritative release gate.

**Primary outputs:** Health scorecard, completeness matrix, issue register, remaining-work backlog, decision register, and phased plan.

## Category Summary

| Category | Prompt Count |
|---|---:|
| `contracts` | 1 |
| `core` | 2 |
| `data` | 1 |
| `delivery` | 1 |
| `discovery` | 1 |
| `documentation` | 1 |
| `engineering` | 6 |
| `governance` | 2 |
| `operations` | 3 |
| `orchestration` | 1 |
| `release` | 1 |
| `security` | 5 |

## Quick Routing Index

| Need | Start With | Common Follow-Up |
|---|---|---|
| Unknown repository | `UPPS-03` | `UPPS-02`, then selected specialists |
| Full project audit | `UPPS-02` + `UPPS-03` | Specialists, then `UPPS-24` |
| Find all remaining work | `UPPS-24` | Specialist prompts for uncertain domains |
| Security audit | `UPPS-04` + `UPPS-05` | `UPPS-06` |
| Documentation system | `UPPS-07` | `UPPS-24` or `UPPS-23` |
| Cleanup | `UPPS-10`, `UPPS-05`, then `UPPS-11` | `UPPS-23` if releasing |
| Refactor | `UPPS-08`, `UPPS-09`, `UPPS-10`, `UPPS-15` | `UPPS-12` |
| Dependency upgrade | `UPPS-13` | `UPPS-05`, `UPPS-10`, `UPPS-19` |
| API/CLI change | `UPPS-15` | `UPPS-10`, `UPPS-07` |
| Data migration | `UPPS-16` | `UPPS-18`, `UPPS-19`, `UPPS-21` |
| Performance work | `UPPS-17` | `UPPS-10`, `UPPS-20` |
| Reliability work | `UPPS-18` | `UPPS-20`, `UPPS-21` |
| Production deployment | `UPPS-19` | `UPPS-23` |
| Incident | `UPPS-21` | `UPPS-05`, `UPPS-18`, `UPPS-20` |
| Release decision | `UPPS-23` | None; it is the final gate |


## Canonical Generated Output Map

Paths in this table are relative to `PROJECT_ROOT`.

| ID | Primary Output | Supporting Roots | Log Root |
|---|---|---|---|
| `UPPS-00` | `./.prompt_suite/context/project_context.yaml` | `./.prompt_suite/` | `./logs/prompt_runs/` |
| `UPPS-01` | `./.prompt_suite/contracts/universal_execution_contract.md` | `./.prompt_suite/` | `./logs/prompt_runs/` |
| `UPPS-02` | `./reports/orchestration/project_orchestration_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-03` | `./reports/discovery/project_discovery_report.md` | `./artifacts/` | `./logs/prompt_runs/` |
| `UPPS-04` | `./reports/security/threat_model.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-05` | `./reports/security/security_audit_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-06` | `./reports/security/security_remediation_verification_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-07` | `./docs/index.md` | `./artifacts/`, `./docs/`, `./reports/` | `./logs/prompt_runs/` |
| `UPPS-08` | `./reports/architecture/architecture_review_report.md` | `./artifacts/`, `./docs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-09` | `./reports/quality/code_quality_maintainability_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-10` | `./reports/testing/testing_verification_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-11` | `./reports/cleanup/cleanup_repository_hygiene_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-12` | `./reports/refactoring/refactoring_modernization_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-13` | `./reports/dependencies/dependency_supply_chain_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-14` | `./reports/configuration/configuration_environment_secrets_report.md` | `./artifacts/`, `./docs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-15` | `./reports/contracts/api_cli_public_contract_report.md` | `./artifacts/`, `./docs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-16` | `./reports/data/data_storage_schema_migration_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-17` | `./reports/performance/performance_efficiency_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-18` | `./reports/reliability/reliability_resilience_recovery_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-19` | `./reports/delivery/ci_cd_build_release_deployment_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-20` | `./reports/operations/observability_operations_report.md` | `./artifacts/`, `./docs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-21` | `./reports/incidents/incident_response_recovery_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-22` | `./reports/governance/license_compliance_governance_report.md` | `./artifacts/`, `./docs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-23` | `./reports/release/release_readiness_report.md` | `./artifacts/`, `./logs/`, `./plans/` | `./logs/prompt_runs/` |
| `UPPS-24` | `./reports/project_health/project_health_completeness_audit_report.md` | `./artifacts/`, `./plans/` | `./logs/prompt_runs/` |


### Output Interpretation

- Primary reports go to `reports`.
- Documentation goes to `docs`.
- Plans go to `plans`.
- Machine-readable evidence goes to `artifacts`.
- Logs go to `logs`.
- Prompt runtime context goes to `.prompt_suite`.
- A prompt may reference several roots because its narrative, structured evidence, plan, and execution trace have different lifecycles.

### File-Writing Behavior

When output writing is not authorized, the prompt must:

1. return the complete result in chat;
2. list the canonical output paths;
3. state that no project files were written.

When output writing is authorized, the prompt must:

1. create only required directories;
2. preserve existing files unless replacement is authorized;
3. write generated names in lowercase `snake_case`;
4. record outputs in the run manifest;
5. list every created or updated file in the final response.
