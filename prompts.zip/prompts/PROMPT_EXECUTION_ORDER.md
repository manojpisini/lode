---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-EXECUTION
title: Prompt Execution Order
document_type: guide
status: stable
description: Defines default ordering, mandatory gates, branching rules, rerun triggers, parallelization boundaries, and scenario-specific execution plans.
last_updated: '2026-07-11'
---

# Prompt Execution Order

The filename is intentionally and correctly spelled `PROMPT_EXECUTION_ORDER.md`.

The numeric sequence is:

- a stable prompt identity;
- a default lifecycle hint;
- a catalog ordering mechanism.

It is **not** a command to run every prompt in numeric order.

Use prerequisites, risk, task scope, existing evidence, and the orchestrator to determine the actual execution plan.

## Global Reference Order

| Seq. | ID | Prompt | Default Role |
|---:|---|---|---|
| 00 | `UPPS-00` | [Project Context Template](prompts/00_PROJECT_CONTEXT_TEMPLATE.md) | `core` / `template` |
| 01 | `UPPS-01` | [Universal Execution Contract](prompts/01_UNIVERSAL_EXECUTION_CONTRACT.md) | `core` / `contract` |
| 02 | `UPPS-02` | [Master Project Orchestrator](prompts/02_MASTER_PROJECT_ORCHESTRATOR.md) | `orchestration` / `orchestrator` |
| 03 | `UPPS-03` | [Project Discovery and Inventory](prompts/03_PROJECT_DISCOVERY_AND_INVENTORY.md) | `discovery` / `audit` |
| 04 | `UPPS-04` | [Threat Modeling](prompts/04_THREAT_MODELING.md) | `security` / `analysis` |
| 05 | `UPPS-05` | [Master Security Audit](prompts/05_MASTER_SECURITY_AUDIT.md) | `security` / `audit` |
| 06 | `UPPS-06` | [Security Remediation and Verification](prompts/06_SECURITY_REMEDIATION_AND_VERIFICATION.md) | `security` / `remediation` |
| 07 | `UPPS-07` | [Comprehensive Project Documentation](prompts/07_COMPREHENSIVE_PROJECT_DOCUMENTATION.md) | `documentation` / `generation` |
| 08 | `UPPS-08` | [Architecture and System Design Review](prompts/08_ARCHITECTURE_AND_SYSTEM_DESIGN_REVIEW.md) | `engineering` / `review` |
| 09 | `UPPS-09` | [Code Quality and Maintainability Review](prompts/09_CODE_QUALITY_AND_MAINTAINABILITY_REVIEW.md) | `engineering` / `review` |
| 10 | `UPPS-10` | [Testing and Verification Review](prompts/10_TESTING_AND_VERIFICATION_REVIEW.md) | `engineering` / `review` |
| 11 | `UPPS-11` | [Safe Cleanup and Repository Hygiene](prompts/11_SAFE_CLEANUP_AND_REPOSITORY_HYGIENE.md) | `engineering` / `transformation` |
| 12 | `UPPS-12` | [Safe Refactoring and Modernization](prompts/12_SAFE_REFACTORING_AND_MODERNIZATION.md) | `engineering` / `transformation` |
| 13 | `UPPS-13` | [Dependency and Supply Chain Review](prompts/13_DEPENDENCY_AND_SUPPLY_CHAIN_REVIEW.md) | `security` / `review` |
| 14 | `UPPS-14` | [Configuration, Environment, and Secrets Review](prompts/14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md) | `security` / `review` |
| 15 | `UPPS-15` | [API, CLI, and Public Contract Review](prompts/15_API_CLI_AND_PUBLIC_CONTRACT_REVIEW.md) | `contracts` / `review` |
| 16 | `UPPS-16` | [Data Storage, Schema, and Migration Review](prompts/16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md) | `data` / `review` |
| 17 | `UPPS-17` | [Performance and Efficiency Review](prompts/17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md) | `engineering` / `review` |
| 18 | `UPPS-18` | [Reliability, Resilience, and Recovery Review](prompts/18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md) | `operations` / `review` |
| 19 | `UPPS-19` | [CI/CD, Build, Release, and Deployment Review](prompts/19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md) | `delivery` / `review` |
| 20 | `UPPS-20` | [Observability and Operations Review](prompts/20_OBSERVABILITY_AND_OPERATIONS_REVIEW.md) | `operations` / `review` |
| 21 | `UPPS-21` | [Incident Response and Recovery](prompts/21_INCIDENT_RESPONSE_AND_RECOVERY.md) | `operations` / `response` |
| 22 | `UPPS-22` | [License, Compliance, and Governance Review](prompts/22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md) | `governance` / `review` |
| 23 | `UPPS-23` | [Release Readiness and Final Audit](prompts/23_RELEASE_READINESS_AND_FINAL_AUDIT.md) | `release` / `gate` |
| 24 | `UPPS-24` | [Comprehensive Project Health and Completeness Audit](prompts/24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md) | `governance` / `audit` |

## Core Ordering Rules

### Rule 1 — Context Before Consequential Work

Use `UPPS-00` and `UPPS-01` before work that can change files, dependencies, contracts, data, infrastructure, external state, or release posture.

### Rule 2 — Discover Before Broad Conclusions

Use `UPPS-03` before a broad audit of an unfamiliar repository.

### Rule 3 — Threat Model Before Deep Security

Use `UPPS-04` before `UPPS-05` when assets, actors, trust boundaries, or deployment exposure are not already established.

### Rule 4 — Audit Before Remediation

Use `UPPS-05` before `UPPS-06`.

### Rule 5 — Verify Before Cleanup or Refactoring

Use `UPPS-10` before `UPPS-11` or `UPPS-12` unless an equivalent current baseline exists.

### Rule 6 — Security Before Destructive or Boundary-Changing Work

Run or revisit security before:

- broad cleanup;
- refactoring;
- dependency replacement;
- permission changes;
- authentication or authorization changes;
- AI tool-access expansion;
- data migration;
- production deployment.

### Rule 7 — Contracts Before Breaking Changes

Use `UPPS-15` before modifying:

- APIs;
- CLIs;
- events;
- schemas;
- package exports;
- configuration keys;
- file formats;
- public paths;
- compatibility guarantees.

### Rule 8 — Data Review Before Data Mutation

Use `UPPS-16` before migrations, retention changes, destructive cleanup, backfills, or source-of-truth changes.

### Rule 9 — Reliability and Operations Before Production Exposure

Use `UPPS-18`, `UPPS-19`, and `UPPS-20` before production deployment when failure handling and operations matter.

### Rule 10 — Health Audit Before Release Gate for Broad Releases

Use `UPPS-24` to consolidate project health and remaining work before `UPPS-23`.

`UPPS-23` remains the authoritative release gate.

## Mandatory Gate Chains

### Security Gate

```text
UPPS-03 Project Discovery
        ↓
UPPS-04 Threat Modeling
        ↓
UPPS-05 Master Security Audit
        ↓
UPPS-06 Security Remediation and Verification
```

`UPPS-06` runs only when validated findings require changes.

### Behavior-Preserving Cleanup Gate

```text
UPPS-03 Discovery
        ↓
UPPS-05 Security Audit
        ↓
UPPS-10 Testing and Verification
        ↓
UPPS-11 Safe Cleanup
        ↓
UPPS-10 Verification Rerun
```

### Safe Refactoring Gate

```text
UPPS-03 Discovery
        ↓
UPPS-08 Architecture
        ↓
UPPS-09 Code Quality
        ↓
UPPS-10 Testing
        ↓
UPPS-15 Public Contracts
        ↓
UPPS-05 Security Review
        ↓
UPPS-12 Safe Refactoring
        ↓
UPPS-10 + affected specialists rerun
```

### Data Migration Gate

```text
UPPS-15 Contracts
        ↓
UPPS-16 Data and Migration
        ↓
UPPS-18 Reliability and Recovery
        ↓
UPPS-19 Deployment and Rollback
        ↓
UPPS-21 Incident/Recovery Preparedness
        ↓
UPPS-23 Release Gate
```

### Production Release Gate

```text
Specialist reviews
        ↓
UPPS-24 Project Health and Completeness
        ↓
UPPS-23 Release Readiness and Final Audit
```

## Scenario 1 — Unknown Repository, Full Assessment

Use when the repository is unfamiliar and the user asks for a complete audit.

1. `UPPS-00` — capture context and permissions.
2. `UPPS-01` — establish safety and evidence rules.
3. `UPPS-02` — route the audit.
4. `UPPS-03` — establish repository ground truth.
5. `UPPS-04` — establish the threat model.
6. `UPPS-05` — perform the security audit.
7. Run selected specialist prompts based on discovered technologies and risks.
8. `UPPS-24` — consolidate project health, completeness, contradictions, and remaining work.
9. `UPPS-23` — only when an exact release decision is requested.

## Scenario 2 — Rapid Repository Triage

Use when time is constrained and the objective is to identify the highest-risk next steps.

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-03` with narrowed scope.
4. `UPPS-05` for high-risk exposed surfaces.
5. `UPPS-10` for baseline confidence.
6. `UPPS-24` with emphasis on blockers and unknowns.

Do not use rapid triage to claim complete coverage.

## Scenario 3 — Whole-Project Health and Remaining-Work Audit

Use when the question is “What is still missing or unfinished?”

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-03`
4. Consume current specialist reports.
5. Run missing high-risk specialists.
6. `UPPS-24`
7. Route uncertain findings back to specialists.
8. Rerun `UPPS-24` only when a materially updated consolidated state is needed.

## Scenario 4 — Documentation Creation or Reconstruction

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-03`
4. `UPPS-07`
5. `UPPS-15` when documenting public contracts.
6. `UPPS-20` when runbooks and operations are in scope.
7. `UPPS-24` when documentation is part of a larger completeness audit.
8. `UPPS-23` when documentation is a release requirement.

## Scenario 5 — Repository Cleanup

1. `UPPS-03`
2. `UPPS-05`
3. `UPPS-10`
4. `UPPS-11` in `AUDIT_ONLY`.
5. Human review of deletion, movement, dependency, and compatibility candidates.
6. `UPPS-11` in `APPLY_SAFE` or `APPLY_APPROVED`.
7. Rerun `UPPS-10`.
8. Rerun `UPPS-05` if executable paths, permissions, dependencies, or security controls changed.
9. `UPPS-24` for updated remaining-work status.

## Scenario 6 — Legacy Modernization

1. `UPPS-03`
2. `UPPS-08`
3. `UPPS-09`
4. `UPPS-10`
5. `UPPS-04`
6. `UPPS-05`
7. `UPPS-13`
8. `UPPS-15`
9. `UPPS-16` when stored data is involved.
10. `UPPS-12` in `PLAN_ONLY`.
11. Apply modernization in small approved stages.
12. Rerun affected specialists after every stage.
13. `UPPS-24`
14. `UPPS-23` for the release candidate.

## Scenario 7 — Bug Fix

1. `UPPS-00` and `UPPS-01` for consequential fixes.
2. `UPPS-03` only when the affected path is unclear.
3. `UPPS-10` to reproduce and add a failing regression test.
4. `UPPS-09` for root-cause review.
5. `UPPS-05` if the bug has security implications.
6. Apply the minimal fix.
7. Rerun targeted and broader verification.
8. `UPPS-15` if the observable contract changes.

## Scenario 8 — Security Audit Only

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-03`
4. `UPPS-04`
5. `UPPS-05`

Stop after the report unless remediation is explicitly authorized.

## Scenario 9 — Security Remediation

1. Confirm a current `UPPS-05` finding.
2. `UPPS-06` in `PLAN_ONLY`.
3. `UPPS-10` to define regression verification.
4. `UPPS-15` if contracts change.
5. `UPPS-16` if data behavior changes.
6. Apply approved remediation.
7. Rerun `UPPS-06` verification.
8. Rerun relevant portions of `UPPS-05`.
9. Update `UPPS-24` or `UPPS-23` as applicable.

## Scenario 10 — Dependency Upgrade

1. `UPPS-03`
2. `UPPS-13`
3. `UPPS-05`
4. `UPPS-10`
5. `UPPS-15` for public behavior changes.
6. `UPPS-19` for build and artifact changes.
7. Upgrade one coherent dependency group.
8. Verify lockfile, build, tests, packaging, and runtime behavior.
9. Rerun supply-chain and security checks.
10. `UPPS-23` for release.

## Scenario 11 — Dependency Removal

1. `UPPS-03`
2. `UPPS-13`
3. `UPPS-10`
4. `UPPS-11` for reachability and cleanup classification.
5. Remove only after build-time, runtime, plugin, platform, and packaging use are excluded.
6. Verify lockfiles, packaging, supported platforms, and generated code.

## Scenario 12 — Configuration or Secret-System Change

1. `UPPS-03`
2. `UPPS-04`
3. `UPPS-05`
4. `UPPS-14`
5. `UPPS-15` for configuration-contract compatibility.
6. `UPPS-19` for environment delivery.
7. `UPPS-20` for redacted diagnostics.
8. Apply approved changes.
9. Verify local, CI, staging, and production profiles.
10. `UPPS-23` before release.

## Scenario 13 — API or CLI Change

1. `UPPS-03`
2. `UPPS-15`
3. `UPPS-10`
4. `UPPS-05`
5. `UPPS-07`
6. Apply with versioning, deprecation, or migration treatment.
7. Verify old and new clients or scripts.
8. `UPPS-24` for completeness impact.
9. `UPPS-23` for release.

## Scenario 14 — Database or Storage Migration

1. `UPPS-03`
2. `UPPS-04`
3. `UPPS-05`
4. `UPPS-15`
5. `UPPS-16`
6. `UPPS-18`
7. `UPPS-19`
8. `UPPS-20`
9. `UPPS-21`
10. Dry-run or isolated verification when authorized.
11. `UPPS-23`.

Never run production migrations merely because the plan is complete.

## Scenario 15 — Performance Optimization

1. `UPPS-03`
2. `UPPS-10`
3. `UPPS-17` to define workload and baseline.
4. `UPPS-09` for maintainability tradeoffs.
5. `UPPS-15` when latency, pagination, output, or API behavior changes.
6. Apply one measured optimization.
7. Rerun correctness tests and benchmarks.
8. `UPPS-18` if concurrency or resource behavior changed.

## Scenario 16 — Reliability Hardening

1. `UPPS-03`
2. `UPPS-08`
3. `UPPS-16` for stateful systems.
4. `UPPS-18`
5. `UPPS-20`
6. `UPPS-21`
7. `UPPS-10` for fault-injection and recovery tests.
8. `UPPS-19` for rollout and rollback.
9. `UPPS-23`.

## Scenario 17 — CI/CD or Build Pipeline Change

1. `UPPS-03`
2. `UPPS-13`
3. `UPPS-05`
4. `UPPS-14`
5. `UPPS-19`
6. `UPPS-10`
7. Apply in a least-privilege test environment.
8. Verify artifacts, caches, permissions, provenance, and rollback.
9. `UPPS-23`.

## Scenario 18 — Observability Rollout

1. `UPPS-03`
2. `UPPS-18`
3. `UPPS-20`
4. `UPPS-14` for configuration and secrets.
5. `UPPS-05` for sensitive-data exposure.
6. `UPPS-17` for overhead.
7. `UPPS-19` for deployment.
8. Verify redaction, cardinality, cost, and actionable signals.

## Scenario 19 — Active Incident

1. Use `UPPS-21` first.
2. Preserve evidence and establish authorization.
3. Use `UPPS-05` for security investigation when applicable.
4. Use `UPPS-18` for failure and recovery behavior.
5. Use `UPPS-20` for telemetry and blind spots.
6. Use `UPPS-16` for data integrity and recovery.
7. Use `UPPS-19` for controlled rollback or redeployment.
8. Use `UPPS-24` after containment to consolidate remaining corrective work.

Do not begin cleanup before evidence-preservation needs are resolved.

## Scenario 20 — AI or Agent System

1. `UPPS-03`
2. `UPPS-04`
3. `UPPS-05`
4. `UPPS-14`
5. `UPPS-15`
6. `UPPS-16` for memory, RAG, vector, and audit stores.
7. `UPPS-10` for evaluations and deterministic checks.
8. `UPPS-18` for retries, loops, cancellation, and fallback.
9. `UPPS-20` for auditability.
10. `UPPS-24` for complete agent-system backlog.
11. `UPPS-23` before production deployment.

## Scenario 21 — Open-Source Library Release

1. `UPPS-03`
2. `UPPS-10`
3. `UPPS-13`
4. `UPPS-15`
5. `UPPS-05`
6. `UPPS-07`
7. `UPPS-22`
8. `UPPS-19`
9. `UPPS-24`
10. `UPPS-23`

Emphasize package exports, semantic versioning, compatibility, licensing, provenance, examples, and installation.

## Scenario 22 — CLI or TUI Release

1. `UPPS-03`
2. `UPPS-15`
3. `UPPS-10`
4. `UPPS-14`
5. `UPPS-05`
6. `UPPS-07`
7. `UPPS-19`
8. `UPPS-24`
9. `UPPS-23`

Emphasize exit codes, scriptability, shells, path handling, signals, cancellation, installation, and platform compatibility.

## Scenario 23 — Web Application Release

1. `UPPS-03`
2. `UPPS-04`
3. `UPPS-05`
4. `UPPS-10`
5. `UPPS-13`
6. `UPPS-14`
7. `UPPS-15`
8. `UPPS-16`
9. `UPPS-17`
10. `UPPS-18`
11. `UPPS-19`
12. `UPPS-20`
13. `UPPS-22`
14. `UPPS-24`
15. `UPPS-23`

## Scenario 24 — Mobile or Desktop Application

1. `UPPS-03`
2. `UPPS-04`
3. `UPPS-05`
4. `UPPS-10`
5. `UPPS-13`
6. `UPPS-14`
7. `UPPS-15`
8. `UPPS-17`
9. `UPPS-18`
10. `UPPS-19`
11. `UPPS-22`
12. `UPPS-24`
13. `UPPS-23`

Emphasize platform permissions, signing, local storage, update channels, crash recovery, offline behavior, and distribution requirements.

## Scenario 25 — Monorepo or Multi-Service Platform

1. `UPPS-02`
2. `UPPS-03`
3. `UPPS-08`
4. `UPPS-04`
5. `UPPS-05`
6. `UPPS-10`
7. `UPPS-13`
8. `UPPS-15`
9. `UPPS-16`
10. `UPPS-18`
11. `UPPS-19`
12. `UPPS-20`
13. `UPPS-24`
14. `UPPS-23`

Audit each workspace or service and then audit integration boundaries.

## Scenario 26 — Prototype to Production

1. `UPPS-03`
2. `UPPS-24` for the initial gap map.
3. `UPPS-08`
4. `UPPS-04`
5. `UPPS-05`
6. `UPPS-10`
7. `UPPS-13`
8. `UPPS-14`
9. `UPPS-15`
10. `UPPS-16`
11. `UPPS-18`
12. `UPPS-19`
13. `UPPS-20`
14. `UPPS-22`
15. Rerun `UPPS-24`.
16. `UPPS-23`.

## Scenario 27 — Failed Release or Rollback

1. `UPPS-21`
2. `UPPS-19`
3. `UPPS-18`
4. `UPPS-20`
5. `UPPS-16` if data was affected.
6. `UPPS-05` if compromise is possible.
7. `UPPS-10` for regression reproduction.
8. `UPPS-24` for corrective backlog.
9. `UPPS-23` for the next candidate.

## Scenario 28 — Compliance or License Review

1. `UPPS-03`
2. `UPPS-13`
3. `UPPS-14`
4. `UPPS-16` for privacy and retention behavior.
5. `UPPS-22`
6. `UPPS-07` for policy and notice updates.
7. `UPPS-24` for unresolved governance work.
8. `UPPS-23` when compliance is a release criterion.

## Parallelization Rules

Some reviews can run in parallel after discovery:

- `UPPS-07`, `UPPS-08`, `UPPS-09`, and `UPPS-10` can often inspect independently.
- `UPPS-13` and `UPPS-14` can often run in parallel.
- `UPPS-17`, `UPPS-18`, and `UPPS-20` can gather evidence in parallel after architecture and runtime paths are understood.
- `UPPS-22` can often run independently after dependency and data inventories exist.

Do not parallelize when:

- one prompt changes files another prompt is auditing;
- a migration changes the baseline;
- security evidence may be destroyed;
- generated artifacts are being regenerated;
- a public contract is changing during compatibility review;
- performance measurements require a stable build;
- release readiness is being evaluated.

## Rerun Triggers

Rerun `UPPS-05` when:

- permissions change;
- dependencies change;
- external exposure changes;
- authentication or authorization changes;
- AI tools or data access expand;
- secrets or configuration systems change.

Rerun `UPPS-10` after:

- any code change;
- cleanup;
- refactoring;
- dependency upgrades;
- migration changes;
- contract changes.

Rerun `UPPS-13` after:

- dependency or base-image changes;
- build-tool changes;
- CI action changes;
- downloaded-artifact changes.

Rerun `UPPS-15` after:

- API, CLI, event, schema, export, config-key, or file-format changes.

Rerun `UPPS-16` after:

- schema, migration, persistence, retention, backup, or recovery changes.

Rerun `UPPS-19` after:

- build, CI/CD, release, deployment, migration-order, or rollback changes.

Rerun `UPPS-24` when:

- the project backlog materially changes;
- specialist findings are resolved or added;
- project scope or intended use changes;
- a major milestone needs a consolidated health view.

Rerun `UPPS-23` for every distinct release candidate or material artifact change.

## Stop Conditions

Stop execution and request review when:

- permissions conflict with the requested task;
- evidence suggests active compromise;
- secrets may be live;
- production may be contacted;
- data mutation is not authorized;
- a migration may be irreversible;
- forensic evidence may be destroyed;
- an unexpected regression appears;
- the baseline changes during an audit;
- a public contract change lacks an owner decision;
- a release gate lacks required evidence.

## Minimal Prompt Sets

| Objective | Minimum Useful Set |
|---|---|
| Understand repository | `00`, `01`, `03` |
| Route broad task | `00`, `01`, `02`, `03` |
| Security audit | `00`, `01`, `03`, `04`, `05` |
| Cleanup | `03`, `05`, `10`, `11` |
| Refactor | `03`, `08`, `09`, `10`, `15`, `12` |
| Documentation | `03`, `07` |
| Remaining-work audit | `03`, selected specialists, `24` |
| Release decision | relevant specialists, `24`, `23` |


## Generated Output Handoffs

Prompt order is also an artifact handoff order.

### Foundation Handoff

```text
UPPS-00
  → .prompt_suite/context/project_context.yaml
  → .prompt_suite/context/permission_boundary.yaml
  → .prompt_suite/context/verification_requirements.yaml

UPPS-01
  → .prompt_suite/contracts/universal_execution_contract.md
  → .prompt_suite/contracts/generated_output_contract.yaml
```

Every later prompt consumes this context.

### Discovery Handoff

```text
UPPS-03
  → reports/discovery/project_discovery_report.md
  → artifacts/inventory/repository_inventory.json
  → artifacts/inventory/entry_point_map.json
  → artifacts/inventory/component_map.json
```

Specialists should reuse these artifacts rather than reconstructing the same inventory independently.

### Security Handoff

```text
UPPS-04 threat model
  ↓
UPPS-05 security audit
  ↓
UPPS-06 remediation and verification
```

Canonical artifacts:

```text
reports/security/threat_model.md
reports/security/security_audit_report.md
plans/security/security_remediation_plan.md
artifacts/security/security_closure_evidence.json
```

### Engineering Handoff

```text
UPPS-10 verification baseline
  ↓
UPPS-11 cleanup or UPPS-12 refactoring
  ↓
UPPS-10 verification rerun
```

Execution logs belong under `logs`, not `docs`.

### Documentation Handoff

`UPPS-07` is the only prompt whose primary output is directly under `docs`.

It may consume:

- discovery reports;
- architecture reports;
- contract inventories;
- configuration inventories;
- operations reports.

It must convert verified facts into maintained documentation rather than copying raw audit reports.

### Project Health and Release Handoff

```text
specialist reports and artifacts
  ↓
UPPS-24
  → reports/project_health/project_health_completeness_audit_report.md
  → artifacts/project_health/remaining_work_backlog.json
  → plans/project_health/phased_improvement_plan.md
  ↓
UPPS-23
  → reports/release/release_readiness_report.md
  → artifacts/release/release_gate_scorecard.json
```

### Run Manifest

Every file-writing run records:

```text
.prompt_suite/runs/<run_id>/run_manifest.json
```

The manifest should include:

- prompt ID;
- suite version;
- mode;
- repository revision;
- start and end timestamps;
- inputs;
- commands;
- files created;
- files updated;
- files preserved;
- files skipped;
- validation results;
- unresolved errors.

### Log Handoff Rule

Logs support evidence but are not the source of truth for conclusions.

Reports may cite logs.

Documentation should not embed raw logs.

Plans should not claim that logged actions are completed unless verification confirms them.

### Scenario Output Examples

#### Full Project Audit

```text
reports/discovery/project_discovery_report.md
reports/security/security_audit_report.md
reports/architecture/architecture_review_report.md
reports/testing/testing_verification_report.md
reports/project_health/project_health_completeness_audit_report.md
```

#### Documentation Build

```text
docs/index.md
docs/architecture/index.md
docs/guides/index.md
docs/reference/index.md
reports/documentation/documentation_generation_report.md
```

#### Cleanup Run

```text
reports/cleanup/cleanup_repository_hygiene_report.md
plans/cleanup/cleanup_plan.md
artifacts/cleanup/cleanup_candidates.json
logs/cleanup/cleanup_execution_log.jsonl
```

#### Release Candidate

```text
reports/release/release_readiness_report.md
artifacts/release/release_gate_scorecard.json
plans/release/release_action_plan.md
logs/release/release_validation_log.txt
```
