---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-MANIFEST
title: Suite Manifest
document_type: manifest
status: stable
description: Records prompt identities, output contracts, relationships, file statistics, root artifacts, and cryptographic integrity.
last_updated: '2026-07-11'
---

# Suite Manifest

## Suite Identity

| Field | Value |
|---|---|
| Suite ID | `universal-project-prompt-suite` |
| Suite version | `3.2.0` |
| Frontmatter schema | `1.1` |
| Prompt count | **25** |
| Specialist prompt count | **23** |
| Prompt source layout | Flat `prompts/` directory |
| Generated filename convention | `lowercase_snake_case` |
| Output path base | Audited project root |
| Generated | `2026-07-11T12:40:31.841379+00:00` |

## Output Storage Model

| Root | Purpose |
|---|---|
| `.prompt_suite/` | Prompt context, contracts, run manifests, and suite state |
| `docs/` | Maintained project documentation |
| `reports/` | Human-readable audits, reviews, and assessments |
| `plans/` | Proposed or approved future work |
| `artifacts/` | Machine-readable inventories, matrices, diagrams, and evidence |
| `logs/` | Sanitized execution traces and command transcripts |
| `examples/` | Explicit examples |
| `tmp/` | Disposable intermediate files |

## Suite Statistics

| Metric | Value |
|---|---:|
| Total prompt lines | 83,588 |
| Total prompt characters | 8,477,587 |
| Total prompt bytes | 8,486,907 |
| Declared primary outputs | 25 |
| Declared supporting outputs | 98 |
| Minimum specialist lines | 1,636 |
| Maximum prompt lines | 4,358 |

## Prompt Inventory and Canonical Outputs

| ID | Seq. | Prompt File | Primary Output | Category | Type | Risk | Lines | SHA-256 |
|---|---:|---|---|---|---|---|---:|---|
| `UPPS-00` | 00 | `prompts/00_PROJECT_CONTEXT_TEMPLATE.md` | `.prompt_suite/context/project_context.yaml` | `core` | `template` | `low` | 225 | `d242432b2f4c541615b71f130610d3b1b18bed4a0d25213ae97aeb132dbf46dc` |
| `UPPS-01` | 01 | `prompts/01_UNIVERSAL_EXECUTION_CONTRACT.md` | `.prompt_suite/contracts/universal_execution_contract.md` | `core` | `contract` | `medium` | 424 | `d2b77c9c4f558483690c6d11c345ccc9e5c64f2d8d8f3bd35262355f074b87a8` |
| `UPPS-02` | 02 | `prompts/02_MASTER_PROJECT_ORCHESTRATOR.md` | `reports/orchestration/project_orchestration_report.md` | `orchestration` | `orchestrator` | `high` | 3,016 | `ee6ba3aef0ac8f77205ab5bd32fce39b9a68b389f920e147c574cd7d40637fb6` |
| `UPPS-03` | 03 | `prompts/03_PROJECT_DISCOVERY_AND_INVENTORY.md` | `reports/discovery/project_discovery_report.md` | `discovery` | `audit` | `medium` | 3,616 | `0b43622faa9d336a53a3fb30c82427d06e9c4c2a9cd589aea8c41ed8225b6857` |
| `UPPS-04` | 04 | `prompts/04_THREAT_MODELING.md` | `reports/security/threat_model.md` | `security` | `analysis` | `high` | 3,600 | `3bf5724de74fa8f7c20c4c6914e0b981fe5c58d5b084d12a04b91393c4ae7479` |
| `UPPS-05` | 05 | `prompts/05_MASTER_SECURITY_AUDIT.md` | `reports/security/security_audit_report.md` | `security` | `audit` | `critical` | 1,636 | `b2fec94b7f8cae52e1b58628f810dcd63251c2b9629f121eb3c77e6b46da2950` |
| `UPPS-06` | 06 | `prompts/06_SECURITY_REMEDIATION_AND_VERIFICATION.md` | `reports/security/security_remediation_verification_report.md` | `security` | `remediation` | `critical` | 3,595 | `cf54b17023f1d89ced4aaa790480c02ba668895cc74fed2a0f7cf67893cff809` |
| `UPPS-07` | 07 | `prompts/07_COMPREHENSIVE_PROJECT_DOCUMENTATION.md` | `docs/index.md` | `documentation` | `generation` | `medium` | 4,358 | `1d90c304e6783adc85fc2a5faa05029ae91220082f49446de3f7fde251a7983b` |
| `UPPS-08` | 08 | `prompts/08_ARCHITECTURE_AND_SYSTEM_DESIGN_REVIEW.md` | `reports/architecture/architecture_review_report.md` | `engineering` | `review` | `high` | 3,596 | `50d5545ddd2e45a106f047a146e24bbce7345c7f3e81f2d16e639d312a79df06` |
| `UPPS-09` | 09 | `prompts/09_CODE_QUALITY_AND_MAINTAINABILITY_REVIEW.md` | `reports/quality/code_quality_maintainability_report.md` | `engineering` | `review` | `high` | 3,347 | `3e3554515d41b98067ae8842936a2b20249c6b411653e7e0b917c387f1af4b28` |
| `UPPS-10` | 10 | `prompts/10_TESTING_AND_VERIFICATION_REVIEW.md` | `reports/testing/testing_verification_report.md` | `engineering` | `review` | `high` | 3,586 | `ce1bb002f8911d551a92ac3b5fa8e31a8c49de47c7b615734ced6e8e9a686a77` |
| `UPPS-11` | 11 | `prompts/11_SAFE_CLEANUP_AND_REPOSITORY_HYGIENE.md` | `reports/cleanup/cleanup_repository_hygiene_report.md` | `engineering` | `transformation` | `high` | 4,093 | `b4ac20131e7af6ec80ed3a52d2049e8f08f0bd597ce657029d9da6cbb10d6cb8` |
| `UPPS-12` | 12 | `prompts/12_SAFE_REFACTORING_AND_MODERNIZATION.md` | `reports/refactoring/refactoring_modernization_report.md` | `engineering` | `transformation` | `critical` | 3,598 | `f412761db4b4215c27642a67e53b372112e110292c7dda783ddc98fcb2363b3a` |
| `UPPS-13` | 13 | `prompts/13_DEPENDENCY_AND_SUPPLY_CHAIN_REVIEW.md` | `reports/dependencies/dependency_supply_chain_report.md` | `security` | `review` | `critical` | 3,587 | `5c38e544dd0c4cf59f2cdd3c62f72b1be67d70603071ad45b9871a0edcf2d687` |
| `UPPS-14` | 14 | `prompts/14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md` | `reports/configuration/configuration_environment_secrets_report.md` | `security` | `review` | `critical` | 3,578 | `895cb4e74fe18fd5844ee5549a699a9c74e26445669d2b73698f24549f38c3bf` |
| `UPPS-15` | 15 | `prompts/15_API_CLI_AND_PUBLIC_CONTRACT_REVIEW.md` | `reports/contracts/api_cli_public_contract_report.md` | `contracts` | `review` | `critical` | 3,586 | `af88f3f3b881ee3acb6c13dc5b141f719f54557824bedf858494eda827ae0d3f` |
| `UPPS-16` | 16 | `prompts/16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md` | `reports/data/data_storage_schema_migration_report.md` | `data` | `review` | `critical` | 3,832 | `b9f95494a7ac0b56445e688b3acf6657817b14242cb2ce046c409ed0d26e06e3` |
| `UPPS-17` | 17 | `prompts/17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md` | `reports/performance/performance_efficiency_report.md` | `engineering` | `review` | `high` | 3,703 | `56475875c9bfd2bcb409081e814a4618fe05e7ad0e512dbc0eff6895aa5e61d2` |
| `UPPS-18` | 18 | `prompts/18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md` | `reports/reliability/reliability_resilience_recovery_report.md` | `operations` | `review` | `critical` | 3,833 | `a591a1200cc751ca3e8f5912b88cf6494a2ef08bd62c0528d04ed058a0e34a83` |
| `UPPS-19` | 19 | `prompts/19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md` | `reports/delivery/ci_cd_build_release_deployment_report.md` | `delivery` | `review` | `critical` | 3,711 | `7c102667ff88d67c0b02c4ee9cf584714082722573345c5fa31bd8cd442395f2` |
| `UPPS-20` | 20 | `prompts/20_OBSERVABILITY_AND_OPERATIONS_REVIEW.md` | `reports/operations/observability_operations_report.md` | `operations` | `review` | `high` | 3,700 | `e601c96ab327405098fca61ea4f1bd507c3c5d511af10b4950fb11284ccdb5a1` |
| `UPPS-21` | 21 | `prompts/21_INCIDENT_RESPONSE_AND_RECOVERY.md` | `reports/incidents/incident_response_recovery_report.md` | `operations` | `response` | `critical` | 3,834 | `180bd499380f9ccc7b0687426b050e3f52a68872134c84e3c1581c128eb6a694` |
| `UPPS-22` | 22 | `prompts/22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md` | `reports/governance/license_compliance_governance_report.md` | `governance` | `review` | `high` | 3,813 | `9be7bc69c2408f61aadb99813c1c18cf14b59806f805eb06a9e389bcf009a9b4` |
| `UPPS-23` | 23 | `prompts/23_RELEASE_READINESS_AND_FINAL_AUDIT.md` | `reports/release/release_readiness_report.md` | `release` | `gate` | `critical` | 3,846 | `491715a402b100742f50c9f083effb8cbb29f92423baff0f6b0f7ce656d12241` |
| `UPPS-24` | 24 | `prompts/24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md` | `reports/project_health/project_health_completeness_audit_report.md` | `governance` | `audit` | `critical` | 3,875 | `58e01ffcdb2fe27718cc76ef3a57079faa1e9692990b02ea52d0a220e79f0bb3` |


## Supporting Output Inventory

| Prompt ID | Path | Format | Requirement |
|---|---|---|---|
| `UPPS-00` | `.prompt_suite/context/permission_boundary.yaml` | `yaml` | required |
| `UPPS-00` | `.prompt_suite/context/verification_requirements.yaml` | `yaml` | required |
| `UPPS-01` | `.prompt_suite/contracts/generated_output_contract.yaml` | `yaml` | required |
| `UPPS-02` | `plans/orchestration/specialist_execution_plan.md` | `markdown` | required |
| `UPPS-02` | `artifacts/orchestration/consolidated_findings.json` | `json` | required |
| `UPPS-03` | `artifacts/inventory/repository_inventory.json` | `json` | required |
| `UPPS-03` | `artifacts/inventory/entry_point_map.json` | `json` | required |
| `UPPS-03` | `artifacts/inventory/component_map.json` | `json` | required |
| `UPPS-03` | `artifacts/inventory/command_inventory.json` | `json` | required |
| `UPPS-04` | `artifacts/security/threat_register.json` | `json` | required |
| `UPPS-04` | `artifacts/security/trust_boundary_map.mmd` | `mermaid` | required |
| `UPPS-04` | `artifacts/security/attack_path_register.json` | `json` | required |
| `UPPS-04` | `plans/security/security_validation_plan.md` | `markdown` | required |
| `UPPS-05` | `artifacts/security/security_findings.json` | `json` | required |
| `UPPS-05` | `artifacts/security/attack_surface_map.json` | `json` | required |
| `UPPS-05` | `artifacts/security/secret_exposure_register.json` | `json` | required |
| `UPPS-05` | `plans/security/security_remediation_roadmap.md` | `markdown` | required |
| `UPPS-06` | `plans/security/security_remediation_plan.md` | `markdown` | required |
| `UPPS-06` | `artifacts/security/security_closure_evidence.json` | `json` | required |
| `UPPS-06` | `artifacts/security/security_regression_matrix.json` | `json` | required |
| `UPPS-07` | `docs/architecture/index.md` | `markdown` | when_applicable |
| `UPPS-07` | `docs/guides/index.md` | `markdown` | when_applicable |
| `UPPS-07` | `docs/reference/index.md` | `markdown` | when_applicable |
| `UPPS-07` | `docs/operations/index.md` | `markdown` | when_applicable |
| `UPPS-07` | `reports/documentation/documentation_generation_report.md` | `markdown` | required |
| `UPPS-07` | `artifacts/documentation/documentation_inventory.json` | `json` | required |
| `UPPS-08` | `docs/architecture/system_architecture.md` | `markdown` | when_applicable |
| `UPPS-08` | `artifacts/architecture/component_map.mmd` | `mermaid` | required |
| `UPPS-08` | `artifacts/architecture/dependency_map.json` | `json` | required |
| `UPPS-08` | `artifacts/architecture/decision_register.json` | `json` | required |
| `UPPS-08` | `plans/architecture/architecture_improvement_plan.md` | `markdown` | required |
| `UPPS-09` | `artifacts/quality/quality_findings.json` | `json` | required |
| `UPPS-09` | `artifacts/quality/maintainability_metrics.json` | `json` | required |
| `UPPS-09` | `plans/refactoring/refactoring_candidates.md` | `markdown` | required |
| `UPPS-10` | `artifacts/testing/test_gap_matrix.json` | `json` | required |
| `UPPS-10` | `artifacts/testing/verification_matrix.json` | `json` | required |
| `UPPS-10` | `plans/testing/verification_plan.md` | `markdown` | required |
| `UPPS-10` | `logs/testing/test_execution_log.txt` | `text` | when_applicable |
| `UPPS-11` | `artifacts/cleanup/cleanup_candidates.json` | `json` | required |
| `UPPS-11` | `plans/cleanup/cleanup_plan.md` | `markdown` | required |
| `UPPS-11` | `logs/cleanup/cleanup_execution_log.jsonl` | `jsonl` | when_applicable |
| `UPPS-12` | `plans/refactoring/refactoring_plan.md` | `markdown` | required |
| `UPPS-12` | `artifacts/refactoring/change_batches.json` | `json` | required |
| `UPPS-12` | `artifacts/refactoring/compatibility_matrix.json` | `json` | required |
| `UPPS-12` | `logs/refactoring/refactoring_execution_log.jsonl` | `jsonl` | when_applicable |
| `UPPS-13` | `artifacts/dependencies/dependency_inventory.json` | `json` | required |
| `UPPS-13` | `artifacts/dependencies/software_bill_of_materials.json` | `json` | when_applicable |
| `UPPS-13` | `artifacts/dependencies/provenance_inventory.json` | `json` | required |
| `UPPS-13` | `plans/dependencies/dependency_upgrade_plan.md` | `markdown` | required |
| `UPPS-14` | `artifacts/configuration/configuration_inventory.json` | `json` | required |
| `UPPS-14` | `artifacts/configuration/environment_matrix.json` | `json` | required |
| `UPPS-14` | `docs/reference/configuration_reference.md` | `markdown` | when_applicable |
| `UPPS-14` | `plans/configuration/configuration_hardening_plan.md` | `markdown` | required |
| `UPPS-15` | `artifacts/contracts/public_contract_inventory.json` | `json` | required |
| `UPPS-15` | `artifacts/contracts/compatibility_matrix.json` | `json` | required |
| `UPPS-15` | `docs/reference/api_reference.md` | `markdown` | when_applicable |
| `UPPS-15` | `docs/reference/cli_reference.md` | `markdown` | when_applicable |
| `UPPS-15` | `plans/contracts/contract_migration_plan.md` | `markdown` | required |
| `UPPS-16` | `artifacts/data/data_inventory.json` | `json` | required |
| `UPPS-16` | `artifacts/data/schema_inventory.json` | `json` | required |
| `UPPS-16` | `plans/data/migration_plan.md` | `markdown` | required |
| `UPPS-16` | `plans/data/recovery_plan.md` | `markdown` | required |
| `UPPS-16` | `logs/data/migration_validation_log.txt` | `text` | when_applicable |
| `UPPS-17` | `artifacts/performance/benchmark_results.json` | `json` | required |
| `UPPS-17` | `artifacts/performance/profile_summary.json` | `json` | required |
| `UPPS-17` | `plans/performance/optimization_plan.md` | `markdown` | required |
| `UPPS-17` | `logs/performance/benchmark_execution_log.txt` | `text` | when_applicable |
| `UPPS-18` | `artifacts/reliability/failure_mode_inventory.json` | `json` | required |
| `UPPS-18` | `artifacts/reliability/resilience_scorecard.json` | `json` | required |
| `UPPS-18` | `plans/reliability/recovery_plan.md` | `markdown` | required |
| `UPPS-18` | `plans/reliability/fault_injection_plan.md` | `markdown` | required |
| `UPPS-18` | `logs/reliability/fault_injection_log.txt` | `text` | when_applicable |
| `UPPS-19` | `artifacts/delivery/pipeline_inventory.json` | `json` | required |
| `UPPS-19` | `artifacts/delivery/artifact_inventory.json` | `json` | required |
| `UPPS-19` | `plans/delivery/deployment_plan.md` | `markdown` | required |
| `UPPS-19` | `plans/delivery/rollback_plan.md` | `markdown` | required |
| `UPPS-19` | `logs/delivery/deployment_validation_log.txt` | `text` | when_applicable |
| `UPPS-20` | `artifacts/operations/observability_inventory.json` | `json` | required |
| `UPPS-20` | `artifacts/operations/alert_inventory.json` | `json` | required |
| `UPPS-20` | `docs/operations/runbooks/index.md` | `markdown` | when_applicable |
| `UPPS-20` | `plans/operations/observability_improvement_plan.md` | `markdown` | required |
| `UPPS-21` | `plans/incidents/incident_response_plan.md` | `markdown` | required |
| `UPPS-21` | `logs/incidents/incident_timeline.jsonl` | `jsonl` | required |
| `UPPS-21` | `artifacts/incidents/evidence_manifest.json` | `json` | required |
| `UPPS-21` | `artifacts/incidents/lessons_learned_register.json` | `json` | when_applicable |
| `UPPS-22` | `artifacts/governance/license_inventory.json` | `json` | required |
| `UPPS-22` | `artifacts/governance/third_party_materials_inventory.json` | `json` | required |
| `UPPS-22` | `docs/governance/index.md` | `markdown` | when_applicable |
| `UPPS-22` | `plans/governance/compliance_remediation_plan.md` | `markdown` | required |
| `UPPS-23` | `artifacts/release/release_gate_scorecard.json` | `json` | required |
| `UPPS-23` | `artifacts/release/accepted_risk_register.json` | `json` | required |
| `UPPS-23` | `plans/release/release_action_plan.md` | `markdown` | required |
| `UPPS-23` | `logs/release/release_validation_log.txt` | `text` | when_applicable |
| `UPPS-24` | `artifacts/project_health/project_health_scorecard.json` | `json` | required |
| `UPPS-24` | `artifacts/project_health/remaining_work_backlog.json` | `json` | required |
| `UPPS-24` | `artifacts/project_health/contradiction_register.json` | `json` | required |
| `UPPS-24` | `artifacts/project_health/human_decision_register.json` | `json` | required |
| `UPPS-24` | `plans/project_health/phased_improvement_plan.md` | `markdown` | required |


## Output Contract Invariants

Every prompt declares:

- `path_base: project_root`;
- one canonical primary artifact;
- zero or more supporting artifacts;
- `logs/prompt_runs` as the shared run-log root;
- `.prompt_suite/runs/{run_id}/run_manifest.json` as the run manifest;
- lowercase `snake_case` filenames and directories;
- `preserve_existing` as the default overwrite policy;
- directory creation only when file writing is authorized;
- chat fallback when file output is not authorized.

## Corrected Project Context

```text
.prompt_suite/context/project_context.yaml
```

The project context is not documentation and must not be written under `docs/prompts`.

## Example Relocation

The uploaded project-specific discovery output was moved from:

```text
output/03_PROJECT_DISCOVERY.md
```

to:

```text
examples/generated_outputs/project_discovery_report.md
```

A real project-discovery run writes to:

```text
reports/discovery/project_discovery_report.md
```

## Root Artifact Integrity

`MANIFEST.md` and `VALIDATION.json` are not self-hashed.

| Root File | Lines | Bytes | SHA-256 |
|---|---:|---:|---|
| `README.md` | 384 | 13,540 | `da4636b8573aca31c4e1d02273fbc9cc311397b0652f68a373c044ab1596b8fb` |
| `PROMPT_CATALOG.md` | 541 | 27,865 | `42f1525c9ecdbc8f12054269464f32da22d3104cbb9369f05df23055306ba808` |
| `PROMPT_EXECUTION_ORDER.md` | 831 | 23,258 | `7588f66140d01e8c22691be7d2c3815e6b50942c34579c8ed2875d460f7a5cbd` |
| `PROMPT_SUITE_CONVENTIONS.md` | 486 | 10,727 | `29a8c5ce4955affaf492d69d67e75ebb42c0131f8ffb3ba6b0be6d61134bafc4` |
| `MIGRATION_FROM_V3_1.md` | 103 | 2,051 | `0d9109231dc71aaf641e79ba6594a9d92ee5d3215135b723aa8ce2d7d20cabfb` |
| `prompt-frontmatter.schema.json` | 316 | 6,699 | `915ec8aab0577b8594d2dbc8bd16161fe664237c5ae53609b22853f81277f68e` |
