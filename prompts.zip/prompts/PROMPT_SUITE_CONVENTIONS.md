---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-CONVENTIONS
title: Prompt Suite Conventions
document_type: specification
status: stable
description: Defines canonical filenames, YAML frontmatter, IDs, modes, relationships, content rules, and validation requirements.
last_updated: '2026-07-11'
---

# Prompt Suite Conventions

## 1. Directory Rule

All prompt assets live directly in:

```text
prompts/
```

No domain, role, workflow, or lifecycle subfolders are permitted.

Domain classification belongs in YAML frontmatter, not the filesystem.

## 2. Filename Rule

Canonical pattern:

```text
NN_DESCRIPTIVE_UPPER_SNAKE_CASE.md
```

Requirements:

- `NN` is a unique two-digit global sequence.
- Names use uppercase ASCII letters, digits, and underscores.
- Files end in `.md`.
- The `_PROMPT` suffix is omitted because the containing directory already establishes that context.
- Acronyms retain readable separation, for example `CI_CD`.
- Filenames describe the task, not a vague role.

Valid:

```text
05_MASTER_SECURITY_AUDIT.md
19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md
```

Invalid:

```text
security/master.md
05-master-security-prompt.md
SECURITY.md
05_MASTER_SECURITY_AUDIT_PROMPT.md
```

## 3. Global Sequence

The sequence communicates recommended lifecycle order, not domain ownership.

- `00–02`: context, contract, orchestration
- `03`: discovery
- `04–06`: security gate
- `07–12`: documentation and engineering change work
- `13–16`: dependencies, configuration, contracts, and data
- `17–21`: performance, reliability, delivery, operations, and incidents
- `22–24`: governance, release gating, and cross-domain project-health consolidation

The orchestrator may skip irrelevant prompts or adjust order when dependencies require it.

## 4. YAML Frontmatter

Every prompt must begin at byte zero with YAML frontmatter.

Required fields:

```yaml
schema_version: "1.0"
suite_id: "universal-project-prompt-suite"
suite_version: "3.2.0"
prompt_id: "UPPS-NN"
sequence: 0
title: ""
slug: ""
canonical_path: "prompts/NN_NAME.md"
category: ""
prompt_type: ""
status: "stable"
description: ""
language_agnostic: true
self_contained: true
default_mode: "AUDIT_ONLY"
allowed_modes: []
modification_scope: ""
risk_level: ""
requires: []
recommended_before: []
recommended_after: []
related_prompts: []
expected_outputs: []
tags: []
last_updated: "YYYY-MM-DD"
```

Specialist prompts also declare:

```yaml
minimum_content_lines: 1000
```

## 5. Identity Rules

- `prompt_id` is immutable after publication.
- `sequence` must equal the filename prefix.
- `canonical_path` must exactly match the file.
- `slug` must be lowercase kebab-case.
- IDs and slugs must be unique.
- Renaming a title does not silently change the prompt ID.
- A breaking semantic rewrite increments the prompt version through the suite release process.

## 6. Prompt Types

Allowed prompt types in this release:

- `template`
- `contract`
- `orchestrator`
- `audit`
- `analysis`
- `generation`
- `review`
- `transformation`
- `remediation`
- `response`
- `gate`

## 7. Categories

Allowed categories in this release:

- `core`
- `orchestration`
- `discovery`
- `security`
- `documentation`
- `engineering`
- `contracts`
- `data`
- `operations`
- `delivery`
- `governance`
- `release`

Categories organize metadata and routing only; they do not create folders.

## 8. Operating Modes

The suite uses exactly:

- `AUDIT_ONLY`
- `PLAN_ONLY`
- `APPLY_SAFE`
- `APPLY_APPROVED`
- `VERIFY_ONLY`

A prompt may default to one mode but must honor the universal execution contract.

## 9. Relationship Semantics

- `requires`: hard prerequisite prompt IDs.
- `recommended_before`: prompts commonly run later.
- `recommended_after`: prompts commonly run earlier.
- `related_prompts`: useful neighboring prompts without a hard dependency.

Relationships use prompt IDs, never filenames, so renames do not break routing metadata.

## 10. Content Rules

Every specialist prompt must:

- be language agnostic;
- define mission and scope;
- inherit or contain the universal execution contract;
- distinguish audit, planning, application, and verification;
- prohibit unsupported completion claims;
- require evidence;
- declare limitations;
- preserve secrets;
- use reversible changes;
- state output structure;
- retain at least 1,000 content lines in this suite edition.

Line count is a minimum coverage constraint, not permission for filler. Repetition without additional operational value is a defect.

## 11. Security Rule

`05_MASTER_SECURITY_AUDIT.md` is the canonical comprehensive security audit.

It runs after discovery and threat modeling, and before:

- cleanup;
- refactoring;
- dependency modification;
- migration;
- production deployment;
- release approval.

Security findings are remediated through `06_SECURITY_REMEDIATION_AND_VERIFICATION.md`.

## 12. Project Health and Release-Gate Rule

`24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md` is the canonical cross-domain audit for:

- whole-project health;
- completeness;
- remaining work;
- contradiction reconciliation;
- human decision discovery;
- phased improvement planning.

It may run early for initial gap discovery and again after specialist reviews for consolidation.

`23_RELEASE_READINESS_AND_FINAL_AUDIT.md` remains the authoritative release gate.

For a major release, the recommended logical order is:

```text
Specialist reviews
        ↓
UPPS-24 Project Health and Completeness
        ↓
UPPS-23 Release Readiness and Final Audit
```

Stable sequence IDs do not override dependency and scenario-specific execution guidance.

## 13. Validation Rules

A valid release must verify:

- flat prompt layout;
- filename regex;
- sequential unique prefixes;
- valid YAML;
- required metadata;
- unique IDs and slugs;
- canonical paths;
- relationship targets;
- no references to removed domain folders;
- no references to retired filenames;
- exactly one H1 per prompt where expected;
- specialist minimum line counts;
- successful ZIP and combined-edition generation.


## Generated Output and Storage Conventions

### Separation of Prompt Sources and Prompt Outputs

Prompt source files live in the suite's `prompts/` directory.

Generated project outputs must never be written into that source directory.

Forbidden default locations include:

```text
./docs/prompts/
./prompts/output/
./prompts/outputs/
./output/
./outputs/
```

### Canonical Project Output Roots

```text
project_root/
├── .prompt_suite/
│   ├── context/
│   ├── contracts/
│   └── runs/
├── docs/
├── reports/
├── plans/
├── artifacts/
├── logs/
├── examples/
└── tmp/
```

#### `.prompt_suite`

Internal persistent state used by prompt execution.

Examples:

```text
.prompt_suite/context/project_context.yaml
.prompt_suite/context/permission_boundary.yaml
.prompt_suite/contracts/universal_execution_contract.md
.prompt_suite/runs/2026_07_11_123045_upps_03/run_manifest.json
```

#### `docs`

Maintained project documentation only.

Examples:

```text
docs/index.md
docs/architecture/system_architecture.md
docs/reference/api_reference.md
docs/operations/runbooks/index.md
```

Do not store prompt context or raw run logs in `docs`.

#### `reports`

Human-readable audit, review, assessment, and verification reports.

Examples:

```text
reports/security/security_audit_report.md
reports/testing/testing_verification_report.md
reports/project_health/project_health_completeness_audit_report.md
```

#### `plans`

Proposed or approved future work.

Examples:

```text
plans/security/security_remediation_plan.md
plans/data/migration_plan.md
plans/delivery/rollback_plan.md
```

A plan must not be presented as completed implementation.

#### `artifacts`

Machine-readable inventories, matrices, manifests, scorecards, diagrams, and evidence indexes.

Examples:

```text
artifacts/inventory/repository_inventory.json
artifacts/security/security_findings.json
artifacts/architecture/component_map.mmd
```

#### `logs`

Sanitized execution traces, command transcripts, timelines, benchmark output, and validation records.

Examples:

```text
logs/prompt_runs/2026_07_11_123045_upps_03/upps_03_execution_log.jsonl
logs/testing/test_execution_log.txt
logs/incidents/incident_timeline.jsonl
```

### Generated Name Convention

All generated paths use lowercase `snake_case`.

Valid filename expression:

```text
^[a-z0-9]+(?:_[a-z0-9]+)*(?:\.[a-z0-9]+)+$
```

Valid directory expression:

```text
^\.?[a-z0-9]+(?:_[a-z0-9]+)*$
```

Rules:

- use lowercase ASCII letters;
- use underscores between words;
- use lowercase extensions;
- do not use spaces;
- do not use hyphens;
- do not use uppercase letters;
- do not prefix generated files with prompt sequence numbers;
- use descriptive stable names;
- avoid words such as `final`, `latest`, `new`, `copy`, or `output`;
- use a timestamped history directory rather than filename suffixes for preserved versions.

### Standard Filename Exceptions

A generated or updated project may need externally conventional filenames such as:

```text
README.md
LICENSE
CHANGELOG.md
SECURITY.md
CODE_OF_CONDUCT.md
CONTRIBUTING.md
```

These are permitted only when the ecosystem or repository convention requires them.

All suite-owned generated reports, plans, artifacts, contexts, and logs remain lowercase `snake_case`.

### Canonical Current Artifact and History

Use a stable canonical path for the current artifact.

Preserve older versions under:

```text
<root>/<category>/history/<yyyy_mm_dd_hhmmss>/<canonical_filename>
```

Example:

```text
reports/security/history/2026_07_11_123045/security_audit_report.md
```

### Run Identifier

The default run identifier is:

```text
yyyy_mm_dd_hhmmss_upps_nn
```

Example:

```text
2026_07_11_123045_upps_05
```

### Prompt Frontmatter Requirement

Every prompt declares an `output_contract` containing:

- path base;
- canonical primary artifact;
- supporting artifacts;
- log directory;
- run manifest path;
- file naming convention;
- directory naming convention;
- overwrite policy;
- directory-creation behavior;
- chat fallback.

### Source-of-Truth Rule

Do not duplicate the same full content across multiple output roots.

Use:

- `docs` for maintained documentation;
- `reports` for human-readable findings;
- `plans` for future work;
- `artifacts` for structured data;
- `logs` for execution evidence.

Cross-link instead of copying.

### Completion Rule

Before claiming completion, report:

- files created;
- files updated;
- files preserved;
- files skipped;
- canonical outputs not generated and why;
- validation of output paths and names.
