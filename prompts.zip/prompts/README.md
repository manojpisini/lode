---
schema_version: '1.1'
suite_id: universal-project-prompt-suite
suite_version: 3.2.0
document_id: UPPS-DOC-README
title: Universal Project Prompt Suite
document_type: readme
status: stable
description: Defines the purpose, structure, operating model, routing strategy, safety model, validation, and practical use of the Universal Project Prompt Suite.
last_updated: '2026-07-11'
---

# Universal Project Prompt Suite

A language-agnostic, evidence-driven prompt system for discovering, auditing, documenting, securing, cleaning, refactoring, testing, operating, governing, and releasing software projects.

**Suite version:** `3.2.0`  
**Prompt files:** **25**  
**Specialist prompts:** **23**  
**Layout:** Flat `prompts/` directory  
**Default operating mode:** `AUDIT_ONLY`  
**Validated specialist minimum:** At least 1,000 lines  
**Canonical security audit:** `prompts/05_MASTER_SECURITY_AUDIT.md`  
**Cross-domain project-health audit:** `prompts/24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md`

## Purpose

The suite helps an AI coding agent, engineering team, maintainer, auditor, or technical lead answer five different questions without collapsing them into one ambiguous instruction:

1. **What is this project?**
2. **What is incomplete, broken, unsafe, contradictory, or risky?**
3. **What specialist analysis is required?**
4. **What changes can be made safely and how should they be verified?**
5. **Is the resulting project ready for its intended use or release?**

Each prompt has a bounded responsibility, explicit prerequisites, operating modes, safety controls, expected outputs, and relationships to other prompts.

## Design Principles

### Evidence Before Assertion

Material conclusions must point to repository evidence, configuration, symbols, line ranges, command output, artifacts, or reproducible observations.

### Audit Before Mutation

Unfamiliar or high-risk repositories begin in `AUDIT_ONLY`. Planning, implementation, and verification are separate stages.

### Specialist Depth Without Context Flooding

Do not load every prompt at once. Use the orchestrator or select the minimum relevant prompts.

### Security as an Independent Gate

Security is not hidden inside code quality. Threat modeling, auditing, and remediation are separate prompts with explicit ordering.

### Behavior and Contract Preservation

Cleanup and refactoring must preserve intended behavior, public contracts, persistent data, supported environments, and operational workflows unless changes are explicitly approved.

### Honest Completion

The suite prohibits unsupported claims such as “complete,” “safe,” “secure,” “production-ready,” or “release-ready.”

## What Is New in Version 3.2.0

- Added a mandatory `output_contract` to all 25 prompts.
- Corrected project-context storage to `./.prompt_suite/context/project_context.yaml`.
- Reserved `./docs/` for maintained documentation.
- Added canonical `./reports/`, `./plans/`, `./artifacts/`, and `./logs/` roots.
- Standardized all prompt-generated directories and filenames to lowercase `snake_case`.
- Added per-prompt primary and supporting output paths.
- Added run manifests under `./.prompt_suite/runs/<run_id>/`.
- Added prompt execution logs under `./logs/prompt_runs/<run_id>/`.
- Added overwrite, preservation, history, redaction, and chat-fallback rules.
- Relocated the project-specific discovery sample from `output/` to `examples/generated_outputs/`.
- Added `MIGRATION_FROM_V3_1.md`.
- Upgraded the frontmatter schema from `1.0` to `1.1`.
- Expanded validation to verify output roots, naming, uniqueness, and forbidden locations.

## Canonical Repository Layout

```text
universal_project_prompt_suite_v3_2/
├── README.md
├── MANIFEST.md
├── PROMPT_CATALOG.md
├── PROMPT_EXECUTION_ORDER.md
├── PROMPT_SUITE_CONVENTIONS.md
├── MIGRATION_FROM_V3_1.md
├── prompt-frontmatter.schema.json
├── VALIDATION.json
└── prompts/
    ├── 00_PROJECT_CONTEXT_TEMPLATE.md
    ├── 01_UNIVERSAL_EXECUTION_CONTRACT.md
    ├── 02_MASTER_PROJECT_ORCHESTRATOR.md
    ├── 03_PROJECT_DISCOVERY_AND_INVENTORY.md
    ├── 04_THREAT_MODELING.md
    ├── 05_MASTER_SECURITY_AUDIT.md
    ├── 06_SECURITY_REMEDIATION_AND_VERIFICATION.md
    ├── 07_COMPREHENSIVE_PROJECT_DOCUMENTATION.md
    ├── 08_ARCHITECTURE_AND_SYSTEM_DESIGN_REVIEW.md
    ├── 09_CODE_QUALITY_AND_MAINTAINABILITY_REVIEW.md
    ├── 10_TESTING_AND_VERIFICATION_REVIEW.md
    ├── 11_SAFE_CLEANUP_AND_REPOSITORY_HYGIENE.md
    ├── 12_SAFE_REFACTORING_AND_MODERNIZATION.md
    ├── 13_DEPENDENCY_AND_SUPPLY_CHAIN_REVIEW.md
    ├── 14_CONFIGURATION_ENVIRONMENT_AND_SECRETS_REVIEW.md
    ├── 15_API_CLI_AND_PUBLIC_CONTRACT_REVIEW.md
    ├── 16_DATA_STORAGE_SCHEMA_AND_MIGRATION_REVIEW.md
    ├── 17_PERFORMANCE_AND_EFFICIENCY_REVIEW.md
    ├── 18_RELIABILITY_RESILIENCE_AND_RECOVERY_REVIEW.md
    ├── 19_CI_CD_BUILD_RELEASE_AND_DEPLOYMENT_REVIEW.md
    ├── 20_OBSERVABILITY_AND_OPERATIONS_REVIEW.md
    ├── 21_INCIDENT_RESPONSE_AND_RECOVERY.md
    ├── 22_LICENSE_COMPLIANCE_AND_GOVERNANCE_REVIEW.md
    ├── 23_RELEASE_READINESS_AND_FINAL_AUDIT.md
    └── 24_COMPREHENSIVE_PROJECT_HEALTH_AND_COMPLETENESS_AUDIT.md
```

The correctly spelled canonical root guide is `PROMPT_EXECUTION_ORDER.md`.

## Prompt Roles

### Foundation

- `UPPS-00` collects project context, constraints, permissions, and acceptance criteria.
- `UPPS-01` establishes suite-wide safety and evidence rules.
- `UPPS-02` selects, sequences, and consolidates specialist work.
- `UPPS-03` establishes repository ground truth.

### Security Gate

- `UPPS-04` builds the threat model.
- `UPPS-05` performs the deep security audit.
- `UPPS-06` repairs validated security findings and verifies closure.

### Engineering and Documentation

- `UPPS-07` creates or repairs the documentation system.
- `UPPS-08` reconstructs and evaluates architecture.
- `UPPS-09` reviews correctness and maintainability.
- `UPPS-10` evaluates verification confidence.
- `UPPS-11` performs behavior-preserving cleanup.
- `UPPS-12` performs controlled refactoring and modernization.

### Dependencies, Configuration, Contracts, and Data

- `UPPS-13` reviews dependencies and software supply chain.
- `UPPS-14` reviews configuration, environment parity, and secrets.
- `UPPS-15` reviews public APIs, CLIs, schemas, and compatibility.
- `UPPS-16` reviews storage, data integrity, schemas, and migrations.

### Performance, Reliability, Delivery, and Operations

- `UPPS-17` measures and improves performance.
- `UPPS-18` evaluates failure behavior, resilience, and recovery.
- `UPPS-19` reviews build, CI/CD, release, deployment, and rollback.
- `UPPS-20` reviews logs, metrics, traces, health, alerts, and runbooks.
- `UPPS-21` prepares or evaluates incident response and recovery.

### Governance and Final Assessment

- `UPPS-22` reviews license, compliance, privacy claims, ownership, and governance.
- `UPPS-23` owns the authoritative release-readiness decision.
- `UPPS-24` consolidates whole-project health, completeness, remaining work, contradictions, and human decisions.

## UPPS-24 Versus UPPS-23

These prompts are related but not interchangeable.

| Prompt | Primary Question | Output | Authority |
|---|---|---|---|
| `UPPS-24` | What remains incomplete, broken, unsafe, contradictory, or unresolved across the whole project? | Health scorecard, completeness matrix, consolidated backlog, contradiction register, phased plan | Project-health and completeness assessment |
| `UPPS-23` | May this exact revision and artifact set be released to the named environment? | Gate scorecard and `GO`, `CONDITIONAL_GO`, `NO_GO`, or `INCOMPLETE` decision | Authoritative release gate |

For a major release, run `UPPS-24` before `UPPS-23` so the release gate receives a consolidated project-health backlog.

## Operating Modes

| Mode | Purpose | File Changes |
|---|---|---|
| `AUDIT_ONLY` | Inspect and report | None |
| `PLAN_ONLY` | Produce an implementation or remediation plan | None |
| `APPLY_SAFE` | Apply low-risk, reversible, behavior-preserving changes | Limited |
| `APPLY_APPROVED` | Apply explicitly authorized higher-impact changes | Authorized scope only |
| `VERIFY_ONLY` | Verify an existing change set or release candidate | None unless explicitly allowed |

## Recommended Starting Paths

### Unknown Repository

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-02`
4. `UPPS-03`
5. Selected specialist prompts
6. `UPPS-24`
7. `UPPS-23` only when a release decision is required

### One Focused Task

1. `UPPS-00`
2. `UPPS-01`
3. The relevant specialist prompt
4. Its required prerequisites
5. Verification prompt or release gate when applicable

### Full Project Audit

1. `UPPS-00`
2. `UPPS-01`
3. `UPPS-02`
4. `UPPS-03`
5. Risk-relevant specialist prompts
6. `UPPS-24`
7. `UPPS-23` for an actual release candidate

## Security Placement

```text
Project Context
      ↓
Execution Contract
      ↓
Project Discovery
      ↓
Threat Modeling
      ↓
Master Security Audit
      ↓
Security Remediation and Verification
      ↓
Cleanup / Refactoring / Dependency Changes / Migration / Deployment
```

Run or revisit security whenever a change alters:

- trust boundaries;
- permissions;
- authentication or authorization;
- tool access;
- external integrations;
- dependencies;
- data flows;
- sensitive storage;
- deployment exposure;
- CI/CD privileges.

## Loading Guidance

Do not concatenate all 25 prompts into one model context.

Load:

1. project context;
2. execution contract;
3. orchestrator or one specialist prompt;
4. only relevant project evidence;
5. related specialist reports when consolidation is required.

Use `PROMPT_CATALOG.md` to select prompts and `PROMPT_EXECUTION_ORDER.md` to sequence them.

## Validation and Integrity

- `VALIDATION.json` is the machine-readable validation result.
- `MANIFEST.md` records prompt identity, metadata, size, and SHA-256 hashes.
- `prompt-frontmatter.schema.json` defines valid prompt metadata.
- `PROMPT_SUITE_CONVENTIONS.md` defines naming and maintenance rules.
- `PROMPT_CATALOG.md` is the human routing reference.
- `PROMPT_EXECUTION_ORDER.md` contains scenario-specific execution plans.

## Maintenance Rules

When adding or changing a prompt:

1. Preserve stable prompt IDs whenever semantics remain compatible.
2. Use a unique global sequence and canonical flat filename.
3. Add valid YAML frontmatter.
4. Declare prerequisites, related prompts, modes, risk, and expected outputs.
5. Update the catalog and execution-order guide.
6. Regenerate the manifest and validation report.
7. Recalculate hashes.
8. Regenerate the combined edition and ZIP package.
9. Do not claim a valid suite release until validation passes.


## Generated Output Architecture

Every prompt now declares a machine-readable `output_contract`.

Output paths are resolved from the audited project's root, not from the installed prompt suite.

### Project Output Tree

```text
project_root/
├── .prompt_suite/
│   ├── context/
│   │   ├── project_context.yaml
│   │   ├── permission_boundary.yaml
│   │   └── verification_requirements.yaml
│   ├── contracts/
│   └── runs/
├── docs/
├── reports/
├── plans/
├── artifacts/
├── logs/
├── examples/
└── tmp/
```

### Corrected Project Context Location

The project context is not project documentation.

Its canonical path is:

```text
./.prompt_suite/context/project_context.yaml
```

It must not be written to:

```text
./docs/prompts/
./prompts/output/
./output/
./outputs/
```

### Root Responsibilities

| Root | Responsibility |
|---|---|
| `./.prompt_suite/` | Prompt context, contracts, run manifests, and suite state |
| `./docs/` | Maintained project documentation |
| `./reports/` | Human-readable audits, reviews, and verification reports |
| `./plans/` | Proposed or approved future work |
| `./artifacts/` | Machine-readable inventories, matrices, diagrams, and evidence |
| `./logs/` | Sanitized command and execution traces |
| `./examples/` | Explicit examples, not current project truth |
| `./tmp/` | Disposable intermediate files |

### Generated Filename Convention

Generated files and directories use lowercase `snake_case`.

Valid:

```text
project_context.yaml
security_audit_report.md
remaining_work_backlog.json
test_execution_log.txt
```

Invalid:

```text
Project_Context.yaml
Security-Audit-FINAL.md
03_PROJECT_DISCOVERY.md
output.json
```

The prompt source files continue to use their established uppercase suite naming convention.

The lowercase rule applies to artifacts generated by those prompts.

### Canonical Output Examples

| Prompt | Canonical Primary Output |
|---|---|
| `UPPS-00` | `./.prompt_suite/context/project_context.yaml` |
| `UPPS-03` | `./reports/discovery/project_discovery_report.md` |
| `UPPS-05` | `./reports/security/security_audit_report.md` |
| `UPPS-07` | `./docs/index.md` |
| `UPPS-10` | `./reports/testing/testing_verification_report.md` |
| `UPPS-19` | `./reports/delivery/ci_cd_build_release_deployment_report.md` |
| `UPPS-23` | `./reports/release/release_readiness_report.md` |
| `UPPS-24` | `./reports/project_health/project_health_completeness_audit_report.md` |

See `PROMPT_CATALOG.md` for every prompt and `PROMPT_SUITE_CONVENTIONS.md` for the full storage contract.
